export enum PatientTypeDto {
  Citizen = 0,
  Company = 1,
  Insurance = 2,
  Foreigner = 3
} 