import { PatientTypeDto } from './patient-type.model';

export interface MedicalServiceDto {
  id: number;
  name: string;
  description: string;
  serviceCode: string;
  categoryId: number;
  categoryName?: string;
  price: number;
  isActive: boolean;
  isRadiologyService?: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface MedicalServiceToSaveDto {
  id: number;
  name: string;
  description: string;
  serviceCode: string;
  categoryId: number;
  categoryName?: string;
  price: number;
  isActive: boolean;
  isRadiologyService?: boolean;
  createdAt?: Date;
  updatedAt?: Date;
  prices? : ServicePriceDto[];
  radiologyReportTemplates?: RadiologyReportTemplateDto[];
  radiologyReportTemplate?: RadiologyReportTemplateDto;
}

export interface RadiologyReportTemplateDto {
  id: number;
  templateCode?: string;
  templateName: string;
  examType: string;
  defaultFindings: string;
  defaultMedicalOpinion: string;
  medicalServiceId: number;
  isActive: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface ServicePriceDto {
  id?: number;
  serviceId?: number;
  price: number;
  patientType: number | PatientType;
  patientTypeId?: number;
  
  // Payment calculations
  doctorAmount: number;
  technicianAmount: number;
  centerPercentage: number;
  
  // Payment types
  doctorPaymentType: PaymentCalculationType;
  technicianPaymentType: PaymentCalculationType;
  
  // Doctor assignments
  allDoctors?: boolean;
  selectedDoctorIds?: number[];
  
  // UI helper fields
  useDoctorFixedAmount?: boolean;
  useTechnicianFixedAmount?: boolean;
}

export enum PaymentCalculationType {
  Percentage = 0,
  FixedAmount = 1
}

// Legacy interfaces for backward compatibility
export interface CategoryService {
  id: number;
  name: string;
  displayOrder: number;
  isActive: boolean;
  children?: CategoryService[];
}

export enum PatientType {
  Citizen = 0,
  Insurance = 1,
  Company = 2,
  Foreigner = 3
}

export interface ServicePrice {
  id: number;
  serviceId: number;
  patientType: any; // can be number or PatientTypeDto
  price: number;
  doctorAmount: number;
  technicianAmount: number;
  centerPercentage: number;
  doctorPaymentType: number;
  technicianPaymentType: number;
  allDoctors: boolean;
  selectedDoctorIds?: number[];
  clinicId?: number;
}

// Legacy MedicalService interface for components that still use it
export interface MedicalService {
  id: number;
  name: string;
  description: string;
  categoryId: number;
  category: CategoryService;
  price: number;
  serviceCode: string;
  prices: ServicePriceDto[];
  isActive: boolean;
  isRadiologyService: boolean;
  radiologyReportTemplates?: RadiologyReportTemplateDto[];
  createdAt: Date;
  updatedAt: Date;
} 