export interface Request {
  id: number;
  title: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected';
  type: 'leave' | 'schedule' | 'equipment';
  priority: 'low' | 'medium' | 'high';
  requesterName: string;
  createdAt: Date;
  updatedAt: Date;
  requesterId: number;
  approverId?: number;
  approverName?: string;
  approvedAt?: Date;
  rejectedAt?: Date;
  rejectionReason?: string;
}
