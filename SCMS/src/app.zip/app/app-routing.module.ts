import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const servicesRoutes: Routes = [
  {
    path: '',
    redirectTo: 'pricing',
    pathMatch: 'full'
  },
  {
    path: 'pricing',
    loadComponent: () => import('./pages/services/service-pricing/service-pricing.component').then(m => m.ServicePricingComponent),
  }
];

const receptionRoutes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/reception/reception.component').then(m => m.ReceptionComponent),
  }
];

const insuranceRoutes: Routes = [
  {
    path: '',
    redirectTo: 'employee-registration',
    pathMatch: 'full'
  },
  {
    path: 'employee-registration',
    loadComponent: () => import('./pages/insurance/employee-registration/employee-registration.component').then(m => m.EmployeeRegistrationComponent),
  }
];

const treasuryRoutes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    loadComponent: () => import('./pages/treasury/treasury-dashboard/treasury-dashboard.component').then(m => m.TreasuryDashboardComponent),
  },
  {
    path: 'doctor-balance',
    loadComponent: () => import('./pages/treasury/doctor-balance/doctor-balance.component').then(m => m.DoctorBalanceComponent),
  },
  {
    path: 'doctor-payouts',
    loadComponent: () => import('./pages/treasury/doctor-payouts/doctor-payouts.component').then(m => m.DoctorPayoutsComponent),
  },
  {
    path: 'expenses',
    loadComponent: () => import('./pages/treasury/expenses/expenses.component').then(m => m.ExpensesComponent),
  },
  {
    path: 'settlements',
    loadComponent: () => import('./pages/treasury/settlements/settlements.component').then(m => m.SettlementsComponent),
  }
];

const imagingRoutes: Routes = [
  {
    path: 'imaging',
    children: [
      {
        path: 'types',
        loadComponent: () => import('./pages/imaging/imaging-types/imaging-types.component')
          .then(m => m.ImagingTypesComponent)
      },
      {
        path: 'request',
        loadComponent: () => import('./pages/imaging/patient-imaging-request/patient-imaging-request.component')
          .then(m => m.PatientImagingRequestComponent)
      },
      {
        path: '',
        redirectTo: 'types',
        pathMatch: 'full'
      }
    ]
  }
];

const applicationsRoutes: Routes = [
  {
    path: 'employee-registration',
    loadComponent: () => import('./pages/insurance/employee-registration/employee-registration.component')
      .then(m => m.EmployeeRegistrationComponent)
  },
  {
    path: 'doctor',
    loadChildren: () => import('./pages/doctor/doctor.module').then(m => m.DoctorModule)
  },
  {
    path: 'reception',
    loadComponent: () => import('./pages/reception/reception.component')
      .then(m => m.ReceptionComponent)
  },
  {
    path: 'user',
    loadChildren: () => import('./user/user.module').then(m => m.UserModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('./settings/settings.module').then(m => m.SettingsModule)
  },
  {
    path: 'documentation',
    loadComponent: () => import('./pages/documentation/documentation.component')
      .then(m => m.DocumentationComponent)
  },
  {
    path: 'treatment',
    loadComponent: () => import('./pages/treatment/treatment.module')
      .then(m => m.TreatmentModule)
  },
  {
    path: 'notification-settings',
    loadComponent: () => import('./pages/settings/notification-settings/notification-settings.component')
      .then(m => m.NotificationSettingsComponent)
  },
  {
    path: 'payment-settings',
    loadComponent: () => import('./pages/settings/payment-settings/payment-settings.component')
      .then(m => m.PaymentSettingsComponent)
  },
  {
    path: 'printer-settings',
    loadComponent: () => import('./pages/settings/printer-settings/printer-settings.component')
      .then(m => m.PrinterSettingsComponent)
  },
  {
    path: 'system-settings',
    loadComponent: () => import('./pages/settings/system-settings/system-settings.component')
      .then(m => m.SystemSettingsComponent)
  },
  {
    path: 'emergency-admission',
    loadChildren: () => import('./pages/apps/emergency-admission/emergency-admission.routes')
      .then(m => m.EMERGENCY_ADMISSION_ROUTES)
  },
  {
    path: 'hospital-requests',
    loadChildren: () => import('./pages/apps/hospital-requests/hospital-requests.routes')
      .then(m => m.HOSPITAL_REQUESTS_ROUTES)
  },

  {
    path: 'surgery',
    loadChildren: () => import('./pages/apps/surgeries/surgery-routing.module')
      .then(m => m.SurgeryRoutingModule)
  },
  {
    path: 'social',
    loadChildren: () => import('./pages/apps/social/social.routes')
      .then(m => m.default)
  },

  {
    path: 'imaging-types',
    loadComponent: () => import('./pages/imaging/imaging-types/imaging-types.component')
      .then(m => m.ImagingTypesComponent)
  },
  {
    path: 'rooms',
    loadComponent: () => import('./pages/apps/room/room.module')
      .then(m => m.RoomsModule)
  },
  {
    path: 'patients',
    loadChildren: () => import('./patients/patients.routes').then(m => m.PATIENTS_ROUTES)
  },
  {
    path: 'appointment',
    loadComponent: () => import('./pages/apps/appointment/appointment.component')
      .then(m => m.AppointmentComponent)
  },
  {
    path: 'analysis-patient',
    loadComponent: () => import('./pages/apps/analysis-patient/analysis-patient.module')
      .then(m => m.AnalysisPatientModule)
  },
  {
    path: 'analysis-laboratory',
    loadComponent: () => import('./pages/apps/analysis-laboratory/analysis-laboratory.module')
      .then(m => m.analysisLaboratoryModule)
  },
  {
    path: 'pharmacy',
    loadChildren: () => import('./pages/apps/Pharmacy/pharmacy.routes')
      .then(m => m.PHARMACY_ROUTES)
  },
  {
    path: 'medical-record',
    loadChildren: () => import('./pages/medical-record/medical-record.routes')
      .then(m => m.MEDICAL_RECORD_ROUTES)
  },

  {
    path: 'Admin',
    loadChildren: () => import('../app/pages/apps/admin/admin.routes')
      .then(m => m.ADMIN_ROUTES)
  },
  {
    path: 'appointments/finish',
    loadChildren: () => import('./pages/finish-appointment/finish-appointment.routes').then(m => m.FINISH_APPOINTMENT_ROUTES),
    data: {
      toolbarShadowEnabled: true,
      containerEnabled: true
    }
  }
];

const radiologyRoutes: Routes = [
  {
    path: '',
    redirectTo: 'templates',
    pathMatch: 'full'
  },
  {
    path: 'create-report',
    loadChildren: () => import('./pages/radiology/create-report/create-report.module').then(m => m.CreateReportModule)
  },
  {
    path: 'templates',
    loadChildren: () => import('./pages/radiology/radiology.module').then(m => m.RadiologyModule)
  }
];

// const settingsRoutes: Routes = [
//   {
//     path: 'settings',
//     children: [
//       {
//         path: 'printer',
//         loadComponent: () => import('./pages/settings/printer-settings/printer-settings.component')
//           .then(m => m.PrinterSettingsComponent)
//       },
//       {
//         path: '',
//         redirectTo: 'printer',
//         pathMatch: 'full'
//       }
//     ]
//   }
// ];

const routes: Routes = [
  {
    path: '',
    redirectTo: '/imaging/types',
    pathMatch: 'full'
  },
  {
    path: 'services',
    children: servicesRoutes
  },
  // {
  //   path: 'reception',
  //   children: receptionRoutes
  // },
  {
    path: 'insurance',
    children: insuranceRoutes
  },
  {
    path: 'treasury',
    children: treasuryRoutes
  },
  // {
  //   path: 'specialties',
  //   loadChildren: () => import('./pages/apps/specialty/specialty-routing.module').then(m => m.)
  // },
  {
    path: 'hospital',
    loadChildren: () => import('./pages/apps/hospital/hospital.module').then(m => m.HospitalModule)
  },
  {
    path: 'radiology',
    children: radiologyRoutes
  },
  ...applicationsRoutes
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
