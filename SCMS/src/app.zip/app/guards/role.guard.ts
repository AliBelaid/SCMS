import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, map, take } from 'rxjs';
import { UserService } from '../user/user.service';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard {
  
  constructor(
    private userService: UserService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
    // Get the roles that can access this route
    const allowedRoles: string[] = route.data['roles'] as string[];
    
    // Check if this is a doctor route with ID
    const isDoctorRoute = state.url.includes('/doctor/');
    const routeId = route.paramMap.get('id');
    
    return this.userService.currentUser$.pipe(
      take(1),
      map(user => {
        if (!user) {
          // User not authenticated, redirect to login
          this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
          return false;
        }
        
        // Get user roles
        const userRoles = user.roles || [];
        
        // If this is a doctor route with ID, check if user is accessing their own profile or is an admin
        if (isDoctorRoute && routeId) {
          // Convert IDs to strings for comparison to avoid type issues
          const userIdStr = String(user.id);
          const routeIdStr = String(routeId);
          const isOwnProfile = userIdStr === routeIdStr;
          
          console.log('Doctor route ID check:', { userID: userIdStr, routeID: routeIdStr, isMatch: isOwnProfile });
          
          // Check if user is a doctor or admin
          const isDoctor = userRoles.some(role => role === 'Doctor');
          const isAdmin = userRoles.some(role => role === 'Admin');
          
          if ((isDoctor && isOwnProfile) || isAdmin) {
            return true;
          } else {
            this.toastr.error('You do not have permission to view this doctor profile');
            this.router.navigate(['/']);
            return false;
          }
        }
        
        // For other protected routes, check if user has any of the required roles
        if (allowedRoles && allowedRoles.length > 0) {
          const hasRequiredRole = userRoles.some(role => allowedRoles.includes(role));
          
          if (hasRequiredRole) {
            return true;
          } else {
            this.toastr.error('You do not have permission to access this page');
            this.router.navigate(['/']);
            return false;
          }
        }
        
        // If no roles specified for the route, allow access
        return true;
      })
    );
  }
} 