import { Component, OnInit, Input } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TreasuryService } from '../../services/treasury.service';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { DoctorPayoutDetailDialogComponent } from './doctor-payout-detail-dialog/doctor-payout-detail-dialog.component';

@Component({
  selector: 'app-doctor-balance',
  templateUrl: './doctor-balance.component.html',
  styleUrls: ['./doctor-balance.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  providers: [DatePipe]
})
export class DoctorBalanceComponent implements OnInit {
  @Input() doctorId: number;
  
  isLoading = false;
  payouts: any[] = [];
  filteredPayouts: any[] = [];
  monthlyTotals: any[] = [];
  
  statusOptions = ['All', 'Pending', 'Paid'];
  selectedStatus = 'All';
  
  startDate: Date = new Date();
  endDate: Date = new Date();
  
  displayedColumns: string[] = ['date', 'settlementDate', 'amount', 'status', 'actions'];
  
  constructor(
    private treasuryService: TreasuryService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private datePipe: DatePipe
  ) { 
    // Initialize date filters to current month
    this.startDate = new Date(this.startDate.getFullYear(), this.startDate.getMonth(), 1);
    this.endDate = new Date(this.endDate.getFullYear(), this.endDate.getMonth() + 1, 0);
  }

  ngOnInit(): void {
    // If doctorId was not passed as input, try to get it from route
    if (!this.doctorId) {
      this.route.parent?.params.subscribe(params => {
        if (params['id']) {
          this.doctorId = +params['id'];
          this.loadDoctorPayouts();
        }
      });
    } else {
      this.loadDoctorPayouts();
    }
  }

  loadDoctorPayouts(): void {
    this.isLoading = true;
    this.treasuryService.getDoctorPayouts({
      doctorId: this.doctorId,
      startDate: this.startDate,
      endDate: this.endDate,
      status: this.selectedStatus !== 'All' ? this.selectedStatus : undefined,
      page: 1,
      pageSize: 100 // Get a reasonable number of payouts
    }).subscribe({
      next: (response) => {
        // Handle the API response format - check if it's an items array or direct array
        if (response.items) {
          this.payouts = response.items;
        } else if (Array.isArray(response)) {
          this.payouts = response;
        } else {
          this.payouts = [];
          console.warn('Unexpected response format:', response);
        }
        
        this.filteredPayouts = [...this.payouts];
        this.calculateMonthlyTotals();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading doctor payouts:', error);
        this.snackBar.open('Error loading doctor payouts', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  calculateMonthlyTotals(): void {
    // Group payouts by month and calculate totals
    const grouped = this.payouts.reduce((acc, payout) => {
      const date = new Date(payout.settlementDate);
      const month = `${date.getFullYear()}-${date.getMonth() + 1}`;
      
      if (!acc[month]) {
        acc[month] = {
          month: month,
          displayMonth: this.datePipe.transform(date, 'MMMM yyyy'),
          totalAmount: 0,
          paidAmount: 0,
          pendingAmount: 0,
          payoutCount: 0
        };
      }
      
      acc[month].totalAmount += payout.amount;
      acc[month].payoutCount++;
      
      if (payout.status === 'Paid') {
        acc[month].paidAmount += payout.amount;
      } else {
        acc[month].pendingAmount += payout.amount;
      }
      
      return acc;
    }, {});
    
    this.monthlyTotals = Object.values(grouped);
  }

  applyFilters(): void {
    this.loadDoctorPayouts();
  }

  resetFilters(): void {
    this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    this.endDate = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
    this.selectedStatus = 'All';
    this.loadDoctorPayouts();
  }

  viewPayoutDetails(payout: any): void {
    // First try to get the detailed payout information
    this.isLoading = true;
    this.treasuryService.getDoctorPayout(payout.id).subscribe({
      next: (payoutDetails) => {
        this.isLoading = false;
        const dialogRef = this.dialog.open(DoctorPayoutDetailDialogComponent, {
          width: '800px',
          data: {
            payout: payout,
            payments: payoutDetails.services || [] // Use the services from the detailed payout
          }
        });
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Error loading payout details:', error);
        
        // Fallback to getting settlement payments if the direct endpoint fails
        this.treasuryService.getSettlementPayments(payout.settlementId).subscribe({
          next: (data) => {
            const dialogRef = this.dialog.open(DoctorPayoutDetailDialogComponent, {
              width: '800px',
              data: {
                payout: payout,
                payments: data
              }
            });
          },
          error: (fallbackError) => {
            console.error('Error loading settlement payments:', fallbackError);
            this.snackBar.open('Error loading settlement details', 'Close', { duration: 3000 });
          }
        });
      }
    });
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'Paid':
        return 'status-paid';
      case 'Pending':
        return 'status-pending';
      default:
        return 'status-default';
    }
  }
} 