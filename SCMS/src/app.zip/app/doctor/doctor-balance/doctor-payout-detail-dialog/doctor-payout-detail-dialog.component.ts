import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-doctor-payout-detail-dialog',
  templateUrl: './doctor-payout-detail-dialog.component.html',
  styleUrls: ['./doctor-payout-detail-dialog.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    TranslateModule
  ]
})
export class DoctorPayoutDetailDialogComponent {
  payout: any;
  payments: any[] = [];
  displayedColumns: string[] = ['patientName', 'serviceName', 'paymentAmount', 'doctorPercentage', 'doctorAmount'];
  
  constructor(
    public dialogRef: MatDialogRef<DoctorPayoutDetailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { payout: any, payments: any[] }
  ) {
    this.payout = data.payout;
    this.payments = data.payments;
  }
  
  close(): void {
    this.dialogRef.close();
  }
  
  getTotalPaymentAmount(): number {
    return this.payments.reduce((sum, payment) => sum + payment.paymentAmount, 0);
  }
  
  getTotalDoctorAmount(): number {
    return this.payments.reduce((sum, payment) => sum + payment.doctorAmount, 0);
  }
  
  getFormattedPaymentDate(): string {
    return this.payout.paymentDate ? new Date(this.payout.paymentDate).toLocaleDateString() : 'N/A';
  }
} 