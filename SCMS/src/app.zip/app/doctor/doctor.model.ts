// export interface Doctor {
//   id: number;
//   name: string;
//   email: string;
//   phone: string;
//   specialty: string;
//   status: 'active' | 'inactive';
//   doctorSpecialties?: string[];
//   createdAt?: Date;
//   updatedAt?: Date;
// }

// export interface DoctorSpecialty {
//   specialtyId: string;
//   specialtyName: string;
// } 