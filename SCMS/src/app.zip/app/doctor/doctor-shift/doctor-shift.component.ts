import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { style } from '@angular/animations';
import { Component, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from "@angular/core";
import { MatDialog, MatDialogModule } from "@angular/material/dialog";
import { MatSnackBar, MatSnackBarModule } from "@angular/material/snack-bar";
import { CalendarView, CalendarEvent, CalendarEventAction, CalendarEventTimesChangedEvent, CalendarA11y, CalendarDayModule, CalendarEventTitleFormatter, CalendarMonthModule, CalendarUtils, CalendarWeekModule } from "angular-calendar";
import { subDays, startOfDay, addDays, endOfMonth, addHours, isSameMonth, isSameDay, endOfDay } from "date-fns";
import { BehaviorSubject, Observable, Subject } from "rxjs";
import { DoctorService } from "../doctor.service";
import { CalendarEditComponent } from "./calendar-edit/calendar-edit.component";
import { LocaleService } from './calendar-edit/LocaleService';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule, NgSwitch, NgSwitchCase } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { CalendarModule, DateAdapter, CalendarDateFormatter, CalendarCommonModule } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { Injectable } from '@angular/core';
import { formatDate } from '@angular/common';
import { ReceptionManagerCreateUpdateComponent } from 'src/app/pages/medical-record/reception-manager-create-update/reception-manager-create-update.component';

const colors: any = {
  blue: {
    primary: '#5c77ff',
    secondary: '#FFFFFF'
  },
  yellow: {
    primary: '#ffc107',
    secondary: '#FDF1BA'
  },
  red: {
    primary: '#f44336',
    secondary: '#FFFFFF'
  }
};

@Injectable()
export class CustomDateFormatter extends CalendarDateFormatter {
  // You can override specific methods if needed
}

@Component({
  selector: 'doctor-shift',
  templateUrl: './doctor-shift.component.html',
  styleUrls: ['./doctor-shift.component.scss'],
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    CalendarCommonModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatCheckboxModule,
    MatButtonToggleModule,
    MatSnackBarModule,
    DialogModule,
    MatTreeModule,
    CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    CdkStepperModule,
    MatStepperModule,
    MatOptionModule,
    DragDropModule ,
    NgSwitch,
    NgSwitchCase,
    CalendarMonthModule,
    CalendarWeekModule,
    CalendarDayModule,
    CalendarModule,
    MatSnackBarModule
  ],
  providers: [
    {
      provide: DateAdapter,
      useFactory: adapterFactory
    },
    CalendarEventTitleFormatter,
    CalendarDateFormatter,
    CalendarUtils,
    CalendarA11y
  ]
})

export class DoctorShiftComponent implements OnInit {

  @ViewChild('modalContent', { static: true }) modalContent: TemplateRef<any>;
   CalendarView = CalendarView;
  // viewDate: Date = new Date();
  modalData: {
    action: string;
    event: CalendarEvent;
  };

  selectedLang= localStorage.getItem('userLang') || 'en';
  view: CalendarView = CalendarView.Month;
  viewDate: Date = new Date();
  today: Date = new Date();
  events$: Observable<CalendarEvent[]> = new BehaviorSubject<CalendarEvent[]>([]).asObservable();
  refresh: BehaviorSubject<any> = new BehaviorSubject<any>(null);





  actions: CalendarEventAction[] = [
    {
      label: '<i class="fa fa-fw fa-pencil"></i>',
      onClick: ({ event }: { event: any }): void => {
        this.handleEvent('Edited', event);
      }
    },
    {
      label: '<i class="fa fa-fw fa-times"></i>',
      onClick: ({ event }: { event: any }): void => {
        this.events = this.events.filter(iEvent => iEvent !== event);
        this.handleEvent('Deleted', event);
      }
    }
  ];
  eventsx: any[] = [
    {
      start: subDays(startOfDay(new Date()), 1),
      end: addDays(new Date(), 1),
      title: 'A 3 day event',

      color: colors.primary,
      actions: this.actions,
      allDay: true,
      resizable: {
        beforeStart: true,
        afterEnd: true
      },
      draggable: true
    },
    {
      start: startOfDay(new Date()),
      title: 'An event with no end date',
      color: colors.yellow,
      actions: this.actions
    },
    {
      start: subDays(endOfMonth(new Date()), 3),
      end: addDays(endOfMonth(new Date()), 3),
      title: 'A long event that spans 2 months',
      color: colors.primary,
      allDay: true
    },
    {
      start: addHours(startOfDay(new Date()), 2),
      end: new Date(),
      title: 'A draggable and resizable event xx',
      color: colors.red,
      actions: this.actions,
      resizable: {
        beforeStart: true,
        afterEnd: true
      },
      draggable: true
    }
    ,
    {
      start: addHours(startOfDay(new Date()), 7),
      end: addHours(startOfDay(new Date()), 11),
      title: 'A kokokokok xx',
      color: colors.black,
      actions: this.actions,
      resizable: {
        beforeStart: true,
        afterEnd: true
      },
      draggable: true
    }
    ,
    {
      start: addHours(startOfDay(new Date()), 7),
      end: addHours(startOfDay(new Date()), 11),
      title: 'Ali bwlaif',
      color: colors.red,
      actions: this.actions,
      resizable: {
        beforeStart: true,
        afterEnd: true
      },
      draggable: true
    },
    {
      start:addHours(startOfDay(new Date()), 8),
      end: addHours(startOfDay(new Date()), 9),
      title: 'hhhdgdg gsdagdsgsdg',
      color: colors.yellow,
      actions: this.actions
    },
  ];
  activeDayIsOpen = true;



  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      this.activeDayIsOpen = !((isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) || events.length === 0);
      this.viewDate = date;
    }
  }

  AddDay(): void {
    // Retrieve the current locale from LocaleService or directly from localStorage
     const currentLang= localStorage.getItem('userLang') || 'en';
    const dateFormat = currentLang === 'ar' ? 'dd/MM/yyyy' : 'MM/dd/yyyy';
    const timeFormat = currentLang === 'ar' ? 'HH:mm' : 'hh:mm a';

    const dialogRef = this.dialog.open(CalendarEditComponent, {
      minWidth: '550px',
      data: {
        event: event,
        dateFormat: dateFormat,
        timeFormat: timeFormat
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.snackbar.open('Updated Event: ' );
        this.refresh.next(null);
      }
    });
  }
  eventTimesChanged({ event, newStart, newEnd }: CalendarEventTimesChangedEvent): void {
    this.events = this.events.map(iEvent => {
      if (iEvent === event) {
        return {
          ...event,
          start: newStart,
          end: newEnd
        };
      }
      return iEvent;
    });
    this.handleEvent('Dropped or resized', event);
  }

  handleEvent(action: string, event: CalendarEvent): void {

    console.log('clik in week day=='+action )
    console.log(event )
    const dialogRef = this.dialog.open(CalendarEditComponent, {
      data: event
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        event = result;
        this.snackbar.open('Updated Event: ' + event.title);
        this.refresh.next(null);
      }
    });
  }
  MedicalRecordHandleEvent(action: string, event: CalendarEvent): void {

    console.log('clik in week day=='+action )
    console.log(event )
    const dialogRef = this.dialog.open(ReceptionManagerCreateUpdateComponent, {
      data: event
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        event = result;
        this.snackbar.open('Updated Event: ' + event.title);
        this.refresh.next(null);
      }
    });
  }
deleteEvent(eventToDelete: CalendarEvent) {
    this.events = this.events.filter(event => event !== eventToDelete);
}
setView(view: CalendarView) {
    this.view = view;
}

closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
}

  events: CalendarEvent[] = [];
  specialties: any[] = [];
  selectedSpecialty: string='All';

  ngOnInit() {
    this.doctorService.getSpecialties().subscribe(data => {
      this.specialties = data;
    });
    this.translate.onLangChange.subscribe(() => {
      console.log('thttjtj')
      this.doctorService.getDoctors().subscribe(doctors => {
        this.events$ = this.doctorService.mapDoctorsToEvents(doctors);
      });
    });
  }

  constructor(private dialog: MatDialog,private localeService:LocaleService,
              private snackbar: MatSnackBar ,
               private doctorService:DoctorService ,private translate:TranslateService) {
                // this.doctorService.getDoctors().subscribe((rep)=>{
                //   this.events=  this.doctorService.mapDoctorsToEvents(rep);
                // console.log(this.events)
                // })
                this.doctorService.getDoctors().subscribe(doctors => {
                  this.events$ = this.doctorService.mapDoctorsToEvents(doctors);
                });
                this.localeService.locale$.subscribe((locale) => {
                  console.log('locale')

                  this.translate.use(locale);
                //  this.refresh.next(); // trigger calendar refresh
                });
                // Listen for language changes to update event titles

  }

onSpecialtySelected(specialtyId: any): void {
                if(specialtyId==='All') {
                  this.doctorService.getDoctors().subscribe((rep)=>{
                     this.doctorService.getDoctors().subscribe(doctors => {
                      this.events$ = this.doctorService.mapDoctorsToEvents(doctors);
                    });

                  console.log(this.events) })
                }else {
                  this.doctorService.getDoctorsBySpecialty(specialtyId).subscribe(doctors => {
                     this.events$ = this.doctorService.mapDoctorsToEvents(doctors);
                    this.refresh.next(null); // This will refresh the calendar to reflect changes
                  });
                }
  }

}
