import { da } from 'date-fns/locale';
import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { AbstractControl, FormsModule, ReactiveFormsModule, UntypedFormBuilder, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { CalendarCommonModule, CalendarEvent, CalendarModule } from 'angular-calendar';
import { addHours, parseISO } from 'date-fns';
import { format } from 'date-fns';
import localeAr from '@angular/common/locales/ar';
import localeEn from '@angular/common/locales/en'; // Typically included by default
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatNativeDateModule, MatOptionModule, MatRippleModule } from '@angular/material/core';
import { LocaleService } from './LocaleService';
import { Observable, of, map, catchError } from 'rxjs';
import { DoctorService } from '../../doctor.service';
import { Doctor, ShiftDto } from 'src/assets/his.model';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSliderModule } from '@angular/material/slider';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { TranslateModule } from '@ngx-translate/core';
import { MaterialFileInputModule } from 'ngx-material-file-input';

function getLocale() {
  const currentLang = localStorage.getItem('userLang') || 'en';
  return currentLang === 'ar' ? 'ar' : 'en';
}

@Component({
  selector: 'vex-calendar-edit',
  templateUrl: './calendar-edit.component.html',
  styleUrls: ['./calendar-edit.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    CalendarModule,
    CalendarCommonModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatCheckboxModule,
    MatButtonToggleModule,
    MatSnackBarModule,
    DialogModule,
    MatTreeModule,
    CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    CdkStepperModule,
    MatStepperModule,
    MatOptionModule,
    MatSliderModule,
    DragDropModule
  ]
})
export class CalendarEditComponent implements OnInit {
  // Default hours value
  hoursValue: number = 2;

  form = this.fb.group({
    doctorId: [this.data?.doctorId, Validators.required],
    day: [this.data?.day, Validators.required],
    startTime: [this.data?.startTime || '08:00', Validators.required],
    count: [this.data?.count || 8, Validators.required],
    endTime: [this.data?.endTime || '10:00', Validators.required]
  }, {
    asyncValidators: shiftValidator(this._doctorService)
  });

  dateFormat: string;
  timeFormat: string;
  doctors: Doctor[] = [];

  constructor(
    private dialogRef: MatDialogRef<CalendarEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private localeService: LocaleService,
    private fb: UntypedFormBuilder,
    private _doctorService: DoctorService,
    private cdr: ChangeDetectorRef,
  ) {
    localeService.locale$.subscribe(locale => {
      this.cdr.markForCheck();
    });

    this._doctorService.getDoctors().subscribe((rep) => {
      this.doctors = rep;
    });
  }

  ngOnInit() {
    this.dateFormat = this.data?.dateFormat || 'MM/dd/yyyy';
    this.timeFormat = this.data?.timeFormat || 'HH:mm';

    // Set default date if not provided
    if (!this.form.get('day').value) {
      this.form.get('day').setValue(new Date());
    }

    // Calculate initial hours value
    this.calculateInitialHours();

    // Initial calculation of end time
    this.updateEndTime();
  }

  // Calculate hours from start and end time
  calculateInitialHours() {
    const startTime = this.form.value.startTime;
    const endTime = this.form.value.endTime;

    if (startTime && endTime) {
      try {
        const start = this.parseTime(startTime);
        const end = this.parseTime(endTime);
        const diffMs = end.getTime() - start.getTime();
        const diffHours = diffMs / (1000 * 60 * 60);
        this.hoursValue = Math.round(diffHours * 2) / 2; // Round to nearest 0.5
        if (this.hoursValue < 1) this.hoursValue = 1;
        if (this.hoursValue > 12) this.hoursValue = 12;
      } catch (error) {
        this.hoursValue = 2; // Default
      }
    }
  }

  // Handle slider change
  updateHoursToAdd(event: any) {
    // Update hours value from slider
    this.hoursValue = event.value;
    // Update end time based on new hours
    this.updateEndTime();
  }

  save() {
    const shift: ShiftDto = {
      doctorId: this.form.value.doctorId,
      day: format(this.form.value.day, 'yyyy-MM-dd'),
      start: this.form.value.startTime,
      end: this.form.value.endTime,
      count: this.form.value.count,
      id: 0
    };

    this._doctorService.addShift(shift).subscribe(
      response => {
        console.log('Shift added successfully:', response);
        this.dialogRef.close(true);
      },
      error => {
        console.error('Error adding shift:', error);
      }
    );
  }

  updateEndTime() {
    const startTime = this.form.value.startTime;

    if (!startTime) return;

    try {
      const parsedTime = this.parseTime(startTime);
      const endTime = addHours(parsedTime, this.hoursValue);

      this.form.patchValue({
        endTime: format(endTime, 'HH:mm')
      }, { emitEvent: false });

      // Update count based on hours (estimate 4 patients per hour)
      const estimatedPatients = Math.ceil(this.hoursValue * 4);
      this.form.patchValue({
        count: estimatedPatients
      }, { emitEvent: false });
    } catch (error) {
      console.error('Error calculating end time:', error);
    }
  }

  parseTime(timeStr: string): Date {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), today.getDate(), hours, minutes);
  }

  // Add quick time presets (morning, afternoon, evening, night)
  setQuickTime(timeOfDay: string) {
    let startTime = '';
    let hours = 0;

    switch(timeOfDay) {
      case 'morning':
        startTime = '08:00';
        hours = 4;
        break;
      case 'afternoon':
        startTime = '12:00';
        hours = 4;
        break;
      case 'evening':
        startTime = '16:00';
        hours = 4;
        break;
      case 'night':
        startTime = '20:00';
        hours = 8;
        break;
      default:
        return;
    }

    // Update form and recalculate
    this.hoursValue = hours;
    this.form.patchValue({
      startTime: startTime
    });

    // Update end time based on new start time and duration
    this.updateEndTime();
  }
}

export function shiftValidator(doctorService: DoctorService): ValidatorFn {
  return (control: AbstractControl): Observable<ValidationErrors | null> => {
    const doctorId = control.get('doctorId')?.value;
    const day = control.get('day')?.value;
    const startTime = control.get('startTime')?.value;
    const endTime = control.get('endTime')?.value;

    if (!doctorId || !day || !startTime || !endTime) {
      return of(null);
    }

    const shift: ShiftDto = {
      doctorId: doctorId,
      day: format(day, 'yyyy-MM-dd'),
      start: startTime,
      end: endTime,
      count: 20,
      id: 0
    };

    return doctorService.checkDuplicateShift(shift).pipe(
      map(isDuplicate => (isDuplicate ? { duplicateShift: true } : null)),
      catchError(() => of(null))
    );
  };
}
