import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatBadgeModule } from '@angular/material/badge';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from '../doctor.service';
import { QueuePatient, ShiftDto } from 'src/assets/his.model';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatMenuModule } from '@angular/material/menu';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { fadeInRight400ms } from 'src/@vex/animations/fade-in-right.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { scaleIn400ms } from 'src/@vex/animations/scale-in.animation';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ToastrService } from 'ngx-toastr';
import { EmergencyAdmissionCreateUpdateComponent } from '../../pages/apps/emergency-admission/emergency-admission-create-update/emergency-admission-create-update';

@Component({
  selector: 'app-doctor-queue',
  template: `
    <div class="container-fluid py-gutter">
      <div *ngIf="isLoading" class="flex items-center justify-center py-8">
        <mat-spinner diameter="40"></mat-spinner>
      </div>
      
      <div [class.opacity-50]="isLoading">
        <!-- Back button -->
        <div class="mb-6">
          <button mat-button (click)="goBack()" class="flex items-center">
            <mat-icon svgIcon="mat:arrow_back" class="mr-2"></mat-icon>
            {{ 'Back' | translate }}
          </button>
        </div>
        
        <div class="card mb-6">
          <div class="px-6 py-4 border-b flex items-center justify-between">
            <div>
              <h2 class="headline m-0">{{ 'Doctor Queue Management' | translate }}</h2>
              <p class="text-secondary m-0">{{ shift?.day || 'No date available' }}</p>
            </div>
            <div class="flex gap-2">
              <button mat-raised-button color="primary" (click)="refreshQueue()">
                <mat-icon svgIcon="mat:refresh" class="mr-2"></mat-icon>
                {{ 'Refresh' | translate }}
              </button>
              <button mat-raised-button color="accent" (click)="addNewPatient()">
                <mat-icon svgIcon="mat:person_add" class="mr-2"></mat-icon>
                {{ 'Add Patient' | translate }}
              </button>
            </div>
          </div>
          
          <div class="px-6 py-4">
            <!-- Error Message -->
            <div *ngIf="hasError" class="alert alert-danger mb-4 p-3 rounded">
              <div class="flex items-center">
                <mat-icon svgIcon="mat:error" class="text-red-500 mr-2"></mat-icon>
                <span>{{ 'Error loading queue data. Please try refreshing.' | translate }}</span>
              </div>
              <div class="mt-2">
                <button mat-raised-button color="primary" (click)="refreshQueue()">
                  <mat-icon svgIcon="mat:refresh" class="mr-2"></mat-icon>
                  {{ 'Refresh' | translate }}
                </button>
              </div>
            </div>
            
            <!-- Queue Navigation Controls -->
            <div class="queue-navigation mb-6 p-4 bg-gray-50 rounded flex items-center justify-between">
              <div class="queue-stats flex gap-4">
                <div class="stat-item text-center">
                  <div class="stat-value text-2xl font-bold text-blue-600">{{ queuePatients?.length || 0 }}</div>
                  <div class="stat-label text-sm text-gray-600">{{ 'Total' | translate }}</div>
                </div>
                <div class="stat-item text-center">
                  <div class="stat-value text-2xl font-bold text-green-600">{{ waitingPatients?.length || 0 }}</div>
                  <div class="stat-label text-sm text-gray-600">{{ 'Waiting' | translate }}</div>
                </div>
                <div class="stat-item text-center">
                  <div class="stat-value text-2xl font-bold text-purple-600">{{ finishedPatients?.length || 0 }}</div>
                  <div class="stat-label text-sm text-gray-600">{{ 'Finished' | translate }}</div>
                </div>
              </div>
              
              <div class="queue-controls flex gap-2">
                <button mat-raised-button color="primary" [disabled]="!hasPreviousPatient()" (click)="goToPreviousPatient()">
                  <mat-icon svgIcon="mat:arrow_back" class="mr-2"></mat-icon>
                  {{ 'Previous' | translate }}
                </button>
                <button mat-raised-button color="accent" (click)="callNextPatient()">
                  <mat-icon svgIcon="mat:arrow_forward" class="mr-2"></mat-icon>
                  {{ 'Next Patient' | translate }}
                </button>
              </div>
            </div>
            
            <!-- Current Patient Card -->
            <div *ngIf="currentPatient" class="card current-patient p-4 mb-6">
              <h3 class="headline mb-2">{{ 'Current Patient' | translate }}</h3>
              <div class="current-patient-info">
                <div class="patient-avatar">
                  <mat-icon svgIcon="mat:person" [ngStyle]="{'color': '#1976d2'}"></mat-icon>
                </div>
                <div class="flex-1">
                  <p class="patient-name">{{ currentPatient?.patientName || 'Unknown Patient' }}</p>
                  <p class="patient-meta">
                    {{ 'Queue #' | translate }}{{ currentPatient?.numberOfQueue }} | 
                    {{ getMeetingTypeName(currentPatient?.meetingType || 0) }}
                  </p>
                </div>
                <div class="flex flex-col gap-2">
                  <button mat-raised-button color="primary" (click)="viewPatientDetails(currentPatient)">
                    <mat-icon svgIcon="mat:visibility" class="mr-2"></mat-icon>
                    {{ 'View Details' | translate }}
                  </button>
                  <button mat-raised-button color="accent" (click)="markAsFinished(currentPatient)">
                    <mat-icon svgIcon="mat:check" class="mr-2"></mat-icon>
                    {{ 'Mark As Finished' | translate }}
                  </button>
                </div>
              </div>
            </div>

            <!-- No Current Patient -->
            <div *ngIf="!currentPatient && queuePatients && queuePatients.length > 0" class="flex flex-col items-center py-8">
              <mat-icon svgIcon="mat:check_circle" class="text-primary mb-4" style="width: 48px; height: 48px;"></mat-icon>
              <h3 class="headline mb-2">{{ 'All patients have been seen' | translate }}</h3>
              <p class="text-secondary text-center mb-4">{{ 'There are no more waiting patients in the queue' | translate }}</p>
              <button mat-raised-button color="primary" (click)="refreshQueue()">
                <mat-icon svgIcon="mat:refresh" class="mr-2"></mat-icon>
                {{ 'Refresh Queue' | translate }}
              </button>
            </div>

            <!-- Empty Queue -->
            <div *ngIf="!queuePatients || queuePatients.length === 0" class="flex flex-col items-center py-8">
              <mat-icon svgIcon="mat:people" class="text-primary mb-4" style="width: 48px; height: 48px;"></mat-icon>
              <h3 class="headline mb-2">{{ 'Empty Queue' | translate }}</h3>
              <p class="text-secondary text-center mb-4">{{ 'There are no patients in the queue' | translate }}</p>
              <button mat-raised-button color="primary" (click)="addNewPatient()">
                <mat-icon svgIcon="mat:person_add" class="mr-2"></mat-icon>
                {{ 'Add Patient' | translate }}
              </button>
            </div>
            
            <!-- Patient Queue Tabs -->
            <mat-tab-group *ngIf="queuePatients && queuePatients.length > 0" class="mt-6" animationDuration="0ms">
              <mat-tab [label]="'Waiting Patients (' + (waitingPatients?.length || 0) + ')'">
                <table mat-table [dataSource]="waitingPatients || []" class="w-full">
                  <ng-container matColumnDef="queueNumber">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Queue #' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">{{ patient.numberOfQueue }}</td>
                  </ng-container>
                  <ng-container matColumnDef="patientName">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Patient' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">{{ patient.patientName }}</td>
                  </ng-container>
                  <ng-container matColumnDef="meetingType">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Meeting Type' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">
                      <span class="status-badge" 
                            [ngClass]="{
                              'emergency': patient.meetingType === 0,
                              'checkup': patient.meetingType === 1,
                              'followup': patient.meetingType === 2
                            }">
                        {{ getMeetingTypeName(patient.meetingType) | translate }}
                      </span>
                    </td>
                  </ng-container>
                  <ng-container matColumnDef="waitingTime">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Waiting Time' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">10 min</td>
                  </ng-container>
                  <ng-container matColumnDef="status">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Status' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">
                      <span class="status-badge waiting">{{ 'Waiting' | translate }}</span>
                    </td>
                  </ng-container>
                  <ng-container matColumnDef="actions">
                    <th mat-header-cell *matHeaderCellDef></th>
                    <td mat-cell *matCellDef="let patient">
                      <button mat-icon-button [matMenuTriggerFor]="menu">
                        <mat-icon svgIcon="mat:more_vert"></mat-icon>
                      </button>
                      <mat-menu #menu="matMenu">
                        <button mat-menu-item (click)="viewPatientDetails(patient)">
                          <mat-icon svgIcon="mat:visibility"></mat-icon>
                          <span>{{ 'View Details' | translate }}</span>
                        </button>
                        <button mat-menu-item (click)="markAsFinished(patient)">
                          <mat-icon svgIcon="mat:check"></mat-icon>
                          <span>{{ 'Mark As Finished' | translate }}</span>
                        </button>
                        <button mat-menu-item (click)="setAsCurrentPatient(patient)">
                          <mat-icon svgIcon="mat:person"></mat-icon>
                          <span>{{ 'Set As Current' | translate }}</span>
                        </button>
                      </mat-menu>
                    </td>
                  </ng-container>
                  <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
                </table>
              </mat-tab>
              <mat-tab [label]="'Finished Patients (' + (finishedPatients?.length || 0) + ')'">
                <table mat-table [dataSource]="finishedPatients || []" class="w-full">
                  <ng-container matColumnDef="queueNumber">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Queue #' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">{{ patient.numberOfQueue }}</td>
                  </ng-container>
                  <ng-container matColumnDef="patientName">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Patient' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">{{ patient.patientName }}</td>
                  </ng-container>
                  <ng-container matColumnDef="meetingType">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Meeting Type' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">
                      <span class="status-badge" 
                            [ngClass]="{
                              'emergency': patient.meetingType === 0,
                              'checkup': patient.meetingType === 1,
                              'followup': patient.meetingType === 2
                            }">
                        {{ getMeetingTypeName(patient.meetingType) | translate }}
                      </span>
                    </td>
                  </ng-container>
                  <ng-container matColumnDef="waitingTime">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Waiting Time' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">10 min</td>
                  </ng-container>
                  <ng-container matColumnDef="status">
                    <th mat-header-cell *matHeaderCellDef>{{ 'Status' | translate }}</th>
                    <td mat-cell *matCellDef="let patient">
                      <span class="status-badge finished">{{ 'Finished' | translate }}</span>
                    </td>
                  </ng-container>
                  <ng-container matColumnDef="actions">
                    <th mat-header-cell *matHeaderCellDef></th>
                    <td mat-cell *matCellDef="let patient">
                      <button mat-icon-button [matMenuTriggerFor]="menu">
                        <mat-icon svgIcon="mat:more_vert"></mat-icon>
                      </button>
                      <mat-menu #menu="matMenu">
                        <button mat-menu-item (click)="viewPatientDetails(patient)">
                          <mat-icon svgIcon="mat:visibility"></mat-icon>
                          <span>{{ 'View Details' | translate }}</span>
                        </button>
                        <button mat-menu-item (click)="reopenPatient(patient)">
                          <mat-icon svgIcon="mat:refresh"></mat-icon>
                          <span>{{ 'Reopen' | translate }}</span>
                        </button>
                      </mat-menu>
                    </td>
                  </ng-container>
                  <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
                </table>
              </mat-tab>
            </mat-tab-group>
          </div>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./doctor-queue.component.scss'],
  standalone: true,
  animations: [
    fadeInUp400ms,
    fadeInRight400ms,
    stagger40ms,
    scaleIn400ms
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    MatTabsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatDividerModule,
    MatBadgeModule,
    TranslateModule,
    MatMenuModule,
    MatProgressSpinnerModule
  ]
})
export class DoctorQueueComponent implements OnInit {
  shiftId: number;
  shift: ShiftDto;
  queuePatients: QueuePatient[] = [];
  waitingPatients: QueuePatient[] = [];
  finishedPatients: QueuePatient[] = [];
  currentPatient: QueuePatient | null = null;
  isLoading = true;
  hasError = false;
  displayedColumns: string[] = ['queueNumber', 'patientName', 'waitingTime', 'meetingType', 'status', 'actions'];
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private doctorService: DoctorService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private toaster: ToastrService,
    private translate: TranslateService
  ) {
    this.isLoading = true;
    
    this.route.paramMap.subscribe(params => {
      const shiftId = params.get('id');
      if (shiftId) {
        this.shiftId = +shiftId;
        this.loadShiftDetails();
      } else {
        this.isLoading = false;
        this.hasError = true;
      }
    });
  }

  ngOnInit() {
    // Component initialized in constructor
  }

  loadShiftDetails() {
    this.isLoading = true;
    this.hasError = false;
    console.log('Loading shift details for shiftId:', this.shiftId);
    
    // Add a safety timeout to ensure loading state is cleared after 10 seconds
    const safetyTimeout = setTimeout(() => {
      if (this.isLoading) {
        console.log('Safety timeout triggered - clearing loading state');
        this.isLoading = false;
        this.hasError = true;
      }
    }, 10000);
    
    this.doctorService.getShiftById(this.shiftId).subscribe({
      next: (shift) => {
        console.log('Shift details loaded successfully');
        this.shift = shift;
        this.queuePatients = shift.queuePatients || [];
        
        // Process the queue patients data
        this.processQueuePatients();
        
        // Clear the safety timeout
        clearTimeout(safetyTimeout);
        
        // Force the change detection by using setTimeout
        setTimeout(() => {
          this.isLoading = false;
          this.hasError = false;
        }, 0);
      },
      error: (error) => {
        console.error('Error loading shift details:', error);
        this.snackBar.open(this.translate.instant('ERROR_LOADING_SHIFT_DETAILS'), 'Close', { duration: 3000 });
        
        // Clear the safety timeout
        clearTimeout(safetyTimeout);
        
        // Even on error, we should stop loading
        this.isLoading = false;
        this.hasError = true;
      }
    });
  }

  processQueuePatients() {
    if (!this.queuePatients || this.queuePatients.length === 0) {
      this.waitingPatients = [];
      this.finishedPatients = [];
      this.currentPatient = null;
      return;
    }
    
    try {
      // Sort by queue number
      this.queuePatients.sort((a, b) => a.numberOfQueue - b.numberOfQueue);
      
      // Find current patient (first non-finished)
      this.currentPatient = this.queuePatients.find(p => !p.isFinished) || null;
      
      // Filter waiting and finished patients
      this.waitingPatients = this.queuePatients.filter(p => !p.isFinished);
      this.finishedPatients = this.queuePatients.filter(p => p.isFinished);
    } catch (error) {
      console.error('Error processing queue patients:', error);
      // Ensure UI still works with default empty arrays
      this.waitingPatients = [];
      this.finishedPatients = [];
      this.currentPatient = null;
    }
  }

  refreshQueue() {
    this.isLoading = true;
    this.hasError = false;
    this.toaster.info(this.translate.instant('REFRESHING_QUEUE'));
    this.loadShiftDetails();
  }

  markAsFinished(patient: QueuePatient): void {
    if (patient.isFinished) {
      this.toaster.info(this.translate.instant('ALREADY_COMPLETED'));
      return;
    }
    
    // Navigate to the finish appointment page
    this.router.navigate(['/appointments/finish', patient.id]);
  }

  callNextPatient() {
    if (this.currentPatient) {
      // Mark current patient as finished
      this.markAsFinished(this.currentPatient);
    }
    
    // Find next patient
    const nextPatient = this.waitingPatients.find(p => p.id !== this.currentPatient?.id);
    if (nextPatient) {
      this.currentPatient = nextPatient;
    } else {
      this.currentPatient = null;
    }
  }

  getWaitingTime(patient: QueuePatient): string {
    // Since createdAt doesn't exist on QueuePatient, we'll return a placeholder value
    // This should be updated once the backend provides creation timestamps
    return "10 min";
  }

  getMeetingTypeName(type: number): string {
    switch (type) {
      case 0:
        return 'Emergency';
      case 1:
        return 'Check-up';
      case 2:
        return 'Follow-up';
      default:
        return 'Unknown';
    }
  }

  viewPatientDetails(patient: QueuePatient) {
    this.router.navigate(['/patients', patient.patientId]);
  }

  addNewPatient() {
    if (!this.shift || !this.shift.doctorId) {
      this.snackBar.open(this.translate.instant('ERROR_SHIFT_DATA_MISSING'), 'Close', { duration: 3000 });
      return;
    }
    
    this.router.navigate(['/doctor/shift'], { 
      queryParams: { doctorId: this.shift.doctorId, shiftId: this.shiftId }
    });
  }

  goBack() {
    this.router.navigate(['/doctor']);
  }

  hasPreviousPatient(): boolean {
    if (!this.currentPatient || !this.waitingPatients) return false;
    const currentIndex = this.waitingPatients.findIndex(p => p.id === this.currentPatient?.id);
    return currentIndex > 0;
  }

  goToPreviousPatient() {
    if (this.currentPatient && this.waitingPatients && this.waitingPatients.length > 0) {
      const currentIndex = this.waitingPatients.findIndex(p => p.id === this.currentPatient?.id);
      if (currentIndex > 0) {
        this.currentPatient = this.waitingPatients[currentIndex - 1];
      }
    }
  }

  setAsCurrentPatient(patient: QueuePatient) {
    this.currentPatient = patient;
    this.toaster.info(this.translate.instant('PATIENT_SET_AS_CURRENT'));
  }

  reopenPatient(patient: QueuePatient) {
    // Find the patient in the queuePatients array
    const index = this.queuePatients.findIndex(p => p.id === patient.id);
    if (index !== -1) {
      // Update the patient status
      this.queuePatients[index].isFinished = false;
      
      // Update the backend
      this.doctorService.updateQueueStatus(patient.id, false).subscribe({
        next: () => {
          this.toaster.success(this.translate.instant('PATIENT_REOPENED'));
          this.processQueuePatients();
        },
        error: (error) => {
          console.error('Error reopening patient:', error);
          this.toaster.error(this.translate.instant('ERROR_REOPENING_PATIENT'));
          // Revert changes if the API call fails
          this.queuePatients[index].isFinished = true;
        }
      });
    }
  }
} 