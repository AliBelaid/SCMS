import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subscription } from 'rxjs';
import { DoctorService } from '../../doctor.service';
import { Doctor } from 'src/assets/his.model';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { TranslateModule } from '@ngx-translate/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'vex-new-doctor-profile',
  templateUrl: './new-doctor-profile.component.html',
  styleUrls: ['./new-doctor-profile.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatTabsModule,
    TranslateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    RouterModule,
    MatTooltipModule
  ]
})
export class NewDoctorProfileComponent implements OnInit, OnDestroy {
  doctor: Doctor;
  isLoading = true;
  doctorSubscription: Subscription;
  doctorId: string;
  activeTabIndex = 0;

  navLinks = [
    {
      path: 'details',
      label: 'DETAILS',
      icon: 'mat:person'
    },
    {
      path: 'queue',
      label: 'QUEUE',
      icon: 'mat:queue'
    },
    {
      path: 'schedule',
      label: 'SCHEDULE',
      icon: 'mat:calendar_today'
    },
    {
      path: 'balance',
      label: 'BALANCE',
      icon: 'mat:account_balance'
    },
    {
      path: 'reports',
      label: 'REPORTS',
      icon: 'mat:assessment'
    },
    {
      path: 'settings',
      label: 'SETTINGS',
      icon: 'mat:settings'
    }
  ];

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    public doctorService: DoctorService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.isLoading = true;
    this.loadDoctor();
  }

  loadDoctor() {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.doctorId = id;
        this.loadDoctorDetails();
      } else {
        this.snackBar.open('Doctor ID not found', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  loadDoctorDetails() {
    this.isLoading = true;
    this.doctorSubscription = this.doctorService.getDoctorById(this.doctorId).subscribe({
      next: (doctor) => {
        this.doctor = doctor;
        this.doctorService.setCurrentDoctor(doctor);
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading doctor details:', error);
        this.snackBar.open('Error loading doctor details', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  toggleEditMode() {
    if (!this.doctor) {
      this.snackBar.open('Cannot edit: Doctor data not loaded', 'Close', { duration: 3000 });
      return;
    }
    
    // Enable edit mode in the DoctorService
    this.doctorService.setEditModeEnabled(true);
    
    // Check if we're currently in the details page
    if (this.router.url.endsWith('/details')) {
      // We're already in the details page, just enable edit mode
      this.snackBar.open('Edit mode enabled', 'Close', { duration: 2000 });
    } else {
      // Navigate to the details page with edit mode enabled
      this.router.navigate(['details'], { relativeTo: this.route });
      this.activeTabIndex = 0; // Set the details tab as active
      this.snackBar.open('Navigated to details with edit mode enabled', 'Close', { duration: 2000 });
    }
  }

  ngOnDestroy() {
    if (this.doctorSubscription) {
      this.doctorSubscription.unsubscribe();
    }
  }
} 