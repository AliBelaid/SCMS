import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { DoctorService } from '../../doctor.service';
import { ActivatedRoute } from '@angular/router';
import { Doctor, QueuePatient } from 'src/assets/his.model';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-doctor-reports',
  templateUrl: './doctor-reports.component.html',
  styleUrls: ['./doctor-reports.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    MatSelectModule,
    MatProgressSpinnerModule
  ]
})
export class DoctorReportsComponent implements OnInit {
  doctor: Doctor | null = null;
  doctorId: string;
  isLoading = true;
  patients: QueuePatient[] = [];
  displayedColumns: string[] = ['patientName', 'date', 'meetingType', 'status', 'actions'];
  filteredPatients: QueuePatient[] = [];
  
  // Filter parameters
  filterStatus: string = 'all';
  filterDateFrom: Date | null = null;
  filterDateTo: Date | null = null;
  searchTerm: string = '';

  constructor(
    private doctorService: DoctorService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.parent?.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.doctorId = id;
        this.loadDoctorDetails();
      }
    });
  }

  loadDoctorDetails() {
    this.isLoading = true;
    this.doctorService.getDoctorById(this.doctorId).subscribe({
      next: (doctor) => {
        this.doctor = doctor;
        this.collectAllPatients();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading doctor details:', error);
        this.isLoading = false;
      }
    });
  }

  collectAllPatients() {
    if (this.doctor?.shifts) {
      this.patients = [];
      this.doctor.shifts.forEach(shift => {
        if (shift.queuePatients) {
          this.patients.push(...shift.queuePatients);
        }
      });
      this.applyFilters();
    }
  }

  applyFilters() {
    this.filteredPatients = this.patients.filter(patient => {
      // Apply status filter
      if (this.filterStatus !== 'all') {
        const isFinished = this.filterStatus === 'finished';
        if (patient.isFinished !== isFinished) {
          return false;
        }
      }
      
      // Apply search term filter
      if (this.searchTerm && !patient.patientName.toLowerCase().includes(this.searchTerm.toLowerCase())) {
        return false;
      }
      
      // Apply date filters if available
      // Note: This would need actual date data from the backend
      
      return true;
    });
  }

  onFilterChange() {
    this.applyFilters();
  }

  onSearch(event: Event) {
    this.searchTerm = (event.target as HTMLInputElement).value;
    this.applyFilters();
  }

  resetFilters() {
    this.filterStatus = 'all';
    this.filterDateFrom = null;
    this.filterDateTo = null;
    this.searchTerm = '';
    this.applyFilters();
  }

  getMeetingTypeName(type: number): string {
    switch (type) {
      case 0:
        return 'EMERGENCY';
      case 1:
        return 'CHECKUP';
      case 2:
        return 'FOLLOW_UP';
      default:
        return 'Unknown';
    }
  }
} 