import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { DoctorService } from '../../doctor.service';
import { ActivatedRoute } from '@angular/router';
import { Doctor } from 'src/assets/his.model';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-doctor-settings',
  templateUrl: './doctor-settings.component.html',
  styleUrls: ['./doctor-settings.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatSlideToggleModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDividerModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    MatProgressSpinnerModule
  ]
})
export class DoctorSettingsComponent implements OnInit {
  doctor: Doctor | null = null;
  doctorId: string;
  isLoading = true;
  
  // Settings options
  notificationsEnabled = true;
  emailNotifications = true;
  darkModeEnabled = false;
  language = 'en';
  autoAcceptAppointments = false;
  
  // Visual themes
  availableThemes = [
    { id: 'default', name: 'Default' },
    { id: 'dark', name: 'Dark' },
    { id: 'light', name: 'Light' },
    { id: 'custom', name: 'Custom' }
  ];
  selectedTheme = 'default';

  constructor(
    private doctorService: DoctorService,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    this.route.parent?.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.doctorId = id;
        this.loadDoctorDetails();
      }
    });
  }

  loadDoctorDetails() {
    this.isLoading = true;
    this.doctorService.getDoctorById(this.doctorId).subscribe({
      next: (doctor) => {
        this.doctor = doctor;
        this.initializeSettings();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading doctor details:', error);
        this.isLoading = false;
      }
    });
  }

  initializeSettings() {
    // Here, we would load settings from the backend
    // For now, we're using demo values
  }

  saveSettings() {
    // Here, we would save the settings to the backend
    // For now, we just show a success message
    
    this.snackBar.open('Settings saved successfully', 'Close', {
      duration: 3000
    });
  }

  resetSettings() {
    this.notificationsEnabled = true;
    this.emailNotifications = true;
    this.darkModeEnabled = false;
    this.language = 'en';
    this.autoAcceptAppointments = false;
    this.selectedTheme = 'default';
  }
} 