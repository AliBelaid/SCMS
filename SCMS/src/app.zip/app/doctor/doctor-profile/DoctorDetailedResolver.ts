// import { Injectable } from '@angular/core';
// import {
//   Router, Resolve,
//   RouterStateSnapshot,
//   ActivatedRouteSnapshot
// } from '@angular/router';
// import { Observable, map, of, take } from 'rxjs';

// import { DoctorService } from '../doctor.service';
// import { Doctor } from 'src/assets/his.model';

// @Injectable({
//   providedIn: 'root'
// })


// export class  DoctorDetailedResolver implements Resolve<Doctor> {

//   constructor(private SpecialtyService:DoctorService) {

//   }
//   resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Doctor> {
//    var id=route.paramMap.get('id');
//     if(id===null ||id ==='default') return null;
// {    return this.SpecialtyService.getDoctorById(id);
// }

//   }
// }

