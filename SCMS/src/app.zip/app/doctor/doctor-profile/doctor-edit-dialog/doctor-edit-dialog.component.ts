import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { TranslateModule } from '@ngx-translate/core';

import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { DoctorService } from 'src/app/doctor/doctor.service';
import { finalize } from 'rxjs/operators';
import { Doctor } from 'src/assets/his.model';

// Interface for doctor specialty
interface DoctorSpecialtyDTO {
  specialtyId: number;
}

// Interface for the doctor specialties as they come from the API
interface DoctorSpecialty {
  specialtyId: number;
  specialtyName?: string;
}

@Component({
  selector: 'vex-doctor-edit-dialog',
  templateUrl: './doctor-edit-dialog.component.html',
  styleUrls: ['./doctor-edit-dialog.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatSelectModule,
    MatDividerModule,
    TranslateModule,
    MatSlideToggleModule
  ]
})
export class DoctorEditDialogComponent implements OnInit {
  form: FormGroup;
  isEditMode: boolean;
  availableSpecialties: any[] = [];
  isLoading = false;
  specialtyIds: string[] = [];
  
  constructor(
    private dialogRef: MatDialogRef<DoctorEditDialogComponent>,
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: { doctor?: Doctor },
    private doctorService: DoctorService
  ) {
    this.isEditMode = !!this.data?.doctor;
    if (this.data?.doctor?.specialization && Array.isArray(this.data.doctor.specialization)) {
      this.specialtyIds = this.data.doctor.specialization.map((ds: any) => ds.specialtyId);
    }
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      name: [this.data?.doctor?.name || '', [Validators.required]],
      email: [this.data?.doctor?.email || '', [Validators.required, Validators.email]],
      phone: [this.data?.doctor?.phone || '', [Validators.required]],
      specialty: [this.data?.doctor?.specialty || '', [Validators.required]],
      status: [this.data?.doctor?.status || 'active', [Validators.required]]
    });
    this.loadSpecialties();
  }
  
  loadSpecialties(): void {
    this.isLoading = true;
    this.doctorService.getSpecialties()
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (specialties) => {
          this.availableSpecialties = specialties;
        },
        error: (error) => {
          console.error('Error loading specialties:', error);
        }
      });
  }

  onSubmit(): void {
    if (this.form.valid) {
      const doctorData: Doctor = {
        ...this.form.value,
        id: this.data?.doctor?.id
      };
      this.dialogRef.close(doctorData);
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }
} 