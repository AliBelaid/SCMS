import { Component, OnInit, OnDestroy, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { take, Subscription } from 'rxjs';
import { fadeInRight400ms } from 'src/@vex/animations/fade-in-right.animation';
import { scaleIn400ms } from 'src/@vex/animations/scale-in.animation';
import { Link } from 'src/@vex/interfaces/link.interface';
import { DoctorService } from '../doctor.service';
import { Doctor } from 'src/assets/his.model';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { BackendApiService } from 'src/assets/services/backend-api.service';

@Component({
  selector: 'app-doctor-profile',
  templateUrl: './doctor-profile.component.html',
  styleUrls: ['./doctor-profile.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatTabsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatOptionModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDialogModule,
    MatMenuModule,
 MatTabsModule
  ],
  animations: [
    scaleIn400ms,
    fadeInRight400ms
  ]
})
export class DoctorProfileComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('fileInput') fileInput: ElementRef;
  
  public photoCover: string;
  public photoAvatar: string;
  links: Link[];
  doctor: Doctor | null = null;
  user: Doctor | null = null;
  isEditing: boolean = false;
  isLoading: boolean = false;
  doctorSubscription: Subscription;
  activeTabIndex: number = 0;

  navLinks = [
    {
      label: 'SCHEDULE',
      path: 'schedule',
      icon: 'mat:calendar_today'
    },
    {
      label: 'DETAILS',
      path: 'details',
      icon: 'mat:person'
    },
    {
      label: 'QUEUE',
      path: 'queue',
      icon: 'mat:people'
    },
    {
      label: 'BALANCE',
      path: 'balance',
      icon: 'mat:account_balance'
    },
    {
      label: 'REPORTS',
      path: 'reports',
      icon: 'mat:assessment'
    },
    {
      label: 'SETTINGS',
      path: 'settings',
      icon: 'mat:settings'
    }
  ];

  constructor(
    public doctorService: DoctorService,
    private router: Router,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    //private backendApiService: AuthService ,
   

  ) {}

  ngOnInit(): void {
    this.isLoading = true;
    const doctorId = Number(this.route.snapshot.paramMap.get('id'));
    
    // Subscribe to currentDoctor$ to get updates
    this.doctorSubscription = this.doctorService.currentDoctor$.subscribe(doctor => {
      if (doctor) {
        console.log(doctor);
        this.doctor = doctor;
        this.user = doctor;
        this.setupProfileData();
        this.isLoading = false;
        this.ensureValidTabRoute();
      } else if (doctorId) {
        // If no current doctor but we have an ID, load from API
        this.loadDoctor(doctorId);
      } else {
        this.snackBar.open('Doctor ID not found', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
    
    // Check the current URL to set the active tab
    this.checkActiveTab();
  }
  
  ngAfterViewInit() {
    // Slight delay to ensure view is fully initialized
    setTimeout(() => {
      this.checkActiveTab();
    }, 100);
  }

  checkActiveTab() {
    const currentUrl = this.router.url;
    const activeTabPath = this.navLinks.findIndex(tab => 
      currentUrl.includes(`/${tab.path}`)
    );
    
    if (activeTabPath >= 0) {
      this.activeTabIndex = activeTabPath;
    } else {
      // Default to schedule if no match
      this.activeTabIndex = 0;
    }
  }

  loadDoctor(id: number) {
    this.isLoading = true;
    this.doctorService.getDoctorById(id).subscribe({
      next: (doctor) => {
        this.doctor = doctor;
        this.user = doctor;
        this.doctorService.setCurrentDoctor(doctor); // Update the current doctor in service
        this.setupProfileData();
        this.isLoading = false;
        this.ensureValidTabRoute();
      },
      error: (error) => {
        console.error('Error loading doctor details:', error);
        this.snackBar.open('Error loading doctor details', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  setupProfileData() {
    if (this.doctor) {
      console.log(this.doctor);
      this.links = [
        {
          label: "Schedule",
          route: `/doctor/${this.doctor.id}/schedule`,
          routerLinkActiveOptions: { exact: true }
        },
        {
          label: "Details",
          route: `/doctor/${this.doctor.id}/details`
        },
        {
          label: "Queue",
          route: `/doctor/${this.doctor.id}/queue`
        },
        {
          label: "Balance",
          route: `/doctor/${this.doctor.id}/balance`
        },
        {
          label: "Reports",
          route: `/doctor/${this.doctor.id}/reports`
        },
        {
          label: "Settings",
          route: `/doctor/${this.doctor.id}/settings`
        }
      ];
      console.log(this.links);
      // Set photos
      this.photoAvatar = this.doctor.photoUrl || 'assets/img/avatars/default-avatar.png';
      this.photoCover = 'assets/img/Medical/background3.jpg';
    }
  }

  ensureValidTabRoute() {
    // Get the current URL segments
    const urlSegments = this.router.url.split('/');
    const lastSegment = urlSegments[urlSegments.length - 1];
    
    // Check if we're at the doctor/:id route without a specific tab
    if (this.doctor && urlSegments.length >= 3 && !this.navLinks.some(tab => tab.path === lastSegment)) {
      // Navigate to the schedule tab by default
      this.router.navigate(['schedule'], { relativeTo: this.route });
    }
  }

  toggleEdit() {
    this.isEditing = !this.isEditing;
  }

  saveProfile() {
    // Implement save functionality
    this.isEditing = false;
    this.snackBar.open('Profile saved successfully', 'Close', { duration: 2000 });
  }

  openEditMode() {
    this.toggleEdit();
  }

  navigateToTab(path: string) {
    this.router.navigate([path], { relativeTo: this.route });
  }
  
  onTabChange(event: any) {
    const selectedTab = this.navLinks[event.index];
    if (selectedTab) {
      this.navigateToTab(selectedTab.path);
    }
  }

  ngOnDestroy() {
    if (this.doctorSubscription) {
      this.doctorSubscription.unsubscribe();
    }
  }

  toggleEditMode() {
    if (!this.doctor) {
      this.snackBar.open('Cannot edit: Doctor data not loaded', 'Close', { duration: 3000 });
      return;
    }
    
    console.log('Toggle edit mode called');
    
    // Enable edit mode in the DoctorService
    this.doctorService.setEditModeEnabled(true);
    
    // Open edit dialog
    import('./doctor-edit-dialog/doctor-edit-dialog.component').then(m => {
      const dialogRef = this.dialog.open(m.DoctorEditDialogComponent, {
        width: '800px',
        data: { doctor: this.doctor }
      });
      
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          // Handle the updated doctor data
          this.isLoading = true;
          this.doctorService.updateDoctor(this.doctor.id, result).subscribe({
            next: (updatedDoctor) => {
              this.doctor = updatedDoctor;
              this.doctorService.setCurrentDoctor(updatedDoctor);
              this.isLoading = false;
              this.snackBar.open('Doctor profile updated successfully', 'Close', { duration: 3000 });
            },
            error: (error) => {
              console.error('Error updating doctor:', error);
              this.isLoading = false;
              this.snackBar.open('Error updating doctor profile', 'Close', { duration: 3000 });
            }
          });
        }
        
        // Disable edit mode after dialog is closed
        this.doctorService.setEditModeEnabled(false);
      });
    });
  }

  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.isLoading = true;
      
      // Convert file to base64 string
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const base64String = e.target.result;
        
        // Upload the base64 image to the server
        this.doctorService.uploadPhoto(this.doctor.id, base64String).subscribe(
          response => {
            // Get the URL from the response
            const photoUrl = response?.photoUrl || '';
            
            // Update user and doctor properties
            if (photoUrl) {
              this.user.photoUrl = photoUrl;
              this.doctor.photoUrl = photoUrl;
              // Also update in the doctor service
              this.doctorService.currentDoctorSourcesNext(this.doctor);
            }
            
            // Hide loading state
            this.isLoading = false;
            
            // Show success notification
            this.snackBar.open('Profile photo updated successfully', 'Close', {
              duration: 3000,
              horizontalPosition: 'end',
              verticalPosition: 'top'
            });
          },
          error => {
            console.error('Error uploading doctor photo:', error);
            this.isLoading = false;
            
            // Show error notification
            this.snackBar.open('Failed to upload photo. Please try again.', 'Close', {
              duration: 3000,
              horizontalPosition: 'end',
              verticalPosition: 'top'
            });
          }
        );
      };
      
      reader.readAsDataURL(file);
    }
  }
}
