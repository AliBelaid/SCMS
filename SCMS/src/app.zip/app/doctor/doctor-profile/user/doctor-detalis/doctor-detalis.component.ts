import { HttpClient } from "@angular/common/http";
import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MatDialogModule } from "@angular/material/dialog";
import { ActivatedRoute, Router, RouterModule } from "@angular/router";
import { take } from "rxjs";
import { fadeInRight400ms } from "src/@vex/animations/fade-in-right.animation";
import { fadeInUp400ms } from "src/@vex/animations/fade-in-up.animation";
import { scaleIn400ms } from "src/@vex/animations/scale-in.animation";
import { stagger40ms } from "src/@vex/animations/stagger.animation";
import { TranslateModule, TranslateService } from "@ngx-translate/core";
import { DoctorService } from "src/app/doctor/doctor.service";
import { Doctor, QueuePatient, ShiftDto } from "src/assets/his.model";
import { CommonModule } from "@angular/common";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { MatInputModule } from "@angular/material/input";
import { MatFormFieldModule } from "@angular/material/form-field";
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { MatCardModule } from "@angular/material/card";
import { MatTabsModule } from "@angular/material/tabs";
import { MatListModule } from "@angular/material/list";
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  selector: "vex-doctor-detalis",
  templateUrl: "./doctor-detalis.component.html",
  styleUrls: ["./doctor-detalis.component.scss"],
  animations: [fadeInUp400ms, fadeInRight400ms, scaleIn400ms, stagger40ms],
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    MatCardModule,
    MatTabsModule,
    MatIconModule,
    MatListModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatSelectModule,
    MatDividerModule,
    MatSlideToggleModule
  ]
})
export class DoctorDetalisComponent implements OnInit {
  @ViewChild('fileInput') fileInput: ElementRef;
  
  doctor: Doctor;
  isLoading = false;
  todayShift: ShiftDto | null = null;
  doctorId: string | number;
  specializationDetails: any;
  error: string | null = null;
  editMode = false;
  editForm: FormGroup;
  specialtyIds: string[] = [];
  selectedImage: string | ArrayBuffer | null = null;
  imageFile: File | null = null;
  availableSpecialties: any[] = [];
  saveLoading = false;
  
  constructor(
    private router: Router,
    private http: HttpClient,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private doctorService: DoctorService,
    public translate: TranslateService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadDoctor();
    this.initForm();
    this.loadSpecialties();
  }

  initForm(): void {
    this.editForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', Validators.required],
      hospitalAffiliation: [''],
      specialization: ['', Validators.required],
      specializationDetails: [''],
      yearsOfExperience: [0, [Validators.required, Validators.min(0)]],
      active: [true]
    });
  }

  loadDoctor(): void {
    this.route.parent?.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.doctorId = parseInt(id, 10);
        this.isLoading = true;
        this.loadDoctorDetails(id);
      } else {
        this.snackBar.open('Doctor ID not found', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }
  
  loadDoctorDetails(doctorId: string | number): void {
    this.doctorService.getDoctorById(doctorId).subscribe({
      next: (doctor) => {
        this.doctor = {
          ...doctor,
          specialization: typeof doctor.specialization === 'string' 
            ? this.decodeHtml(doctor.specialization)
            : doctor.specialization,
          specializationDetails: doctor.specializationDetails || ''
        };

        // Update the current doctor in the service
        this.doctorService.currentDoctorSourcesNext(this.doctor);

        if (doctor.specializationDetails) {
          try {
            // Check if it's already an object
            if (typeof doctor.specializationDetails === 'object') {
              this.specializationDetails = doctor.specializationDetails;
            } else {
              // Try to parse as JSON, but wrap in try/catch
              this.specializationDetails = JSON.parse(doctor.specializationDetails);
            }
          } catch (e) {
            console.error('Error parsing specialization details:', e);
            // Instead of setting to null, create a basic object with the text
            this.specializationDetails = {
              mainSpecialty: doctor.specialization || 'N/A',
              description: doctor.specializationDetails || ''
            };
          }
        }
        
        // Update the form with doctor data
        this.updateFormWithDoctorData();
        
        this.findTodayShift();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading doctor:', error);
        this.snackBar.open(
          this.translate.instant('ERROR_LOADING_DOCTOR'),
          this.translate.instant('CLOSE'),
          { duration: 3000 }
        );
        this.isLoading = false;
        this.error = 'Could not load doctor details';
      }
    });
  }

  updateFormWithDoctorData(): void {
    if (this.doctor) {
      this.editForm.patchValue({
        firstName: this.doctor.firstName || '',
        lastName: this.doctor.lastName || '',
        email: this.doctor.email || '',
        phoneNumber: this.doctor.phone || '',
        hospitalAffiliation: this.doctor.hospitalAffiliation || '',
        specialization: this.doctor.specialization || '',
        specializationDetails: this.doctor.specializationDetails || '',
        yearsOfExperience: this.doctor.yearsOfExperience || 0,
        active: this.doctor.active || true
      });
      
      // Use logo or photoUrl, whichever is available
      if (this.doctor['logo']) {
        this.selectedImage = this.doctor['logo'];
      } else if (this.doctor.photoUrl) {
        this.selectedImage = this.doctor.photoUrl;
      }
    }
  }

  loadSpecialties(): void {
    this.doctorService.getSpecialties().subscribe({
      next: (specialties) => {
        this.availableSpecialties = specialties;
      },
      error: (error) => {
        console.error('Error loading specialties:', error);
      }
    });
  }

  decodeHtml(html: string): string {
    const txt = document.createElement('textarea');
    txt.innerHTML = html;
    return txt.value;
  }

  findTodayShift() {
    if (this.doctor && this.doctor.shifts && this.doctor.shifts.length > 0) {
      try {
        const today = new Date().toISOString().split('T')[0];
        this.todayShift = this.doctor.shifts.find(shift => {
          if (!shift.day) return false;
          const shiftDate = new Date(shift.day).toISOString().split('T')[0];
          return shiftDate === today;
        }) || null;
        
        if (this.todayShift && this.todayShift.id) {
          this.loadShiftDetails(this.todayShift.id);
        }
      } catch (e) {
        console.error('Error finding today\'s shift:', e);
        this.todayShift = null;
      }
    }
  }

  loadShiftDetails(shiftId: number) {
    this.doctorService.getShiftById(shiftId).subscribe({
      next: (shift) => {
        this.todayShift = shift;
      },
      error: (error) => {
        console.error('Error loading shift details:', error);
        this.snackBar.open('Error loading shift details', 'Close', { duration: 3000 });
      }
    });
  }

  enableEditMode() {
    this.editMode = true;
    this.doctorService.setEditModeEnabled(true);
    this.updateFormWithDoctorData();
  }
  
  cancelEdit() {
    this.editMode = false;
    this.doctorService.setEditModeEnabled(false);
    this.selectedImage = this.doctor['logo'] || this.doctor.photoUrl || null;
    this.imageFile = null;
    
    // Reset the form with original data
    this.updateFormWithDoctorData();
    
    // Clear file input if it exists
    if (this.fileInput && this.fileInput.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
  }
  
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.imageFile = input.files[0];
      
      // Create a preview and convert to base64
      const reader = new FileReader();
      reader.onload = () => {
        this.selectedImage = reader.result;
      };
      reader.readAsDataURL(this.imageFile);
    }
  }
  
  openFileSelector(): void {
    if (this.editMode && this.fileInput) {
      this.fileInput.nativeElement.click();
    }
  }
  
  removeImage(): void {
    if (this.editMode) {
      this.selectedImage = null;
      this.imageFile = null;
      if (this.fileInput) {
        this.fileInput.nativeElement.value = '';
      }
    }
  }

  saveChanges(): void {
    if (!this.editForm.valid) {
      this.snackBar.open(
        this.translate.instant('PLEASE_FIX_FORM_ERRORS'),
        this.translate.instant('CLOSE'),
        { duration: 3000 }
      );
      return;
    }
    
    this.saveLoading = true;
    
    // Prepare the updated doctor data
    const updatedDoctor = {
      ...this.doctor,
      ...this.editForm.value,
      // Map phoneNumber to phone for the API
      phone: this.editForm.value.phoneNumber,
    };
    
    // If we have a new image as base64, add it directly to the doctor data
    if (this.selectedImage && typeof this.selectedImage === 'string' && 
        this.selectedImage !== this.doctor.photoUrl && 
        this.selectedImage !== this.doctor['logo']) {
      
      // The selectedImage is already a base64 string from the FileReader
      updatedDoctor['logo'] = this.selectedImage;
    }
    
    // Send the update with the image included in the doctor data
    this.updateDoctorData(updatedDoctor);
  }
  
  updateDoctorData(doctorData: any): void {
    this.doctorService.updateDoctor(this.doctor.id, doctorData).subscribe({
      next: (updatedDoctor) => {
        this.doctor = updatedDoctor;
        this.doctorService.currentDoctorSourcesNext(updatedDoctor);
        
        this.editMode = false;
        this.saveLoading = false;
        this.doctorService.setEditModeEnabled(false);
        
        this.snackBar.open(
          this.translate.instant('DOCTOR_PROFILE_UPDATED'),
          this.translate.instant('CLOSE'),
          { duration: 3000 }
        );
        
        // Show loading state
        this.isLoading = true;
        
        // Set a small timeout to ensure UI shows loading state
        setTimeout(() => {
          // Reload doctor details from server to get fresh data
          this.loadDoctorDetails(this.doctorId);
        }, 1000);
      },
      error: (error) => {
        console.error('Error updating doctor:', error);
        this.saveLoading = false;
        this.snackBar.open(
          this.translate.instant('ERROR_UPDATING_PROFILE'),
          this.translate.instant('CLOSE'),
          { duration: 3000 }
        );
      }
    });
  }

  formatDate(dateString: string): string {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return 'Invalid Date';
      }
      return date.toLocaleDateString();
    } catch (e) {
      console.error('Error formatting date:', e);
      return 'Invalid Date';
    }
  }

  getFullName(): string {
    if (!this.doctor) return 'N/A';
    if (this.doctor.firstName) {
      return this.doctor.firstName + ' ' + this.doctor.lastName;
    }
    const firstName = this.doctor.firstName || '';
    const lastName = this.doctor.lastName || '';
    return `${firstName} ${lastName}`.trim() || 'N/A';
  }

  getClinicNames(): string {
    if (!this.doctor || !this.doctor.clinicDoctorAssignments || this.doctor.clinicDoctorAssignments.length === 0) {
      return 'N/A';
    }
    return this.doctor.clinicDoctorAssignments
      .map(assignment => assignment.clinicName)
      .filter(name => name)
      .join(', ') || 'N/A';
  }

  getSpecializationDetails(): any {
    if (!this.specializationDetails) return null;
    try {
      return {
        mainSpecialty: this.specializationDetails.mainSpecialty || 'N/A',
        subSpecialties: this.specializationDetails.subSpecialties || [],
        certifications: this.specializationDetails.certifications || [],
        specialInterests: this.specializationDetails.specialInterests || [],
        description: this.specializationDetails.description || 'N/A'
      };
    } catch (e) {
      console.error('Error getting specialization details:', e);
      return null;
    }
  }
}
