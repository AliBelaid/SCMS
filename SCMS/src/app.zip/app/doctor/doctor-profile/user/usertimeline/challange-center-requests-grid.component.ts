
// import { Component, OnInit } from '@angular/core';
// import { MatDialog } from '@angular/material/dialog';
// import { ActivatedRoute } from '@angular/router';
// import { map } from 'rxjs/operators';
// import { fadeInRight400ms } from 'src/@vex/animations/fade-in-right.animation';
// import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
// import { scaleFadeIn400ms } from 'src/@vex/animations/scale-fade-in.animation';
// import { scaleIn400ms } from 'src/@vex/animations/scale-in.animation';
// import { stagger40ms } from 'src/@vex/animations/stagger.animation';
// import { Link } from 'src/@vex/interfaces/link.interface';
// import { trackById } from 'src/@vex/utils/track-by';
// import { Challange } from 'src/app/pages/apps/challange-center/challange-center-requests/interfaces/course.interface';
// import { Course } from 'src/app/pages/apps/courses/interfaces/course.interface';

// @Component({
//   selector: 'vex-challange-center-requests-grid',
//   templateUrl: './challange-center-requests-grid.component.html',
//   styleUrls: ['./challange-center-requests-grid.component.scss'],
//   animations: [
//     scaleIn400ms,
//     fadeInRight400ms,
//     stagger40ms,
//     fadeInUp400ms,
//     scaleFadeIn400ms
//   ]
// })
// export class ChallangeCenterRequestsGridComponent implements OnInit {

//   // courses = coursesData;
//   // filteredCourses$ = this.route.paramMap.pipe(
//   //   map(paramMap => paramMap.get('activeCategory')),
//   //   map(activeCategory => {
//   //     switch (activeCategory) {
//   //       case 'all': {
//   //         return coursesData;
//   //       }

//   //       case 'starred': {
//   //         return    coursesData.filter(c => c.locked);
//   //       }

//   //       default: {
//   //         return [];
//   //       }
//   //     }
//   //   })
//   // );

//   path =  'assets/images/users/avatar-5.jpg' ; 
//   avatars  =  "avatar-5"  ; 
 

//     challangeData: Challange[] = [
//     {
//       id: 12,
//       imageSrc:  this.path  + this.avatars +   '4.jpg',
//       userName: 'w.abuaziz',
//       subjectName: 'جغرافيا العالم',
//       creationTime: '03-11-2022 11:25:13 AM ',
//       endTime:'03-11-2022 11:25:13 AM ',
//       locked:false,
//       waitting:true ,
//       live:3,      
//       title:'أتحداك'  ,
//     },
//     {
//       id: 13,
//       imageSrc:  this.path  + this.avatars +   '3.jpg',
//       userName: 'm.ali',
//       subjectName: 'جغرافيا العالم',
//       creationTime: '03-11-2022 11:25:13 AM ',
//       endTime:'03-11-2022 11:25:13 AM ',
//       locked:false,
//       waitting:true ,
//       live:3,      
//       title:'أين الشجعان'  ,
//     },
//     {
//       id: 13,
//       imageSrc:  this.path  + this.avatars +   '2.jpg',
//       userName: 'm.ali',
//       subjectName: 'جغرافيا العالم',
//       creationTime: '03-11-2022 11:25:13 AM ',
//       endTime:'03-11-2022 11:25:13 AM ',
//       locked:false,
//       waitting:true ,
//       live:3,      
//       title:'هل من مبارز'  ,
//     },
//     {
//       id: 13,
//       imageSrc:  this.path  + this.avatars +   '1.jpg',
//       userName: 'm.ali',
//       subjectName: 'جغرافيا العالم',
//       creationTime: '03-11-2022 11:25:13 AM ',
//       endTime:'03-11-2022 11:25:13 AM ',
//       locked:true,
//       waitting:false ,
//       live:3,      
//       title:'أنا الذي سمتني أمي حيدرة'  ,
//     },
//     {
//       id: 13,
//       imageSrc:  this.path  + this.avatars +   '4.jpg',
//       userName: 'm.ali',
//       subjectName: 'جغرافيا العالم',
//       creationTime: '03-11-2022 11:25:13 AM ',
//       endTime:'03-11-2022 11:25:13 AM ',
//       locked:false,
//       waitting:true ,
//       live:0,      
//       title:'ألا ترى أن السيف ينقص قدره اذا قيل أن السيف أمضى من العصا'  ,
//     },
//     {
//       id: 13,
//       imageSrc:  this.path  + this.avatars +   '3.jpg',
//       userName: 'm.ali',
//       subjectName: 'جغرافيا العالم',
//       creationTime: '03-11-2022 11:25:13 AM ',
//       endTime:'03-11-2022 11:25:13 AM ',
//       locked:false,
//       waitting:false ,
//       live:3,      
//       title:'ومدجج كره الكماة نزاله  - لا ممعنا هربا ولا مستسلم'  ,
//     },

//     ]


//   challanges = this.challangeData;
//   filteredChallanges$ = this.route.paramMap.pipe(
//     map(paramMap => paramMap.get('activeCategory')),
//     map(activeCategory => {
//       switch (activeCategory) {
//         case 'all': {
//           return this.challangeData;
//         }

//         case 'starred': {
//           return    this.challangeData.filter(c => c.locked);
//         }

//         default: {
//           return [];
//         }
//       }
//     })
//   );


 



  
//   links: Link[] = [
//     {
//       label: 'جميع التحديات',
//       route: '../all'
//     },
//     {
//       label: '  تحديات مباشرة',
//       route: '../frequent'
//     },
//     {
//       label: ' تحديات مجموعات    ',
//       route: '../starred'
//     }
//   ];

//   trackById = trackById;

//   constructor(private dialog: MatDialog,
//               private route: ActivatedRoute) { }

//   ngOnInit() {}

//   openChallange(id?: Course['id']) {
//     // this.dialog.open(ContactsEditComponent, {
//     //   data: id || null,
//     //   width: '600px'
//     // });
//   }

//   toggleStar(id: Course['id']) {
//     const challange = this.challangeData.find(c => c.id === id);

//     if (challange) {926665555
//       challange.locked = !challange.locked;
//     }
//   }





  
// }
