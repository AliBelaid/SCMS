// import { finalize, take } from 'rxjs';
// import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
// import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

//  import { stagger40ms } from 'src/@vex/animations/stagger.animation';
// import { DoctorService } from 'src/app/doctor/doctor.service';
// import { TranslateService } from '@ngx-translate/core';
// import { fadeInRight400ms } from 'src/@vex/animations/fade-in-right.animation';
// import { QueuePatient } from 'src/assets/his.model';


// export interface ContactsTableMenu {
//   type: 'link' | 'subheading';
//   id: 'all' | 'WAITING_LIST' | 'FINISHED_CASES' | 'TOTAL_QUEUE' | 'EMERGENCY_CASES' | 'REVIEW_CASES' | 'EXAMINATION_CASES' |'Older';

//   icon?: string;
//   label: string;
//   classes?: {
//     icon?: string;
//   };
// }

// @Component({
//   selector: 'vex-contacts-table-menu',
//   templateUrl: './contacts-table-menu.component.html',
//   animations: [fadeInRight400ms, stagger40ms]
// })
// export class ContactsTableMenuComponent implements OnInit {

//   // @Input() items: ContactsTableMenu[] = [
//   //   {
//   //     type: 'link',
//   //     id: 'all',
//   //     icon: 'mat:view_headline',
//   //     label: 'All cases'
//   //   },
//   //   {
//   //     type: 'link',
//   //     id: 'waitingPatients',
//   //     icon: 'mat:history',
//   //     label: 'Waiting list'
//   //   },
//   //   {
//   //     type: 'link',
//   //     id: 'starred',
//   //     icon: 'mat:star',
//   //     label: 'Upcoming cases'
//   //   }, {
//   //     type: 'link',
//   //     id: 'isFinished',
//   //     icon: 'mat:home',
//   //     label: 'Previous cases'
//   //   } ,

//   //   {
//   //     type: 'link',
//   //     id: 'nextNumber',
//   //     icon: 'mat:home',
//   //     label: 'Next cases'
//   //   }

//   // ];
//   @Input() items: ContactsTableMenu[] = [
//     // {
//     //   type: 'link',
//     //   id: 'all',
//     //   icon: 'mat:view_headline',
//     //   label: 'All cases'
//     // },
//     {
//       type: 'link',
//       id: 'WAITING_LIST',
//       icon: 'mat:history',
//       label: 'WAITING_LIST'
//     },
//     // {
//     //   type: 'link',
//     //   id: 'starred',
//     //   icon: 'mat:star',
//     //   label: 'Upcoming cases'
//     // },

//     {
//       type: 'link',
//       id: 'FINISHED_CASES',
//       icon: 'mat:check',
//       label: 'FINISHED_CASES'
//     },
//     {
//       type: 'link',
//       id: 'TOTAL_QUEUE',
//       icon: 'mat:queue',
//       label: 'TOTAL_QUEUE'
//     },
//     {
//       type: 'link',
//       id: 'EMERGENCY_CASES',
//       icon: 'mat:local_hospital',
//       label: 'EMERGENCY_CASES'
//     },
//     {
//       type: 'link',
//       id: 'REVIEW_CASES',
//       icon: 'mat:assignment',
//       label: 'REVIEW_CASES'
//     },
//     {
//       type: 'link',
//       id: 'EXAMINATION_CASES',
//       icon: 'mat:search',
//       label: 'EMERGENCY_CASES'
//     }

//     ,
//     {
//       type: 'link',
//       id: 'Older',
//       icon: 'mat:search',
//       label: 'Older'
//     }


//   ];

//   @Output() filterChange = new EventEmitter<QueuePatient[]>();
//   @Output() openAddNew = new EventEmitter<void>();
// @Input() contactsData:QueuePatient[]=[];
// @Input() contactsDataOlder:QueuePatient[]=[];
//   activeCategory: ContactsTableMenu['id'] = 'all';

//   constructor(private _doctorService:DoctorService ,public translate:TranslateService) {

//    }

//   ngOnInit() {
// this.loadeDate();
// this.setFilter('TOTAL_QUEUE');
//   }



//   formatDate(date: Date): string {
//     const month = date.getMonth() + 1; // getMonth() is zero-based
//     const day = date.getDate();
//     const year = date.getFullYear();
//     return `${month}/${day}/${year}`;
//   }
//   setFilter(category: ContactsTableMenu['id']) {
//     const today = this.formatDate(new Date())
//     console.log(this.contactsData)
//     console.log(today)

//        if(this.activeCategory !==category) {
//     this.loadeDate();
//    }
//     this.activeCategory = category;


//     switch (this.activeCategory) {
//        case 'WAITING_LIST':
//         return this.filterChange.emit(this.contactsData.filter(c => !c.isFinished && c.day == today));

//       case 'FINISHED_CASES':
//         return this.filterChange.emit(this.contactsData.filter(c => c.isFinished && c.day == today));

//       case 'TOTAL_QUEUE':
//         {
//           console.log(this.contactsData)
//           return this.filterChange.emit(this.contactsData.filter(c => c.day == today));
//         }
//       case 'EMERGENCY_CASES':
//         return this.filterChange.emit(this.contactsData.filter(c => c.meetingType === 0 && c.day == today));

//       case 'REVIEW_CASES':
//         return this.filterChange.emit(this.contactsData.filter(c => c.meetingType === 1 && c.day == today));

//       case 'EXAMINATION_CASES':
//         return this.filterChange.emit(this.contactsData.filter(c => c.meetingType === 2 && c.day == today));

//           case 'Older':
//          this.filterChange.emit(this.contactsDataOlder.filter(c => c.day < today));
//             break;




//       default:
//         return this.filterChange.emit(this.contactsData);
//     }
//   }


//   isActive(category: ContactsTableMenu['id']) {
//     return this.activeCategory === category;
//   }

//   loadeDate() {
//     this._doctorService.currentMember$.pipe(take(1)).subscribe((response) => {
//         if(response != null) {
//            this.contactsData= response.queuePatients;
//         }},
//       error=> {
//     console.log(error)
//   });

//   }

// }
