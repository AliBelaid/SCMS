import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { MatChipsModule } from '@angular/material/chips';
import { MatBadgeModule } from '@angular/material/badge';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DoctorService } from '../../../../doctor.service';
import { ActivatedRoute, Router } from '@angular/router';
import { QueuePatient, ShiftDto } from 'src/assets/his.model';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { scaleIn400ms } from 'src/@vex/animations/scale-in.animation';
import { fadeInRight400ms } from 'src/@vex/animations/fade-in-right.animation';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-contacts-table',
  templateUrl: './contacts-table.component.html',
  styleUrls: ['./contacts-table.component.scss'],
  standalone: true,
  animations: [
    fadeInUp400ms,
    stagger40ms,
    scaleIn400ms,
    fadeInRight400ms
  ],
  imports: [
    CommonModule,
    MatTabsModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    MatMenuModule,
    MatChipsModule,
    MatBadgeModule,
    MatProgressSpinnerModule
  ]
})
export class ContactsTableComponent implements OnInit {
  doctorId: string;
  isLoading = true;
  queuePatients: QueuePatient[] = [];
  waitingPatients: QueuePatient[] = [];
  finishedPatients: QueuePatient[] = [];
  emergencyPatients: QueuePatient[] = [];
  checkupPatients: QueuePatient[] = [];
  followupPatients: QueuePatient[] = [];
  
  displayedColumns: string[] = ['queueNumber', 'patientName', 'meetingType', 'waitingTime', 'status', 'actions'];
  searchTerm = '';
  shifts: ShiftDto[] = [];
  selectedShift: ShiftDto | null = null;
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private doctorService: DoctorService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.route.parent?.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.doctorId = id;
        this.loadDoctorShifts();
      }
    });
  }

  loadDoctorShifts() {
    this.isLoading = true;
    this.doctorService.getDoctorById(this.doctorId).subscribe({
      next: (doctor) => {
        if (doctor && doctor.shifts) {
          this.shifts = doctor.shifts;
          // Get today's shift if available
          const today = new Date().toISOString().split('T')[0];
          this.selectedShift = this.shifts.find(s => s.day === today) || this.shifts[0];
          
          if (this.selectedShift) {
            this.loadQueuePatients(this.selectedShift.id);
          } else {
            this.isLoading = false;
          }
        } else {
          this.isLoading = false;
        }
      },
      error: (error) => {
        console.error('Error loading doctor shifts:', error);
        this.snackBar.open('Error loading doctor shifts', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  loadQueuePatients(shiftId: number) {
    this.isLoading = true;
    this.doctorService.getShiftWithFallback(shiftId).subscribe({
      next: (shift) => {
        this.selectedShift = shift;
        this.queuePatients = shift.queuePatients || [];
        this.filterAndCategorizePatients();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading queue patients:', error);
        this.snackBar.open('Error loading queue patients', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  filterAndCategorizePatients() {
    // Filter by search term if provided
    let filteredPatients = this.searchTerm ? 
      this.queuePatients.filter(p => 
        p.patientName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        p.numberOfQueue.toString().includes(this.searchTerm)
      ) : 
      [...this.queuePatients];
    
    // Sort by queue number
    filteredPatients.sort((a, b) => a.numberOfQueue - b.numberOfQueue);
    
    // Categorize patients by status
    this.waitingPatients = filteredPatients.filter(p => !p.isFinished);
    this.finishedPatients = filteredPatients.filter(p => p.isFinished);
    
    // Categorize patients by meeting type
    this.emergencyPatients = filteredPatients.filter(p => p.meetingType === 0);
    this.checkupPatients = filteredPatients.filter(p => p.meetingType === 1);
    this.followupPatients = filteredPatients.filter(p => p.meetingType === 2);
  }

  getWaitingTime(patient: QueuePatient): string {
    // Static placeholder since createdAt doesn't exist on QueuePatient
    return "10 min";
  }

  getMeetingTypeName(type: number): string {
    switch (type) {
      case 0:
        return 'EMERGENCY';
      case 1:
        return 'CHECKUP';
      case 2:
        return 'FOLLOW_UP';
      default:
        return 'Unknown';
    }
  }

  viewPatientDetails(patient: QueuePatient) {
    this.router.navigate(['/patients', patient.patientId]);
  }

  markAsFinished(patient: QueuePatient) {
    const index = this.queuePatients.findIndex(p => p.id === patient.id);
    if (index !== -1) {
      this.queuePatients[index].isFinished = true;
      this.doctorService.batchUpdateQueuePatients([this.queuePatients[index]]).subscribe({
        next: () => {
          this.snackBar.open('Patient marked as finished', 'Close', { duration: 2000 });
          this.filterAndCategorizePatients();
        },
        error: (error) => {
          console.error('Error updating patient status:', error);
          this.snackBar.open('Error updating patient status', 'Close', { duration: 3000 });
          // Revert changes if the API call fails
          this.queuePatients[index].isFinished = false;
        }
      });
    }
  }

  onSelectShift(shift: ShiftDto) {
    this.loadQueuePatients(shift.id);
  }

  onSearch(event: Event) {
    const input = event.target as HTMLInputElement;
    this.searchTerm = input.value;
    this.filterAndCategorizePatients();
  }

  viewShiftQueue(shiftId: number) {
    this.router.navigate(['/doctor/queue', shiftId]);
  }
}
