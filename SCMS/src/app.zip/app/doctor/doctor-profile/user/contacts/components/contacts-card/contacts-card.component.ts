import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { QueuePatient } from 'src/assets/his.model';

@Component({
  selector: 'vex-contacts-card',
  templateUrl: './contacts-card.component.html',
  styleUrls: ['./contacts-card.component.scss']
})
export class ContactsCardComponent implements OnInit {

  @Input() contact: QueuePatient;
  @Output() openContact = new EventEmitter<QueuePatient['id']>();
  @Output() toggleStar = new EventEmitter<QueuePatient['id']>();

  constructor() { }

  ngOnInit() {
  }

  emitToggleStar(event: MouseEvent, contactId: QueuePatient['id']) {
    event.stopPropagation();
    this.toggleStar.emit(contactId);
  }
}
