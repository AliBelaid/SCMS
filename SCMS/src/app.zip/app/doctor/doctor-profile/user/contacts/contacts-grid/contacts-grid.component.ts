import { Component, Input, OnInit } from '@angular/core';

import { ContactsEditComponent } from '../components/contacts-edit/contacts-edit.component';
import { MatDialog } from '@angular/material/dialog';

import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';
import { fadeInRight400ms } from 'src/@vex/animations/fade-in-right.animation';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { scaleFadeIn400ms } from 'src/@vex/animations/scale-fade-in.animation';
import { scaleIn400ms } from 'src/@vex/animations/scale-in.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { Link } from 'src/@vex/interfaces/link.interface';
import { trackById } from 'src/@vex/utils/track-by';
import { QueuePatient } from 'src/assets/his.model';

@Component({
  selector: 'vex-contacts-grid',
  templateUrl: './contacts-grid.component.html',
  styleUrls: ['./contacts-grid.component.scss'],
  animations: [
    scaleIn400ms,
    fadeInRight400ms,
    stagger40ms,
    fadeInUp400ms,
    scaleFadeIn400ms
  ]
})
export class ContactsGridComponent implements OnInit {

 @Input() contacts:QueuePatient[] ;
  filteredContacts$ = this.route.paramMap.pipe(
    map(paramMap => paramMap.get('activeCategory')),
    map(activeCategory => {
      switch (activeCategory) {
        case 'all': {
          return this.contacts;
        }

        case 'starred': {
          return this.contacts.filter(c => c.isFinished);
        }

        default: {
          return [];
        }
      }
    })
  );

  links: Link[] = [
    {
      label: 'All Contacts',
      route: '../all'
    },
    {
      label: 'isFinished',
      route: '../isFinished'
    },
    {
      label: 'nextNumber',
      route: '../nextNumber'
    }
  ];

  trackById = trackById;

  constructor(private dialog: MatDialog,
              private route: ActivatedRoute) { }

  ngOnInit() {}

  openContact(id?: QueuePatient['id']) {
    this.dialog.open(ContactsEditComponent, {
      data: id || null,
      width: '600px'
    });
  }

  toggleStar(id: QueuePatient['id']) {
    const contact = this.contacts.find(c => c.id === id);

    if (contact) {
      contact.isFinished = !contact.isFinished;
    }
  }
}
