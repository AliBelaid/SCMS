import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ContactsCardModule } from '../components/contacts-card/contacts-card.module';
import { ContactsGridComponent } from './contacts-grid.component';
import { ContactsGridRoutingModule } from './contacts-grid-routing.module';

@NgModule({
  declarations: [ContactsGridComponent],
  imports: [
    CommonModule,
    ContactsGridRoutingModule,
    MatTabsModule,

    MatButtonModule,
    MatDialogModule,
    ContactsCardModule,
    MatIconModule,
    MatTooltipModule,
    ContactsCardModule
  ]
})
export class ContactsGridModule {
}
