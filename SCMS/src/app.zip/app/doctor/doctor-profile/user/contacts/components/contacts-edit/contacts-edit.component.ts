import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { UntypedFormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { QueuePatient } from 'src/assets/his.model';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatMenuModule } from '@angular/material/menu';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

export let contactIdCounter = 50;

@Component({
  selector: 'vex-contacts-edit',
  templateUrl: './contacts-edit.component.html',
  styleUrls: ['./contacts-edit.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatMenuModule,
    MatSelectModule,
    MatCheckboxModule,MatDividerModule,
    MatDialogModule,
    MatIconModule,
    MatInputModule,
    MatDividerModule,
    MatDatepickerModule,

    ReactiveFormsModule,
    MatMenuModule,
    MatButtonModule,
    MatNativeDateModule
  ]
})
export class ContactsEditComponent implements OnInit {

  form = this.fb.group({
    // name: null,
    // email: null,
    // phone: null,
    // company: null,
    // notes: null,
    // birthday: null
    numberOfQueue : null,
    selected : null,
   isFinished : null,
  });

  contact: QueuePatient;

  get isEdit(): boolean {
    return !!this.contactId;
  }

  constructor(@Inject(MAT_DIALOG_DATA) private contactId: QueuePatient['id'],
              private dialogRef: MatDialogRef<ContactsEditComponent>,
              private fb: UntypedFormBuilder) { }

  ngOnInit() {
    if (this.contactId) {
    //   this.contact = contactsData.find(c => c.id === this.contactId);
    //   this.form.patchValue(this.contact);
    // }
    }
  }

  toggleStar() {
    if (this.contact) {
      this.contact.isFinished = !this.contact.isFinished;
    }
  }

  save() {
    const form = this.form.value;

    if (!this.contact) {
      this.contact = {
        ...form,
        id: contactIdCounter++
      };
    }

    this.contact.numberOfQueue = form.name;
    this.contact.selected = form.selected;
    this.contact.patientName = form.patientName;
    this.contact.isFinished = form.isFinished;
   // this.contact.notes = form.notes;
   // this.contact.birthday = form.birthday;

    this.dialogRef.close();
  }
}
