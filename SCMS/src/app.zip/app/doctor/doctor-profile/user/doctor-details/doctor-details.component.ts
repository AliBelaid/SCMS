import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subscription } from 'rxjs';
import { DoctorService } from '../../../../doctor/doctor.service';
import { Doctor } from 'src/assets/his.model';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TranslateModule } from '@ngx-translate/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'vex-doctor-details',
  templateUrl: './doctor-details.component.html',
  styleUrls: ['./doctor-details.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatDividerModule,
    MatFormFieldModule,
    MatInputModule,
    TranslateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    RouterModule
  ]
})
export class DoctorDetailsComponent implements OnInit, OnDestroy {
  doctor: Doctor;
  isLoading = true;
  doctorSubscription: Subscription;
  doctorId: number;
  
  constructor(
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    public doctorService: DoctorService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.isLoading = true;
    this.loadDoctor();
  }

  loadDoctor() {
    this.route.parent?.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.doctorId = parseInt(id, 10);
        this.loadDoctorDetails();
      } else {
        this.snackBar.open('Doctor ID not found', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  loadDoctorDetails() {
    this.isLoading = true;
    this.doctorSubscription = this.doctorService.getDoctorById(this.doctorId).subscribe({
      next: (doctor) => {
        this.doctor = doctor;
        this.doctorService.currentDoctorSourcesNext(doctor);
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading doctor details:', error);
        this.snackBar.open('Error loading doctor details', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  openEdit() {
    // Find parent component and trigger the edit mode
    if (this.doctor) {
      this.doctorService.setEditModeEnabled(true);
      this.snackBar.open('Edit mode activated', 'Close', { duration: 2000 });
    } else {
      this.snackBar.open('Cannot edit: Doctor data not loaded', 'Close', { duration: 3000 });
    }
  }

  ngOnDestroy() {
    if (this.doctorSubscription) {
      this.doctorSubscription.unsubscribe();
    }
  }
} 