import { AfterViewInit, Component, DestroyRef, inject, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { SelectionModel } from '@angular/cdk/collections';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { aioTableLabels } from 'src/static-data/aio-table-data';
import { DoctorCreateUpdateComponent } from './doctor-create-update/doctor-create-update.component';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { Router, RouterModule } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { DoctorService } from './doctor.service';
import { Doctor, MedicalRecord, Appointment, DoctorShifts, ShiftDto, QueuePatient } from 'src/assets/his.model';
import { DoctorProfileComponent } from './doctor-profile/doctor-profile.component';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'vex-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.scss'],
  animations: [
    fadeInUp400ms,
    stagger40ms
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'outline'
      } as unknown as MatFormFieldDefaultOptions
    }
  ],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatCheckboxModule,
    MatSnackBarModule,
    VexBreadcrumbsComponent,
    DialogModule,
    MatTreeModule,
    CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    CdkStepperModule,
    MatButtonToggleModule,
    MatSliderModule,
    MatStepperModule,
    MatOptionModule,
    VexPageLayoutContentDirective,
    VexPageLayoutHeaderDirective,
    VexPageLayoutComponent,
    DragDropModule,
    RouterModule
  ]
})
export class DoctorComponent implements OnInit, AfterViewInit {
[x: string]: any;
  layoutCtrl = new UntypedFormControl('fullwidth');

  subject$: ReplaySubject<Doctor[]> = new ReplaySubject<Doctor[]>(1);
  data$: Observable<Doctor[]> = this.subject$.asObservable();
  doctors: Doctor[];

  @Input()
  columns: TableColumn<Doctor>[] = [
    { label: this.translate.instant('ID'), property: 'id', type: 'text', visible: true },
    { label: this.translate.instant('NAME'), property: 'fullName', type: 'text', visible: true },
    { label: this.translate.instant('EMAIL'), property: 'email', type: 'text', visible: false },
    { label: this.translate.instant('PHONE'), property: 'phone', type: 'text', visible: false },
    { label: this.translate.instant('PHOTO_URL'), property: 'photoUrl', type: 'image', visible: true, matColumnDef: "image" },
    { label: this.translate.instant('AGE'), property: 'age', type: 'text', visible: false },
    { label: this.translate.instant('YEARS_OF_EXPERIENCE'), property: 'yearsOfExperience', type: 'text', visible: true },
    { label: this.translate.instant('SPECIALIZATION'), property: 'specialization', type: 'text', visible: true },
    { label: this.translate.instant('HOSPITAL_AFFILIATION'), property: 'hospitalAffiliation', type: 'text', visible: true },
    { label: this.translate.instant('IS_SHIFT_TODAY'), property: 'isShiftToday', type: 'text', visible: true },
    { label: this.translate.instant('BUFFER_SIZE'), property: 'bufferSize', type: 'text', visible: true },
    { label: this.translate.instant('ACTIONS'), property: 'actions', type: 'button', visible: true }
  ];

  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<Doctor> | null;
  selection = new SelectionModel<Doctor>(true, []);
  searchCtrl = new UntypedFormControl();

  labels = aioTableLabels;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private dialog: MatDialog,
    private doctorService: DoctorService,
    private router: Router,
    private translate: TranslateService,
    private snackBar: MatSnackBar
  ) {}

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  ngOnInit() {
    this.dataSource = new MatTableDataSource<Doctor>([]);
    this.loadingData();
  }

  loadingData() {
    this.doctorService.getDoctorsShiftToday().subscribe({
      next: (doctors) => {
        console.log('Doctors data:', doctors);
        this.subject$.next(doctors);
        this.doctors = doctors;
        this.dataSource = new MatTableDataSource(doctors);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error: (err) => {
        console.error('Error loading doctors:', err);
        // Fallback to regular getDoctors if today's shifts are not available
        this.doctorService.getDoctors().subscribe({
          next: (allDoctors) => {
            console.log('All doctors fallback:', allDoctors);
            this.subject$.next(allDoctors);
            this.doctors = allDoctors;
            this.dataSource = new MatTableDataSource(allDoctors);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
          },
          error: (error) => {
            console.error('Failed to load doctors:', error);
          }
        });
      }
    });

    this.searchCtrl.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((value) => this.onFilterChange(value));
  }
  loading: boolean = false;
  private readonly destroyRef: DestroyRef = inject(DestroyRef);

  ngAfterViewInit() {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  createDoctor() {
    this.dialog.open(DoctorCreateUpdateComponent, {
      width: '980px',
      maxWidth: '98vw',
      panelClass: 'vex-doctor-dialog',
      disableClose: true,
      autoFocus: false
    }).afterClosed().subscribe((doctor: Doctor) => {
      if (doctor) {
        this.doctors.unshift(doctor);
        this.dataSource.data = this.doctors;
        this.subject$.next(this.doctors);
        this.showToast('Doctor created successfully');
      }
    });
  }

  updateDoctor(doctor: Doctor) {
    this.dialog.open(DoctorCreateUpdateComponent, {
      data: doctor,
      width: '980px',
      maxWidth: '98vw',
      panelClass: 'vex-doctor-dialog',
      disableClose: true,
      autoFocus: false
    }).afterClosed().subscribe((updatedDoctor: Doctor) => {
      if (updatedDoctor) {
        const index = this.doctors.findIndex(d => d.id === updatedDoctor.id);
        if (index > -1) {
          this.doctors[index] = updatedDoctor;
          this.dataSource.data = this.doctors;
          this.subject$.next(this.doctors);
          this.showToast('Doctor updated successfully');
        }
      }
    });
  }

  deleteDoctor(doctor: Doctor) {
    if (!doctor || !doctor.id) {
      this.snackBar.open('Invalid doctor data', 'Close', {
        duration: 3000
      });
      return;
    }

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'DELETE_DOCTOR_TITLE',
        message: 'DELETE_DOCTOR_CONFIRM',
        itemName: doctor.fullName,
        color: 'warn'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loading = true;
        this.doctorService.deleteDoctor(doctor.id).subscribe({
          next: () => {
            // Remove from local arrays and update UI
            const index = this.doctors.findIndex(d => d.id === doctor.id);
            if (index > -1) {
              this.doctors.splice(index, 1);
              this.dataSource.data = this.doctors;
              this.subject$.next(this.doctors);
              this.snackBar.open(this.translate.instant('DOCTOR_DELETED_SUCCESS'), 'Close', {
                duration: 3000
              });
            }
            this.loading = false;
          },
          error: (error) => {
            console.error('Error deleting doctor:', error);
            this.snackBar.open(this.translate.instant('ERROR_DELETING_DOCTOR'), 'Close', {
              duration: 3000
            });
            this.loading = false;
          }
        });
      }
    });
  }

  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  toggleColumnVisibility(column: TableColumn<Doctor>, event: MouseEvent) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }

  goProfile(doctor: Doctor) {
    this.doctorService.setCurrentDoctor(doctor);
    this.router.navigate(['/doctor', doctor.id]);
  }
  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }

  // These methods were referenced in the HTML but not defined in the component
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource?.data.length || 0;
    return numSelected === numRows;
  }

  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    if (this.dataSource) {
      this.selection.select(...this.dataSource.data);
    }
  }

  AddQueue(doctor: Doctor) {
    // Navigate to add queue page or open queue dialog
    if (doctor.shiftToday) {
      this.router.navigate(['/doctor/shift'], { 
        queryParams: { 
          doctorId: doctor.id, 
          shiftId: doctor.shiftToday.id 
        } 
      });
    } else {
      console.warn('Doctor has no active shift today');
    }
  }

  GoProfile(doctor: Doctor) {
    this.goProfile(doctor);
  }

  /**
   * Show a success toast message
   */
  showToast(message: string) {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      horizontalPosition: 'end',
      verticalPosition: 'top'
    });
  }
}

