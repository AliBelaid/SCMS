import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatMenuModule } from '@angular/material/menu';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { NgIf, NgFor } from '@angular/common';
import { DoctorSelectorModule } from '../../shared/components/doctor-selector/doctor-selector.module';
import { DoctorService } from '../doctor.service';
import { Doctor } from 'src/assets/his.model';

@Component({
  selector: 'app-doctor-selector-demo',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatDividerModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTabsModule,
    MatPaginatorModule,
    MatMenuModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    TranslateModule,
    RouterModule,
    MatTableModule,
    MatSortModule,
    NgIf,
    NgFor,
    DoctorSelectorModule
  ],
  templateUrl: './doctor-selector-demo.component.html',
  styleUrls: ['./doctor-selector-demo.component.scss']
})
export class DoctorSelectorDemoComponent implements OnInit {
  // Basic doctor selector
  selectedDoctors: Doctor[] = [];
  
  // Limited doctor selector
  limitedSelectedDoctors: Doctor[] = [];
  
  // Required doctor selector
  requiredSelectedDoctors: Doctor[] = [];
  
  // Disabled doctor selector
  disabledSelectedDoctors: Doctor[] = [];
  isDisabled = true;
  
  // Without avatars doctor selector
  noAvatarSelectedDoctors: Doctor[] = [];

  constructor(private doctorService: DoctorService) {}

  ngOnInit(): void {
    // Load some initial data for the disabled example
    this.doctorService.getDoctors().subscribe({
      next: (doctors) => {
        if (doctors.length > 0) {
          this.disabledSelectedDoctors = [doctors[0]];
        }
      }
    });
  }

  onDoctorsSelected(doctors: Doctor[]): void {
    this.selectedDoctors = doctors;
    console.log('Selected doctors:', doctors);
  }

  onLimitedDoctorsSelected(doctors: Doctor[]): void {
    this.limitedSelectedDoctors = doctors;
    console.log('Limited selected doctors:', doctors);
  }

  onRequiredDoctorsSelected(doctors: Doctor[]): void {
    this.requiredSelectedDoctors = doctors;
    console.log('Required selected doctors:', doctors);
  }

  onDisabledDoctorsSelected(doctors: Doctor[]): void {
    this.disabledSelectedDoctors = doctors;
    console.log('Disabled selected doctors:', doctors);
  }

  onNoAvatarDoctorsSelected(doctors: Doctor[]): void {
    this.noAvatarSelectedDoctors = doctors;
    console.log('No avatar selected doctors:', doctors);
  }

  toggleDisabled(): void {
    this.isDisabled = !this.isDisabled;
  }

  clearAllSelections(): void {
    this.selectedDoctors = [];
    this.limitedSelectedDoctors = [];
    this.requiredSelectedDoctors = [];
    this.noAvatarSelectedDoctors = [];
    // Don't clear the disabled selection
  }
} 