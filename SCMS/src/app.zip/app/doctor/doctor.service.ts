import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, catchError, of, throwError } from 'rxjs';
import { Shift } from '../core/models/shift.model';
import { CalendarEventDto, Doctor, DoctorShift, QueuePatient, QueuePatientToSaved, QueueStatusDto, ShiftDto } from 'src/assets/his.model';
import { CalendarEvent } from 'angular-calendar';
import { map } from 'rxjs/operators';
import { Clinic, DoctorSpecialty, Specialty } from 'src/assets/user';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private apiUrl = environment.apiUrl;
  private currentMemberSubject = new BehaviorSubject<any>(null);
  currentMember$ = this.currentMemberSubject.asObservable();
  private currentDoctorSubject = new BehaviorSubject<Doctor | null>(null);
  public currentDoctor$ = this.currentDoctorSubject.asObservable();
  private editModeEnabled = false;

  constructor(private http: HttpClient) {}

  getClinics(): Observable<Clinic[]> {
    return this.http.get<Clinic[]>(`${this.apiUrl}/clinics`).pipe(
      map((clinics: any[]) => {
        console.log(clinics);
        // Ensure the data is consistent with the expected model in the application
        return clinics.map(c => ({
          ...c,
          id: c.id ,
          // Make sure both name and specialtyName are available for compatibility
          name: c.name || c.specialtyName,
          specialtyName: c.specialtyName || c.name
        }));
      })
    );
  }

  getClinicEvents(clinicId: number): Observable< CalendarEvent<any>[]> {
    return this.http.get< CalendarEvent<any>[]>(`${this.apiUrl}/clinics/${clinicId}/events`);
  }

  getDoctorsByClinic(clinicId: number): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.apiUrl}/clinics/${clinicId}/doctors`);
  }

  getDoctorsBySpecialty(specialtyId: number): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.apiUrl}/specialties/${specialtyId}/doctors`);
  }

  getDoctors(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.apiUrl}/doctors`);
  }

  getSpecialties(): Observable<Specialty[]> {
    return this.http.get<Specialty[]>(`${this.apiUrl}/specialties`).pipe(
      map((specialties: any[]) => {
        // Handle mapping between Specialty and our frontend Specialty model
        return specialties.map(s => {
          return {
            ...s,
            // Ensure we're using the right properties regardless of whether 
            // the API sent data from a Clinic or Specialty entity
            name: s.name || s.specialtyName,
            specialtyName: s.specialtyName || s.name,
          };
        });
      })
    );
  }

  getSpecialtyUsers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/specialties/users`);
  }

  getQueuePatients(clinicId: number): Observable<QueuePatient[]> {
    return this.http.get<QueuePatient[]>(`${this.apiUrl}/clinics/${clinicId}/queue`);
  }

  addToQueue(queuePatient: QueuePatientToSaved): Observable<QueuePatient> {
    return this.http.post<QueuePatient>(`${this.apiUrl}/clinics/queue`, queuePatient);
  }

  getQueueStatus(clinicId: number): Observable<QueueStatusDto> {
    return this.http.get<QueueStatusDto>(`${this.apiUrl}/clinics/${clinicId}/queue-status`);
  }

  createShift(shiftData: Partial<Shift>): Observable<Shift> {
    return this.http.post<Shift>(`${this.apiUrl}/shifts`, shiftData);
  }

  updateShift(shiftId: number, shiftData: Partial<Shift>): Observable<Shift> {
    return this.http.put<Shift>(`${this.apiUrl}/shifts/${shiftId}`, shiftData);
  }

  deleteShift(shiftId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/shifts/${shiftId}`);
  }

  getShiftById(shiftId: number): Observable<ShiftDto> {
    return this.http.get<ShiftDto>(`${this.apiUrl}/doctors/shift-details/${shiftId}`).pipe(
      map(shift => {
        // Ensure all properties have default values and queuePatients is always an array
        return {
          ...shift,
          queuePatients: shift.queuePatients || []
        };
      }),
      catchError(error => {
        console.error('Error fetching shift details:', error);
        // If there was an error, try to get the basic shift info
        return this.http.get<Shift>(`${this.apiUrl}/shifts/${shiftId}`).pipe(
          map(basicShift => {
            // Create a ShiftDto with empty queuePatients
            return {
              id: basicShift.id,
              doctorId: basicShift.doctorId,
              day: basicShift.day,
              start: basicShift.start,
              end: basicShift.end,
              count: basicShift.count,
              finishedPatients: 0,
              waitingPatients: 0,
              currentPatientId: 0,
              currentNumber: 0,
              nextNumber: 0,
              queuePatients: [],
              isActiveQueue: false,
              totalNumbersIssued: 0
            } as ShiftDto;
          }),
          catchError(() => {
            // If even basic shift fails, return minimal object
            return of({
              id: Number(shiftId),
              doctorId: 0,
              day: new Date().toISOString(),
              start: '00:00',
              end: '00:00',
              count: 0,
              queuePatients: [],
              isActiveQueue: false
            } as ShiftDto);
          })
        );
      })
    );
  }

  getDoctorShiftDetails(doctorId: number): Observable<ShiftDto[]> {
    return this.http.get<ShiftDto[]>(`${this.apiUrl}/doctors/doctor-shift-details/${doctorId}`);
  }

  getDoctorsShiftToday(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.apiUrl}/doctors/all-doctors-shift-today`);
  }

  checkDuplicateShift(shift: Partial<Shift>): Observable<boolean> {
    const apiShift = {
      doctorId: shift.doctorId,
      day: shift.day,
      start: shift.start,
      end: shift.end,
      count: shift.count,
      id: shift.id || 0
    };
    return this.http.post<boolean>(`${this.apiUrl}/shifts/check-duplicate`, apiShift);
  }

  mapDoctorsToEvents(doctors: Doctor[]): Observable<CalendarEvent[]> {
    return this.http.post<CalendarEvent[]>(`${this.apiUrl}/doctors/map-to-events`, doctors);
  }

  addShift(shift: Partial<Shift>): Observable<Shift> {
    return this.http.post<Shift>(`${this.apiUrl}/doctors/addShift`, shift);
  }

  currentDoctorDtoSourcesNext(doctor: Doctor): void {
    this.currentMemberSubject.next(doctor);
  }

  getDoctorById(id: string | number): Observable<Doctor> {
    return this.http.get<Doctor>(`${this.apiUrl}/doctors/${id}`);
  }

  addDoctorToClinic(clinicId: number, doctorId: number): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/clinics/${clinicId}/doctor/${doctorId}`, {});
  }

  removeDoctorFromClinic(clinicId: number, doctorId: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/clinics/${clinicId}/doctor/${doctorId}`);
  }

  batchUpdateQueuePatients(patients: QueuePatient[]): Observable<boolean> {
    return this.http.put<boolean>(`${this.apiUrl}/doctors/batch-update`, patients);
  }

  getQueuePatientsByClinic(clinicId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/queue/queue-patients-clinic/${clinicId}`);
  }

  updateQueueStatus(queuePatientId: number, isFinished: boolean): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/clinics/queue/${queuePatientId}`, { isFinished });
  }

  deleteQueuePatient(queuePatientId: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/queue/${queuePatientId}`);
  }

  markRegistrationAsPaid(queuePatientId: number, paymentData: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/queue/payment/${queuePatientId}`, paymentData);
  }

  /**
   * Update a doctor record
   */
  updateDoctor(id:any,doctor: Doctor): Observable<Doctor> {
    // Process the doctor data before sending to the API
    const processedDoctor = {
      ...doctor,
      // Clean up fields that are now removed
      city: '',
      country: ''
    };
    
    return this.http.put<Doctor>(`${this.apiUrl}/doctors/${id}`, processedDoctor);
  }
  
  /**
   * Create a new doctor record
   */
  createDoctor(doctor: any): Observable<Doctor> {
    // Prepare the doctor data in the format expected by the API
    const doctorCreateDto = {
      // Basic user information
      email: doctor.email,
      firstName: doctor.firstName,
      lastName: doctor.lastName,
      password: doctor.password,
      confirmPassword: doctor.confirmPassword,
      phoneNumber: doctor.phoneNumber,
      dateOfBirth: doctor.dateOfBirth,
      gender: doctor.gender || 'male',
      
      // Doctor-specific information
      yearsOfExperience: doctor.yearsOfExperience || 0,
      specialization: doctor.doctor?.specialization || '',
      specializationDetails: doctor.doctor?.specialtyDetails || '',
      hospitalAffiliation: doctor.hospitalAffiliation || '',
      
      // Profile image
      logo: doctor.logo || '',
      
      // Relationships
      doctorSpecialties: (doctor.doctorSpecialties || []).map(specialty => ({
        specialtyId: Number(specialty.specialtyId)
      })),
      
      doctorClinics: (doctor.doctorClinics || []).map(clinic => ({
        clinicId: Number(clinic.clinicId)
      })),
      
      shifts: (doctor.shifts || []).map(shift => ({
        clinicId: shift.clinicId,
        day: shift.day,
        start: shift.start,
        end: shift.end,
        count: shift.count
      }))
    };
    
    return this.http.post<Doctor>(`${this.apiUrl}/doctors`, doctorCreateDto);
  }
  
  /**
   * Generate a safe username from first and last name
   * This handles Unicode characters by creating a safer alternative
   */
   generateSafeUsername(firstName: string, lastName: string): string {
    // Create base from first and last name
    const baseUsername = `${firstName || ''}_${lastName || ''}`.trim();
    
    // Create a fallback if the name is completely empty
    if (!baseUsername || baseUsername === '_') {
      return `doctor_${new Date().getTime()}`;
    }
    
    // Replace spaces and special characters
    const safeUsername = baseUsername
      .replace(/\s+/g, '_')
      .replace(/[^\w\-\.]/g, '');
      
    // Add timestamp to ensure uniqueness
    return `${safeUsername}_${new Date().getTime()}`;
  }

  setCurrentDoctor(doctor: Doctor | null) {
    this.currentDoctorSubject.next(doctor);
  }

  setEditModeEnabled(enabled: boolean): void {
    this.editModeEnabled = enabled;
  }

  isEditModeEnabled(): boolean {
    return this.editModeEnabled;
  }

  currentDoctorSourcesNext(doctor: Doctor): void {
    this.currentDoctorSubject.next(doctor);
  }

  deleteDoctor(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/doctors/${id}`);
  }

  /**
   * Upload a doctor's photo using base64 image string
   */
  uploadPhoto(id: number, imageBase64: string): Observable<{ photoUrl: string }> {
    return this.http.post<{ photoUrl: string }>(`${this.apiUrl}/doctors/${id}/photo`, { photo: imageBase64 });
  }

  getDoctorShiftWithPatients(shiftId: number): Observable<ShiftDto> {
    return this.getShiftById(shiftId).pipe(
      map((shift: ShiftDto) => {
        // Ensure queuePatients is always an array
        shift.queuePatients = shift.queuePatients || [];
        
        // Add additional patient data if needed
        if (shift.queuePatients.length > 0) {
          // Map any additional properties if needed
          shift.queuePatients = shift.queuePatients.map(patient => ({
            ...patient,
            // Set default values for any missing properties
            isFinished: patient.isFinished || false,
            meetingType: patient.meetingType || 0
          }));
        }
        
        return shift;
      })
    );
  }

  getShiftWithFallback(shiftId: number): Observable<ShiftDto> {
    return this.http.get<ShiftDto>(`${this.apiUrl}/doctors/shift-details/${shiftId}`).pipe(
      catchError(error => {
        if (error.status === 404) {
          // If shift not found or has no queue patients, create a default shift object
          console.log('Shift not found or has no queue patients, creating default shift');
          return this.http.get<Shift>(`${this.apiUrl}/shifts/${shiftId}`).pipe(
            map(basicShift => {
              // Create a default ShiftDto from the basic shift data
              return {
                id: basicShift.id,
                doctorId: basicShift.doctorId,
                day: basicShift.day,
                start: basicShift.start,
                end: basicShift.end,
                count: basicShift.count,
                finishedPatients: 0,
                waitingPatients: 0,
                currentPatientId: 0,
                currentNumber: 0,
                nextPatientId: 0,
                nextNumber: 0,
                queuePatients: [],
                isActiveQueue: false,
                totalNumbersIssued: 0
              } as ShiftDto;
            }),
            catchError(innerError => {
              console.error('Error loading basic shift data:', innerError);
              // If even the basic shift data can't be loaded, return a minimal shift object
              return of({
                id: Number(shiftId),
                doctorId: 0,
                day: new Date().toISOString(),
                start: '00:00',
                end: '00:00',
                count: 0,
                queuePatients: [],
                isActiveQueue: false
              } as ShiftDto);
            })
          );
        }
        // For other errors, rethrow
        return throwError(() => error);
      }),
      map(shift => {
        // Ensure queuePatients is always an array
        return {
          ...shift,
          queuePatients: shift.queuePatients || []
        };
      })
    );
  }

}
