import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { Doctor } from 'src/assets/his.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private apiUrl = `${environment.apiUrl}/doctors`;
  private currentDoctorSubject = new BehaviorSubject<Doctor | null>(null);
  currentDoctor$ = this.currentDoctorSubject.asObservable();

  constructor(private http: HttpClient) {}

  getDoctorById(id: string | number): Observable<Doctor> {
    return this.http.get<Doctor>(`${this.apiUrl}/${id}`);
  }

  setCurrentDoctor(doctor: Doctor) {
    this.currentDoctorSubject.next(doctor);
  }

  clearCurrentDoctor() {
    this.currentDoctorSubject.next(null);
  }

  updateDoctor(id: string | number, doctor: Partial<Doctor>): Observable<Doctor> {
    return this.http.patch<Doctor>(`${this.apiUrl}/${id}`, doctor);
  }

  getDoctorShifts(id: string | number): Observable<Doctor['shifts']> {
    return this.http.get<Doctor['shifts']>(`${this.apiUrl}/${id}/shifts`);
  }

  getDoctorClinics(id: string | number): Observable<Doctor['clinicDoctorAssignments']> {
    return this.http.get<Doctor['clinicDoctorAssignments']>(`${this.apiUrl}/${id}/clinics`);
  }
} 