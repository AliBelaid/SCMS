import { Routes } from '@angular/router';
import { DoctorComponent } from './doctor.component';
import { RoleGuard } from '../core/guards/role.guard';
import { AuthGuard } from '../guards/auth.guard';
import { DoctorSelectorDemoComponent } from './doctor-selector-demo/doctor-selector-demo.component';
import { DoctorProfileGuard } from '../guards/doctor-profile.guard';

export const DOCTOR_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./doctor.component').then(m => m.DoctorComponent),
    canActivate: [RoleGuard],
    data: {
      roles: ['Admin', 'Reception']
    }
  },
  
  // {
  //   path: 'create',
  //   loadComponent: () => import('./doctor-create-update/doctor-create-update.component')
  //     .then(m => m.DoctorCreateUpdateComponent),
  //   canActivate: [RoleGuard],
  //   data: {
  //     roles: ['Admin']
  //   }
  // },

      {
        path: 'queue/:id',
        loadComponent: () => import('./queue/doctor-queue.component')
          .then(m => m.DoctorQueueComponent)
      },

  {
    path: ':id',
    loadComponent: () => import('./doctor-profile/new-doctor-profile/new-doctor-profile.component')
      .then(m => m.NewDoctorProfileComponent),
    canActivate: [AuthGuard, DoctorProfileGuard],
    children: [
      {
        path: '',
        redirectTo: 'details',
        pathMatch: 'full'
      },
      {
        path: 'details',
        loadComponent: () => import('./doctor-profile/user/doctor-detalis/doctor-detalis.component')
          .then(m => m.DoctorDetalisComponent)
      },
      {
        path: 'queue',
        loadComponent: () => import('./doctor-profile/user/contacts/contacts-table/contacts-table.component')
          .then(m => m.ContactsTableComponent)
      },
  



      {
        path: 'schedule',
        loadComponent: () => import('./doctor-shift/doctor-shift.component')
          .then(m => m.DoctorShiftComponent)
      },
      {
        path: 'balance',
        loadComponent: () => import('./doctor-balance/doctor-balance.component')
          .then(m => m.DoctorBalanceComponent),
        canActivate: [RoleGuard],
        data: {
          roles: ['Admin', 'Finance', 'Doctor']
        }
      },
      {
        path: 'reports',
        loadComponent: () => import('./doctor-reports/doctor-reports.component')
          .then(m => m.DoctorReportsComponent),
        canActivate: [RoleGuard],
        data: {
          roles: ['Admin', 'Doctor']
        }
      },
      {
        path: 'settings',
        loadComponent: () => import('./doctor-settings/doctor-settings.component')
          .then(m => m.DoctorSettingsComponent),
        canActivate: [RoleGuard],
        data: {
          roles: ['Admin', 'Doctor']
        }
      }
    ]
  },
  // {
  //   path: 'shift/:id',
  //   loadComponent: () => import('./doctor-shift/doctor-shift.component')
  //     .then(m => m.DoctorShiftComponent),
  //   canActivate: [RoleGuard],
  //   data: {
  //     roles: ['Admin', 'Doctor', 'Hospital']
  //   }
  // },
  // {
  //   path: 'doctor-selector-demo',
  //   component: DoctorSelectorDemoComponent,
  //   data: {
  //     title: 'Doctor Selector Demo',
  //     toolbarShadowEnabled: true
  //   }
  // }
];

