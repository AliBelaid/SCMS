import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatRadioModule } from '@angular/material/radio';
import { MatDividerModule } from '@angular/material/divider';
import { MatTabsModule } from '@angular/material/tabs';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { MatTableModule } from '@angular/material/table';
import { DoctorService } from '../doctor.service';
import { Clinic } from 'src/assets/user';
import { Shift } from 'src/app/core/models/shift.model';
import { Observable, forkJoin, of } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';
import { MatTooltipModule } from '@angular/material/tooltip';

// Define a more specific shift interface for our form
export interface DoctorShift extends Partial<Shift> {
  clinicId: number;
  day: string;
  start: string;
  end: string;
  count: number;
}

@Component({
  selector: 'vex-doctor-create-update',
  templateUrl: './doctor-create-update.component.html',
  styleUrls: ['./doctor-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatDividerModule,
    MatTabsModule,
    MatTableModule,
    MatOptionModule,
    MatRippleModule,
    MatTooltipModule
  ],
  // Set the host styles to increase the width 
  host: {
    class: 'vex-doctor-dialog'
  }
})
export class DoctorCreateUpdateComponent implements OnInit {
  // Forms
  form: FormGroup;
  shiftForm: FormGroup;
  
  // Component state
  mode: 'create' | 'update';
  loading = false;
  shiftError: string = '';
  apiError: string = '';
  
  // Data collections
  availableSpecialties: any[] = [];
  availableClinics: Clinic[] = [];
  availableDays: string[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  shifts: DoctorShift[] = [];
  
  // Display columns for the shifts table
  displayedColumns: string[] = ['clinic', 'day', 'start', 'end', 'count', 'actions'];

  constructor(
    @Inject(MAT_DIALOG_DATA) public defaults: any,
    private dialogRef: MatDialogRef<DoctorCreateUpdateComponent>,
    private fb: FormBuilder,
    public translate: TranslateService,
    private doctorService: DoctorService
  ) {
    // Initialize component
    this.initializeComponent();
  }

  ngOnInit() {
    this.loadData();
  }

  /**
   * Initialize component state and forms
   */
   initializeComponent() {
    // Set mode based on if we have defaults
    this.mode = this.defaults ? 'update' : 'create';
    
    // Create main form
    this.createMainForm();
    
    // Create shift form
    this.createShiftForm();
  }

  /**
   * Create the main form with validation
   */
   createMainForm() {
    // Simplified form with email OR phone requirement
    this.form = this.fb.group({
      id: [this.defaults?.id || 0],
      email: ['', [Validators.email]],
      phoneNumber: [''],
      logo: [''],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      dateOfBirth: [null],
      specialties: [[]],
      password: ['', this.mode === 'create' ? Validators.required : null],
      confirmPassword: ['', this.mode === 'create' ? Validators.required : null],
      hospitalAffiliation: [''],
      doctor: this.fb.group({
        yearsOfExperience: [0],
        specialization: [''],
        specialtyDetails: ['']
      })
    }, {
      validators: this.mode === 'create' ? [this.passwordMatchValidator, this.emailOrPhoneValidator] : null
    });
    
    // Set form values for update mode
    if (this.mode === 'update' && this.defaults) {
      // When updating, we need to set the form values from the doctor data
      this.form.patchValue(this.defaults);
      
      // If there's a logo, ensure it's loaded properly
      if (this.defaults.logo) {
        this.form.get('logo').setValue(this.defaults.logo);
      }
    }
  }

  /**
   * Password match validator
   */
  passwordMatchValidator(g: FormGroup) {
    const password = g.get('password').value;
    const confirmPassword = g.get('confirmPassword').value;
    
    return password === confirmPassword ? null : { mismatch: true };
  }

  /**
   * Custom validator to require either email or phone number
   */
  emailOrPhoneValidator(control: any) {
    const email = control.get('email')?.value;
    const phoneNumber = control.get('phoneNumber')?.value;
    
    if (!email && !phoneNumber) {
      return { emailOrPhoneRequired: true };
    }
    
    return null;
  }

  /**
   * Create the shift form with validation
   */
   createShiftForm() {
    this.shiftForm = this.fb.group({
      clinicId: [null, Validators.required],
      day: ['', Validators.required],
      start: ['', Validators.required],
      end: ['', Validators.required],
      count: [1, [Validators.required, Validators.min(1)]]
    });
  }

  /**
   * Load all required data for the form
   */
  loadData() {
    this.loading = true;
    
    // Load specialties and clinics in parallel
    forkJoin({
      specialties: this.doctorService.getSpecialties().pipe(
        catchError(error => {
          console.error('Error loading specialties', error);
          return of([]);
        })
      ),
      clinics: this.doctorService.getClinics().pipe(
        catchError(error => {
          console.error('Error loading clinics', error);
          return of([]);
        })
      )
    }).pipe(
      finalize(() => this.loading = false)
    ).subscribe(results => {
      // Set specialties
      this.availableSpecialties = results.specialties;
      
      // Set clinics
      this.availableClinics = results.clinics;
      
      // Set selected specialties if in update mode
      if (this.mode === 'update' && this.defaults.doctorSpecialties) {
        const selectedSpecialties = this.defaults.doctorSpecialties.map(s => s.specialtyId);
        this.form.get('specialties').setValue(selectedSpecialties);
      }
      
      // Load shifts if in update mode
      if (this.mode === 'update' && this.defaults.shifts) {
        this.shifts = [...this.defaults.shifts];
      }
    });
  }
  
  /**
   * Add a new shift to the shifts array
   */
  addShift() {
    if (this.shiftForm.valid) {
      const newShift = this.shiftForm.value as DoctorShift;
      
      // Clear previous error
      this.shiftError = '';
      
      // Check for overlapping shifts
      if (this.isOverlappingShift(newShift)) {
        // Show error message
        this.shiftError = this.translate.instant('SHIFT_OVERLAP_ERROR');
        return;
      }
      
      // Check if start time is before end time
      const startMinutes = this.timeStringToMinutes(newShift.start);
      const endMinutes = this.timeStringToMinutes(newShift.end);
      
      if (startMinutes >= endMinutes) {
        this.shiftError = this.translate.instant('END_TIME_MUST_BE_AFTER_START_TIME');
        return;
      }
      
      this.shifts.push(newShift);
      
      // Reset the form
      this.shiftForm.reset({ count: 1 });
    }
  }
  
  /**
   * Check if a new shift overlaps with existing shifts
   */
  isOverlappingShift(newShift: DoctorShift): boolean {
    return this.shifts.some(existingShift => {
      // Check if shifts are on the same day and in the same clinic
      if (existingShift.day === newShift.day && existingShift.clinicId === newShift.clinicId) {
        // Convert time strings to Date objects for comparison
        const newStart = this.timeStringToMinutes(newShift.start);
        const newEnd = this.timeStringToMinutes(newShift.end);
        const existingStart = this.timeStringToMinutes(existingShift.start);
        const existingEnd = this.timeStringToMinutes(existingShift.end);
        
        // Check for overlap: new start time is before existing end time AND new end time is after existing start time
        return (newStart < existingEnd && newEnd > existingStart);
      }
      return false;
    });
  }
  
  /**
   * Convert a time string (HH:MM) to minutes for easier comparison
   */
  timeStringToMinutes(timeStr: string): number {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  }
  
  /**
   * Remove a shift from the shifts array
   */
  handleRemoveShift(index: number) {
    if (index >= 0 && index < this.shifts.length) {
      this.shifts.splice(index, 1);
    }
  }

  /**
   * Save the doctor (create or update)
   */
  save() {
    if (!this.form.valid) {
      // Mark all fields as touched to trigger validation
      this.markFormGroupTouched(this.form);
      
      // Check for email or phone number requirement if in create mode
      if (this.mode === 'create' && this.form.hasError('emailOrPhoneRequired')) {
        this.apiError = this.translate.instant('EITHER_EMAIL_OR_PHONE_REQUIRED');
        return;
      }
      
      this.apiError = this.translate.instant('PLEASE_CORRECT_FORM_ERRORS');
      return;
    }

    if (this.mode === 'create') {
      this.createDoctor();
    } else {
      this.updateDoctor();
    }
  }

  /**
   * Create a new doctor
   */
   createDoctor() {
    const doctor = this.prepareFormData();
    
    // Check if form data preparation failed
    if (!doctor) {
      return;
    }
    
    // Clear any previous errors
    this.apiError = '';
    this.loading = true;
    
    this.doctorService.createDoctor(doctor).pipe(
      finalize(() => this.loading = false)
    ).subscribe({
      next: (response) => {
        // Close the dialog and pass the created doctor back to the caller
        this.dialogRef.close(response);
      },
      error: (err) => {
        console.error('Error creating doctor', err);
        this.apiError = err.error?.message || 
                        err.error?.title || 
                        err.error?.errors?.join(', ') ||
                        this.translate.instant('ERROR_CREATING_DOCTOR');
      }
    });
  }

  /**
   * Update an existing doctor
   */
   updateDoctor() {
    const doctor = this.prepareFormData();
    doctor.id = this.defaults.id;
    
    // Clear any previous errors
    this.apiError = '';
    this.loading = true;
    
    this.doctorService.updateDoctor(doctor.id,doctor).pipe(
      finalize(() => this.loading = false)
    ).subscribe({
      next: (response) => {
        // Close the dialog and pass the updated doctor back to the caller
        this.dialogRef.close(response);
      },
      error: (err) => {
        console.error('Error updating doctor', err);
        this.apiError = err.error?.message || 
                       err.error?.title || 
                       this.translate.instant('ERROR_UPDATING_DOCTOR');
      }
    });
  }
  
  /**
   * Prepare form data for submission
   */
   prepareFormData() {
    const formData = this.form.value;
    
    // Ensure proper password fields for create mode
    if (this.mode === 'create' && (!formData.password || !formData.confirmPassword)) {
      this.apiError = this.translate.instant('PASSWORDS_REQUIRED');
      return null;
    }

    // Validate passwords match for create mode
    if (this.mode === 'create' && formData.password !== formData.confirmPassword) {
      this.apiError = this.translate.instant('PASSWORDS_DO_NOT_MATCH');
      return null;
    }
    
    // Set default image if none provided
    if (!formData.logo) {
      formData.logo = 'assets/img/Medical/user.jpg';
    }
    
    // Format specialties
    formData.doctorSpecialties = (formData.specialties || []).map(specialtyId => ({
      specialtyId: Number(specialtyId)
    }));
    
    // Get unique clinic IDs from shifts
    const uniqueClinicIds = [...new Set(this.shifts.map(shift => shift.clinicId))];
    
    // Format clinics from shifts
    formData.doctorClinics = uniqueClinicIds.map(clinicId => ({
      clinicId: Number(clinicId)
    }));
    
    // Add shifts
    formData.shifts = this.shifts.map(shift => ({
      clinicId: shift.clinicId,
      day: shift.day,
      start: shift.start,
      end: shift.end,
      count: shift.count
    }));
    
    // Set default role and gender
    if (this.mode === 'create') {
      formData.gender = 'male'; // Set default gender
    }
    
    // Clean up redundant data
    delete formData.specialties;
    
    return formData;
  }

  /**
   * Handle file selection
   */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const base64Image = e.target.result;
        this.form.get('logo').setValue(base64Image);
        
        // Clear the input value to allow selecting the same file again
        input.value = '';
      };
      reader.readAsDataURL(file);
    }
  }

  /**
   * Get the name of a clinic by ID
   */
  getClinicName(clinicId: number): string {
    const clinic = this.availableClinics.find(c => c.id === clinicId);
    return clinic ? clinic.name : '';
  }
  
  /**
   * Check if passwords match
   */
  passwordsMatch(): boolean {
    const password = this.form.get('password').value;
    const confirmPassword = this.form.get('confirmPassword').value;
    return password === confirmPassword;
  }
  
  /**
   * Helper to check if create mode
   */
  isCreateMode(): boolean {
    return this.mode === 'create';
  }

  /**
   * Helper to check if update mode
   */
  isUpdateMode(): boolean {
    return this.mode === 'update';
  }
  
  /**
   * Mark all controls in a form group as touched
   */
   markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}

