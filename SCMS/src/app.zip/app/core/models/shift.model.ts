import { QueuePatient } from 'src/assets/his.model';

export interface Shift {
  id: number;
  doctorId: number;
  clinicId: number;
  day: string;
  start: string;
  end: string;
  count: number;
  queuePatients: QueuePatient[];
  totalNumbersIssued?: number;
} 