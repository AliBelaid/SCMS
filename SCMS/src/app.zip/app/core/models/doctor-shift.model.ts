// import { Doctor } from 'src/assets/his.model';

// export interface DoctorShift {
//   id: number;
//   doctorId: number;
//   doctor: Doctor;
//   day: string;
//   start: string;
//   end: string;
//   count: number;
//   isActive: boolean;
//   finishedPatients?: number;
//   waitingPatients?: number;
//   currentPatientId?: number;
//   currentNumber?: number;
//   totalNumbersIssued?: number;
//   nextPatientId?: number;
//   nextNumber?: number;
// } 