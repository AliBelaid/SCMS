import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../assets/environments/environment';

interface MedicalTechnician {
  id: number;
  displayName?: string;
  firstName: string;
  lastName: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  /**
   * Get all medical technicians
   */
  getMedicalTechnicians(): Observable<MedicalTechnician[]> {
    return this.http.get<MedicalTechnician[]>(`${this.apiUrl}/staff/medical-technicians`);
  }

  /**
   * Get a medical technician by ID
   * @param technicianId The technician ID
   */
  getTechnicianDetails(technicianId: number): Observable<MedicalTechnician> {
    return this.http.get<MedicalTechnician>(`${this.apiUrl}/staff/${technicianId}`);
  }
} 