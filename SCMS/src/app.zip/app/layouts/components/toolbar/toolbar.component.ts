import {
  Component,
  DestroyRef,
  ElementRef,
  HostBinding,
  inject,
  OnInit
} from '@angular/core';
import { VexLayoutService } from '@vex/services/vex-layout.service';
import { VexConfigService } from '@vex/config/vex-config.service';
import { filter, map, startWith, switchMap, take } from 'rxjs/operators';
import { NavigationService } from '../../../core/navigation/navigation.service';
import { NavigationLoaderService } from '../../../core/navigation/navigation-loader.service';
import { VexPopoverService } from '@vex/components/vex-popover/vex-popover.service';
import { MegaMenuComponent } from './mega-menu/mega-menu.component';
import { Observable, of } from 'rxjs';
import { NavigationComponent } from '../navigation/navigation.component';
import { ToolbarUserComponent } from './toolbar-user/toolbar-user.component';
import { ToolbarNotificationsComponent } from './toolbar-notifications/toolbar-notifications.component';
import { NavigationItemComponent } from '../navigation/navigation-item/navigation-item.component';
import { MatMenuModule } from '@angular/material/menu';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { AsyncPipe, NgClass, NgFor, NgIf } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { NavigationItem } from '../../../core/navigation/navigation-item.interface';
import { checkRouterChildsData } from '@vex/utils/check-router-childs-data';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { UserService } from 'src/app/user/user.service';

@Component({
  selector: 'vex-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss'],
  standalone: true,
  imports: [
    MatButtonModule,
    MatIconModule,
    NgIf,
    RouterLink,
    MatMenuModule,
    NgClass,
    NgFor,
    NavigationItemComponent,
    ToolbarNotificationsComponent,
    ToolbarUserComponent,
    NavigationComponent,
    AsyncPipe ,
    TranslateModule
  ]
})
export class ToolbarComponent implements OnInit {
  @HostBinding('class.shadow-b')
  showShadow: boolean = false;

  navigationItems$: Observable<NavigationItem[]> =
    this.navigationService.items$;
    //navigationItems = this.navigationService.items$.pipe(take(1)).subscribe((rep)=> rep);
  isHorizontalLayout$: Observable<boolean> = this.configService.config$.pipe(
    map((config) => config.layout === 'horizontal')
  );
  isVerticalLayout$: Observable<boolean> = this.configService.config$.pipe(
    map((config) => config.layout === 'vertical')
  );
  isNavbarInToolbar$: Observable<boolean> = this.configService.config$.pipe(
    map((config) => config.navbar.position === 'in-toolbar')
  );
  isNavbarBelowToolbar$: Observable<boolean> = this.configService.config$.pipe(
    map((config) => config.navbar.position === 'below-toolbar')
  );
  userVisible$: Observable<boolean> = this.configService.config$.pipe(
    map((config) => config.toolbar.user.visible)
  );
  title$: Observable<string> = this.configService.select(
    (config) => config.sidenav.title
  );

  isDesktop$: Observable<boolean> = this.layoutService.isDesktop$;
  megaMenuOpen$: Observable<boolean> = of(false);
  private readonly destroyRef: DestroyRef = inject(DestroyRef);



  changeLanguage(lang: string) {
    this.translate.use(lang);
    localStorage.setItem('userLang', lang);
    this.selectedLang = lang;
    this.selectedLang === 'ar' ? this.configService.updateConfig({ direction: 'rtl' }) : this.configService.updateConfig({ direction: 'ltr' });
    
    // Set default language and use it
    this.translate.setDefaultLang(this.selectedLang);
    this.translate.use(this.selectedLang);
    
    // Wait for translation to load, then reload navigation items
    this.translate.get('APPLICATIONS').subscribe(() => {
      this.navigationLoaderService.updateItems(this.loadMenuItems());
    });
  }
  selectedLang = localStorage.getItem('userLang') || 'ar';


  constructor(
    private readonly layoutService: VexLayoutService,
    private readonly configService: VexConfigService,
    private readonly navigationService: NavigationService,
    private readonly navigationLoaderService: NavigationLoaderService,
    private readonly popoverService: VexPopoverService,
    private readonly router: Router,
    public user: UserService,
    public translate: TranslateService
  ) {
    // Initialize language from localStorage
    const savedLang = localStorage.getItem('userLang') || 'ar';
    this.selectedLang = savedLang;
    this.translate.setDefaultLang(savedLang);
    this.translate.use(savedLang);
  }

  ngOnInit() {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        startWith(null),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(() => {
        this.showShadow = checkRouterChildsData(
          this.router.routerState.root.snapshot,
          (data) => data.toolbarShadowEnabled ?? false
        );
      });
  }

  openQuickpanel(): void {
    this.layoutService.openQuickpanel();
  }

  openSidenav(): void {
    this.layoutService.openSidenav();
  }

  openMegaMenu(origin: ElementRef | HTMLElement): void {
    this.megaMenuOpen$ = of(
      this.popoverService.open({
        content: MegaMenuComponent,
        origin,
        offsetY: 12,
        position: [
          {
            originX: 'start',
            originY: 'bottom',
            overlayX: 'start',
            overlayY: 'top'
          },
          {
            originX: 'end',
            originY: 'bottom',
            overlayX: 'end',
            overlayY: 'top'
          }
        ]
      })
    ).pipe(
      switchMap((popoverRef) => popoverRef.afterClosed$.pipe(map(() => false))),
      startWith(true)
    );
  }

  openSearch(): void {
    this.layoutService.openSearch();
  }



  loadMenuItems():NavigationItem[] {
    return      [
      {
        type: 'subheading',
        label: this.translate.instant('APPLICATIONS'),
        children: [
          {
            type: 'link',
            label: this.translate.instant('DOCTORS'),
            route: '/doctor',
            icon: 'mat:medical_services',
            roles: ['Admin', 'Reception' ,'MedicalTechnician']
          },
          {
            type: 'link',
            label: this.translate.instant('PATIENTS'),
            route: '/patients',
            icon: 'mat:people',
            roles: ['Admin', 'Doctor', 'Reception' ,'MedicalTechnician']
          },
          {
            type: 'link',
            label: this.translate.instant('RECEPTION'),
            route: '/reception',
            icon: 'mat:desk',
            roles: ['Admin', 'Reception' ,'MedicalTechnician']
          },
          {
            type: 'link',
            label: this.translate.instant('Pricing'),
            route: '/pricing',
            icon: 'mat:payment',
            roles: ['Admin', 'Finance' ,'Reception']
          },
          {
            type: 'link',
            label: this.translate.instant('Payments'),
            route: '/payments',
            icon: 'mat:credit_card',
            roles: ['Admin', 'Finance', 'Reception']
          },
          {
            type: 'link',
            label: this.translate.instant('SETTINGS'),
            route: '/settings',
            icon: 'mat:settings',
            roles: ['Admin', 'Finance', 'Reception']
          },
          {
            type: 'dropdown',
            label: this.translate.instant('TREASURY'),
            icon: 'mat:account_balance',
            roles: ['Admin', 'Finance'],
            children: [
              {
                type: 'link',
                label: this.translate.instant('DASHBOARD'),
                route: '/treasury/dashboard',
                icon: 'mat:dashboard',
                roles: ['Admin', 'Finance']
              },
              {
                type: 'link',
                label: this.translate.instant('DOCTOR_BALANCE'),
                route: '/treasury/doctor-balance',
                icon: 'mat:payments',
                roles: ['Admin', 'Finance', 'Doctor']
              },
              {
                type: 'link',
                label: this.translate.instant('DOCTOR_PAYOUTS'),
                route: '/treasury/doctor-payouts',
                icon: 'mat:account_balance_wallet',
                roles: ['Admin', 'Finance']
              },
              {
                type: 'link',
                label: this.translate.instant('EXPENSES'),
                route: '/treasury/expenses',
                icon: 'mat:receipt_long',
                roles: ['Admin', 'Finance']
              },
              {
                type: 'link',
                label: this.translate.instant('SETTLEMENTS'),
                route: '/treasury/settlements',
                icon: 'mat:currency_exchange',
                roles: ['Admin', 'Finance']
              },
              {
                type: 'link',
                label: this.translate.instant('BACKUP_QUEUE'),
                route: '/treasury/backup-queue',
                icon: 'mat:backup',
                roles: ['Admin', 'Finance']
              }
            ]
          },
          {
            type: 'link',
            label: this.translate.instant('MEDICAL_RECORDS'),
            route: '/queues',
            icon: 'mat:folder',
            roles: ['Admin', 'Doctor', 'Reception', 'MedicalTechnician'],
            routerLinkActiveOptions: { exact: false }
          },
          {
            type: 'link',
            label: this.translate.instant('PHARMACY'),
            route: '/pharmacy',
            icon: 'mat:local_pharmacy',
            roles: ['Admin', 'Pharmacy']
          },
          {
            type: 'link',
            label: this.translate.instant('Admin'),
            route: '/admin',
            icon: 'mat:admin_panel_settings',
            roles: ['Admin']
          } 
        ]
      },
      {
        type: 'subheading',
        label: this.translate.instant('SPECIALTIES'),
        children: [
          {
            type: 'link',
            label: this.translate.instant('CLINIC_MANAGEMENT'),
            route: '/specialties',
            icon: 'mat:medical_services',
            roles: ['Admin', 'Hospital']
          },
          {
            type: 'link',
            label: this.translate.instant('CLINIC_CALENDAR'),
            route: '/specialties/calendar',
            icon: 'mat:calendar_today',
            roles: ['Admin', 'Hospital', 'Reception']
          },
          {
            type: 'link',
            label: this.translate.instant('SHIFT_MANAGEMENT'),
            route: '/specialties/shifts',
            icon: 'mat:schedule',
            roles: ['Admin', 'Hospital', 'Reception']
          },
          {
            type: 'link',
            label: this.translate.instant('CLINIC_RECORDS'),
            route: '/specialties/records',
            icon: 'mat:folder',
            roles: ['Admin', 'Hospital']
          }
        ]
      },
      {
        type: 'subheading',
        label: this.translate.instant('HOSPITAL_MANAGEMENT'),
        roles: ['Admin', 'Hospital'],
        children: [
          {
            type: 'link',
            label: this.translate.instant('DEPARTMENTS'),
            route: '/departments',
            icon: 'mat:business',
            roles: ['Admin', 'Hospital']
          },
          {
            type: 'link',
            label: this.translate.instant('ROOMS'),
            route: '/rooms',
            icon: 'mat:meeting_room',
            roles: ['Admin', 'Hospital']
          },
          {
            type: 'link',
            label: this.translate.instant('STAFF'),
            route: '/staff',
            icon: 'mat:badge',
            roles: ['Admin', 'Hospital']
          },
          {
            type: 'link',
            label: this.translate.instant('EQUIPMENT'),
            route: '/equipment',
            icon: 'mat:medical_services',
            roles: ['Admin', 'Hospital']
          },
          {
            type: 'link',
            label: this.translate.instant('INVENTORY'),
            route: '/inventory',
            icon: 'mat:inventory',
            roles: ['Admin', 'Hospital']
          },
          {
            type: 'link',
            label: this.translate.instant('APPOINTMENTS'),
            route: '/appointments',
            icon: 'mat:event',
            roles: ['Admin', 'Hospital', 'Reception']
          },
          {
            type: 'link',
            label: this.translate.instant('BILLING'),
            route: '/billing',
            icon: 'mat:receipt',
            roles: ['Admin', 'Hospital', 'Finance']
          },
          {
            type: 'link',
            label: this.translate.instant('REPORTS'),
            route: '/reports',
            icon: 'mat:assessment',
            roles: ['Admin', 'Hospital']
          }
        ]
      },
      {
        type: 'subheading',
        label: this.translate.instant('SETTINGS'),
        children: [
          {
            type: 'link',
            label: this.translate.instant('USER_PROFILE'),
            route:   '/user',
            icon: 'mat:person',
            roles: ['Admin',  'Finance', 'Pharmacy', 'Hospital']
          },
          {
            type: 'link',
            label: this.translate.instant('SYSTEM_SETTINGS'),
            route: '/system-settings',
            icon: 'mat:settings',
            roles: ['Admin']
          },
          {
            type: 'link',
            label: this.translate.instant('PRINTER_SETTINGS'),
            route: '/printer-settings',
            icon: 'mat:print',
            roles: ['Admin']
          }
        ]
      }
    ];
  


    }
  }


