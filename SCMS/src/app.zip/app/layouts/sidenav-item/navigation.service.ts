// Add the service pricing test page to the navigation
this.items = [
  // ... existing items ...
  
  {
    type: 'link',
    route: '/service-pricing/service-category-test',
    icon: 'receipt',
    label: 'MEDICAL_SERVICE_MANAGEMENT',
    badge: {
      value: 'NEW'
    }
  },
  
  // ... existing items ...
]; 