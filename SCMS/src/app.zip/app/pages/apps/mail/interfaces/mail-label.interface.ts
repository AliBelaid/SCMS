export interface MailLabel {
  label: string;
  classes: string[];
}
