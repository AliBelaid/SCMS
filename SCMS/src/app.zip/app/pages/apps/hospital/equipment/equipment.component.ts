import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SelectionModel } from '@angular/cdk/collections';
import { EquipmentCreateUpdateComponent } from './equipment-create-update/equipment-create-update.component';
import { EquipmentService } from './equipment.service';
import { Equipment } from './equipment.model';
import { MatCardModule } from '@angular/material/card';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-equipment',
  templateUrl: './equipment.component.html',
  styleUrls: ['./equipment.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatMenuModule,
    MatTooltipModule,
    MatDialogModule,MatCardModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    MatCheckboxModule
  ]
})
export class EquipmentComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  dataSource: MatTableDataSource<Equipment>;
  selection = new SelectionModel<Equipment>(true, []);
  searchCtrl = new UntypedFormControl();
  displayedColumns: string[] = [
    'select',
    'id',
    'name',
    'type',
    'model',
    'serialNumber',
    'status',
    'location',
    'department',
    'actions'
  ];

  constructor(
    private dialog: MatDialog,
    private equipmentService: EquipmentService,
    private translate: TranslateService,
    private snackBar: MatSnackBar
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit() {
    this.loadEquipment();
    this.setupSearch();
  }

  loadEquipment() {
    this.equipmentService.getEquipment().subscribe(equipment => {
      this.dataSource.data = equipment;
    });
  }

  setupSearch() {
    this.searchCtrl.valueChanges.subscribe(value => {
      this.dataSource.filter = value.trim().toLowerCase();
    });
  }

  createEquipment() {
    const dialogRef = this.dialog.open(EquipmentCreateUpdateComponent, {
      width: '600px',
      data: { mode: 'create' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadEquipment();
      }
    });
  }

  updateEquipment(equipment: Equipment) {
    const dialogRef = this.dialog.open(EquipmentCreateUpdateComponent, {
      width: '600px',
      data: { mode: 'update', equipment }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadEquipment();
      }
    });
  }

  deleteEquipment(equipment: Equipment) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'DELETE_EQUIPMENT_TITLE',
        message: 'DELETE_EQUIPMENT_CONFIRM',
        itemName: equipment.name,
        color: 'warn'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.equipmentService.deleteEquipment(equipment.id).subscribe({
          next: () => {
            this.loadEquipment();
            this.snackBar.open(this.translate.instant('EQUIPMENT_DELETED_SUCCESS'), 'Close', {
              duration: 3000
            });
          },
          error: (error) => {
            console.error('Error deleting equipment:', error);
            this.snackBar.open(this.translate.instant('ERROR_DELETING_EQUIPMENT'), 'Close', {
              duration: 3000
            });
          }
        });
      }
    });
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  deleteSelected() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'DELETE_SELECTED_EQUIPMENT_TITLE',
        message: 'DELETE_SELECTED_EQUIPMENT_CONFIRM',
        itemName: `${this.selection.selected.length} items`,
        color: 'warn'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const selectedIds = this.selection.selected.map(equipment => equipment.id);
        this.equipmentService.deleteMultipleEquipment(selectedIds).subscribe({
          next: () => {
            this.selection.clear();
            this.loadEquipment();
            this.snackBar.open(this.translate.instant('EQUIPMENT_DELETED_SUCCESS'), 'Close', {
              duration: 3000
            });
          },
          error: (error) => {
            console.error('Error deleting equipment:', error);
            this.snackBar.open(this.translate.instant('ERROR_DELETING_EQUIPMENT'), 'Close', {
              duration: 3000
            });
          }
        });
      }
    });
  }
}
