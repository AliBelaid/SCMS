import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Equipment } from './equipment.model';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EquipmentService {
  private apiUrl = `${environment.apiUrl}/equipment`;

  constructor(private http: HttpClient) { }

  getEquipment(): Observable<Equipment[]> {
    return this.http.get<Equipment[]>(this.apiUrl);
  }

  getEquipmentById(id: number): Observable<Equipment> {
    return this.http.get<Equipment>(`${this.apiUrl}/${id}`);
  }

  createEquipment(equipment: Equipment): Observable<Equipment> {
    return this.http.post<Equipment>(this.apiUrl, equipment);
  }

  updateEquipment(id: number, equipment: Equipment): Observable<Equipment> {
    return this.http.put<Equipment>(`${this.apiUrl}/${id}`, equipment);
  }

  deleteEquipment(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  deleteMultipleEquipment(ids: number[]): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/delete-multiple`, { ids });
  }

  searchEquipment(query: string): Observable<Equipment[]> {
    return this.http.get<Equipment[]>(`${this.apiUrl}/search`, { params: { query } });
  }

  getEquipmentByDepartment(department: string): Observable<Equipment[]> {
    return this.http.get<Equipment[]>(`${this.apiUrl}/department/${department}`);
  }

  getEquipmentByStatus(status: string): Observable<Equipment[]> {
    return this.http.get<Equipment[]>(`${this.apiUrl}/status/${status}`);
  }

  getEquipmentNeedingMaintenance(): Observable<Equipment[]> {
    return this.http.get<Equipment[]>(`${this.apiUrl}/needs-maintenance`);
  }
}
