export interface Equipment {
  id: number;
  name: string;
  type: string;
  model: string;
  serialNumber: string;
  manufacturer: string;
  purchaseDate: Date;
  lastMaintenanceDate: Date;
  nextMaintenanceDate: Date;
  status: 'operational' | 'maintenance' | 'out_of_service';
  location: string;
  department: string;
  cost: number;
  warrantyExpiryDate?: Date;
  specifications?: {
    [key: string]: string;
  };
  notes?: string;
}
