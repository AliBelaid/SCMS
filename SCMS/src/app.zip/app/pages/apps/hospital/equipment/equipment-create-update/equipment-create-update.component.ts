import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { TranslateModule } from '@ngx-translate/core';
import { EquipmentService } from '../equipment.service';
import { Equipment } from '../equipment.model';

@Component({
  selector: 'app-equipment-create-update',
  templateUrl: './equipment-create-update.component.html',
  styleUrls: ['./equipment-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    TranslateModule
  ]
})
export class EquipmentCreateUpdateComponent implements OnInit {
  form: FormGroup;
  isEditMode = false;
  departments = ['Cardiology', 'Neurology', 'Orthopedics', 'Pediatrics', 'Radiology'];

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<EquipmentCreateUpdateComponent>,
    private equipmentService: EquipmentService,
    @Inject(MAT_DIALOG_DATA) public data: { mode: 'create' | 'update', equipment?: Equipment }
  ) {
    this.isEditMode = data.mode === 'update';
    this.initializeForm();
  }

  ngOnInit() {
    if (this.isEditMode && this.data.equipment) {
      this.form.patchValue(this.data.equipment);
    }
  }

  initializeForm() {
    this.form = this.fb.group({
      name: ['', Validators.required],
      type: ['', Validators.required],
      model: ['', Validators.required],
      serialNumber: ['', Validators.required],
      manufacturer: ['', Validators.required],
      purchaseDate: [null, Validators.required],
      lastMaintenanceDate: [null],
      nextMaintenanceDate: [null],
      status: ['active', Validators.required],
      location: ['', Validators.required],
      department: ['', Validators.required],
      cost: [null, [Validators.required, Validators.min(0)]],
      warrantyExpiryDate: [null],
      specifications: [''],
      notes: ['']
    });
  }

  onSave() {
    if (this.form.valid) {
      const equipmentData = this.form.value;

      if (this.isEditMode && this.data.equipment) {
        this.equipmentService.updateEquipment(this.data.equipment.id, equipmentData).subscribe(() => {
          this.dialogRef.close(true);
        });
      } else {
        this.equipmentService.createEquipment(equipmentData).subscribe(() => {
          this.dialogRef.close(true);
        });
      }
    }
  }

  onCancel() {
    this.dialogRef.close();
  }
}
