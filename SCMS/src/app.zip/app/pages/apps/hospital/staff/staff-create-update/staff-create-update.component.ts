import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { Staff } from '../staff.model';
import { StaffService } from '../staff.service';
import { MatChipsModule } from '@angular/material/chips';

@Component({
  selector: 'app-staff-create-update',
  templateUrl: './staff-create-update.component.html',
  styleUrls: ['./staff-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
      MatChipsModule ,
      MatIconModule,
    TranslateModule
  ]
})
export class StaffCreateUpdateComponent implements OnInit {
addQualification($event: any) {
throw new Error('Method not implemented.');
}
removeQualification($event: any) {
 
}



  staffForm: FormGroup;
  isEditMode = false;
  departments = ['Cardiology', 'Neurology', 'Pediatrics', 'Emergency', 'Surgery', 'Radiology'];

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<StaffCreateUpdateComponent>,
    private staffService: StaffService,
    @Inject(MAT_DIALOG_DATA) public data: { mode: 'create' | 'update', staff?: Staff }
  ) {
    this.isEditMode = data.mode === 'update';
    this.initializeForm();
  }

  ngOnInit() {
    if (this.isEditMode && this.data.staff) {
      this.staffForm.patchValue(this.data.staff);
    }
  }

  initializeForm() {
    this.staffForm = this.fb.group({
      name: ['', Validators.required],
      position: ['', Validators.required],
      department: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      status: ['active', Validators.required],
      hireDate: [new Date(), Validators.required],
      salary: [0, [Validators.required, Validators.min(0)]],
      address: [''],
      emergencyContact: this.fb.group({
        name: [''],
        relationship: [''],
        phone: ['']
      }),
      qualifications: [[]],
      notes: ['']
    });
  }

  onSave() {
    if (this.staffForm.valid) {
      const staffData = this.staffForm.value;

      if (this.isEditMode && this.data.staff) {
        this.staffService.updateStaff(this.data.staff.id, staffData).subscribe({
          next: () => this.dialogRef.close(true),
          error: (error) => console.error('Error updating staff:', error)
        });
      } else {
        this.staffService.createStaff(staffData).subscribe({
          next: () => this.dialogRef.close(true),
          error: (error) => console.error('Error creating staff:', error)
        });
      }
    }
  }

  onCancel() {
    this.dialogRef.close();
  }
}
