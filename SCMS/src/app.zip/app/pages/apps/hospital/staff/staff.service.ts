import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Staff } from './staff.model';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  private apiUrl = `${environment.apiUrl}/staff`;

  constructor(private http: HttpClient) { }

  getStaff(): Observable<Staff[]> {
    return this.http.get<Staff[]>(this.apiUrl);
  }

  getStaffById(id: number): Observable<Staff> {
    return this.http.get<Staff>(`${this.apiUrl}/${id}`);
  }

  createStaff(staff: Staff): Observable<Staff> {
    return this.http.post<Staff>(this.apiUrl, staff);
  }

  updateStaff(id: number, staff: Staff): Observable<Staff> {
    return this.http.put<Staff>(`${this.apiUrl}/${id}`, staff);
  }

  deleteStaff(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  deleteMultipleStaff(ids: number[]): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/delete-multiple`, { ids });
  }

  searchStaff(query: string): Observable<Staff[]> {
    return this.http.get<Staff[]>(`${this.apiUrl}/search`, { params: { query } });
  }

  getStaffByDepartment(department: string): Observable<Staff[]> {
    return this.http.get<Staff[]>(`${this.apiUrl}/department/${department}`);
  }

  getActiveStaff(): Observable<Staff[]> {
    return this.http.get<Staff[]>(`${this.apiUrl}/active`);
  }
}
