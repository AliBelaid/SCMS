import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SelectionModel } from '@angular/cdk/collections';
import { StaffCreateUpdateComponent } from './staff-create-update/staff-create-update.component';
import { StaffService } from './staff.service';
import { Staff } from './staff.model';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { RouterModule } from '@angular/router';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,MatTooltipModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatIconModule,
    MatTableModule,
    MatCheckboxModule,
    MatSnackBarModule,
    DialogModule,
    MatTreeModule,
    CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    CdkStepperModule,
    MatButtonToggleModule,
    MatSliderModule,
    TranslateModule,
    MatStepperModule,
    MatOptionModule,
    MatProgressSpinnerModule,
    DragDropModule,
    RouterModule,
    VexBreadcrumbsComponent
    , VexPageLayoutComponent,
         VexPageLayoutHeaderDirective,
         VexPageLayoutContentDirective,
         NgIf,
         NgFor,
         NgClass,MatButtonToggleModule,
    MatMenuModule

]
})
export class StaffComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  layoutCtrl = new UntypedFormControl('fullwidth');
  dataSource: MatTableDataSource<Staff>;
  selection = new SelectionModel<Staff>(true, []);
  searchCtrl = new UntypedFormControl();
  displayedColumns: string[] = [
    'select',
    'id',
    'name',
    'position',
    'department',
    'email',
    'phone',
    'status',
    'actions'
  ];

  constructor(
    private dialog: MatDialog,
    private staffService: StaffService,
    private translate: TranslateService,
    private snackBar: MatSnackBar
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit() {
    this.loadStaff();
    this.setupSearch();
  }

  loadStaff() {
    this.staffService.getStaff().subscribe(staff => {
      this.dataSource.data = staff;
    });
  }

  setupSearch() {
    this.searchCtrl.valueChanges.subscribe(value => {
      this.dataSource.filter = value.trim().toLowerCase();
    });
  }

  createStaff() {
    const dialogRef = this.dialog.open(StaffCreateUpdateComponent, {
      width: '600px',
      data: { mode: 'create' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadStaff();
      }
    });
  }

  updateStaff(staff: Staff) {
    const dialogRef = this.dialog.open(StaffCreateUpdateComponent, {
      width: '600px',
      data: { mode: 'update', staff }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadStaff();
      }
    });
  }

  deleteStaff(staff: Staff) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'DELETE_STAFF_TITLE',
        message: 'DELETE_STAFF_CONFIRM',
        itemName: staff.name,
        color: 'warn'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.staffService.deleteStaff(staff.id).subscribe({
          next: () => {
            this.loadStaff();
            this.snackBar.open(this.translate.instant('STAFF_DELETED_SUCCESS'), 'Close', {
              duration: 3000
            });
          },
          error: (error) => {
            console.error('Error deleting staff:', error);
            this.snackBar.open(this.translate.instant('ERROR_DELETING_STAFF'), 'Close', {
              duration: 3000
            });
          }
        });
      }
    });
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  deleteSelected() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'DELETE_SELECTED_STAFF_TITLE',
        message: 'DELETE_SELECTED_STAFF_CONFIRM',
        itemName: `${this.selection.selected.length} staff members`,
        color: 'warn'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const selectedIds = this.selection.selected.map(staff => staff.id);
        this.staffService.deleteMultipleStaff(selectedIds).subscribe({
          next: () => {
            this.selection.clear();
            this.loadStaff();
            this.snackBar.open(this.translate.instant('STAFF_DELETED_SUCCESS'), 'Close', {
              duration: 3000
            });
          },
          error: (error) => {
            console.error('Error deleting staff:', error);
            this.snackBar.open(this.translate.instant('ERROR_DELETING_STAFF'), 'Close', {
              duration: 3000
            });
          }
        });
      }
    });
  }
}
