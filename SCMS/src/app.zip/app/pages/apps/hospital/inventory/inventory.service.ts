import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { InventoryAdjustment, InventoryItem, StockTransaction } from './inventory.model';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private baseUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  // Get all inventory items
  getAllInventoryItems(): Observable<InventoryItem[]> {
    return this.http.get<InventoryItem[]>(`${this.baseUrl}/inventory`);
  }

  // Get a single inventory item by ID
  getInventoryItemById(id: number): Observable<InventoryItem> {
    return this.http.get<InventoryItem>(`${this.baseUrl}/inventory/${id}`);
  }

  // Create a new inventory item
  createInventoryItem(item: Omit<InventoryItem, 'id'>): Observable<InventoryItem> {
    return this.http.post<InventoryItem>(`${this.baseUrl}/inventory`, item);
  }

  // Update an existing inventory item
  updateInventoryItem(id: number, item: Partial<InventoryItem>): Observable<InventoryItem> {
    return this.http.put<InventoryItem>(`${this.baseUrl}/inventory/${id}`, item);
  }

  // Delete an inventory item
  deleteInventoryItem(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/inventory/${id}`);
  }

  // Get transaction history for an inventory item
  getItemTransactionHistory(itemId: number): Observable<StockTransaction[]> {
    return this.http.get<StockTransaction[]>(`${this.baseUrl}/inventory/${itemId}/transactions`);
  }

  // Get all transactions with filters
  getAllTransactions(page: number = 1, pageSize: number = 10, filters?: any): Observable<{ items: StockTransaction[], totalCount: number }> {
    let params: any = { page, pageSize };

    if (filters) {
      Object.keys(filters).forEach(key => {
        if (filters[key]) {
          params[key] = filters[key];
        }
      });
    }

    return this.http.get<{ items: StockTransaction[], totalCount: number }>(`${this.baseUrl}/inventory/transactions`, { params });
  }

  // Adjust inventory stock
  adjustInventoryStock(adjustment: InventoryAdjustment): Observable<InventoryItem> {
    return this.http.post<InventoryItem>(`${this.baseUrl}/inventory/adjust-stock`, adjustment);
  }

  // Export inventory data
  exportInventory(filters?: any): Observable<Blob> {
    let params: any = {};

    if (filters) {
      Object.keys(filters).forEach(key => {
        if (filters[key]) {
          params[key] = filters[key];
        }
      });
    }

    return this.http.get(`${this.baseUrl}/inventory/export`, {
      params,
      responseType: 'blob'
    });
  }

  // Get low stock items
  getLowStockItems(): Observable<InventoryItem[]> {
    return this.http.get<InventoryItem[]>(`${this.baseUrl}/inventory/low-stock`);
  }

  // Get expired items
  getExpiredItems(): Observable<InventoryItem[]> {
    return this.http.get<InventoryItem[]>(`${this.baseUrl}/inventory/expired`);
  }

  // Generate inventory report
  generateInventoryReport(reportType: string, params?: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/inventory/reports/${reportType}`, { params });
  }
}
