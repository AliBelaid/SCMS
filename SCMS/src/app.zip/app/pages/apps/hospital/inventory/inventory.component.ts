import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TranslateModule } from '@ngx-translate/core';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';

import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatBadgeModule } from '@angular/material/badge';
import { InventoryService } from './inventory.service';
import { InventoryItem } from './inventory.model';
import { InventoryCreateUpdateComponent } from './inventory-create-update/inventory-create-update.component';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatSliderModule } from '@angular/material/slider';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { RouterModule } from '@angular/router';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { NgxSpinnerModule } from 'ngx-spinner';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    fadeInUp400ms,
    stagger40ms
  ],

   standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatCheckboxModule,
    MatSnackBarModule,
    VexBreadcrumbsComponent,
    DialogModule,
    MatTreeModule,
    CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,TranslateModule,
    MatChipsModule,
    MatTooltipModule,MatBadgeModule,
    MatRippleModule,
    CdkStepperModule,
    MatButtonToggleModule,
    MatSliderModule,
    MatStepperModule,
    MatOptionModule,
    VexPageLayoutContentDirective,
    VexPageLayoutHeaderDirective,
    VexPageLayoutComponent,
    DragDropModule,
    RouterModule ,
    MatCardModule,
    MatProgressSpinnerModule,
    NgxSpinnerModule
  ]
})
export class InventoryComponent implements OnInit {
  // Data source for the table
  dataSource = new MatTableDataSource<InventoryItem>([]);

  // Columns to display in the table
  displayedColumns: string[] = [
    'name',
    'category',
    'currentStock',
    'unitPrice',
    'location',
    'lastUpdated',
    'status',
    'actions'
  ];

  // Search filters
  searchCtrl = new FormControl('');
  categoryFilter = new FormControl('');
  statusFilter = new FormControl('');

  // Loading state
  isLoading = false;

  // Categories for filtering
  categories = [
    'Medications',
    'Medical Supplies',
    'Laboratory Supplies',
    'Surgical Supplies',
    'Office Supplies',
    'Cleaning Supplies',
    'Other'
  ];

  // Statuses for filtering
  statuses = [
    { value: 'in-stock', label: 'IN_STOCK' },
    { value: 'low-stock', label: 'LOW_STOCK' },
    { value: 'out-of-stock', label: 'OUT_OF_STOCK' },
    { value: 'expired', label: 'EXPIRED' },
    { value: 'discontinued', label: 'DISCONTINUED' }
  ];

  // Breadcrumb configuration
  breadcrumbs = [
    {
      text: 'Dashboard',
      link: '/'
    },
    {
      text: 'Inventory',
      link: '/inventory'
    }
  ];

  constructor(
    private inventoryService: InventoryService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.loadInventory();
    this.setupFilters();
  }

  loadInventory() {
    this.isLoading = true;
    this.cd.markForCheck();

    this.inventoryService.getAllInventoryItems().subscribe({
      next: (items) => {
        this.dataSource.data = items;
        this.isLoading = false;
        this.cd.markForCheck();
      },
      error: (error) => {
        console.error('Error loading inventory:', error);
        this.isLoading = false;
        this.snackBar.open('Error loading inventory items', 'Close', { duration: 3000 });
        this.cd.markForCheck();
      }
    });
  }

  setupFilters() {
    // Set up search filter
    this.searchCtrl.valueChanges.subscribe(value => {
      this.dataSource.filter = value?.trim().toLowerCase() || '';
    });

    // Set up category and status filters
    const filterChange = () => {
      this.applyFilters();
    };

    this.categoryFilter.valueChanges.subscribe(filterChange);
    this.statusFilter.valueChanges.subscribe(filterChange);

    // Customize the filter predicate to support multiple filters
    this.dataSource.filterPredicate = (data: InventoryItem, filter: string) => {
      const searchTerm = filter.toLowerCase();
      const category = this.categoryFilter.value;
      const status = this.statusFilter.value;

      // Apply search filter
      const matchesSearch = !searchTerm ||
                          data.name.toLowerCase().includes(searchTerm) ||
                          data.description?.toLowerCase().includes(searchTerm) ||
                          data.location.toLowerCase().includes(searchTerm) ||
                          data.itemCode.toLowerCase().includes(searchTerm);

      // Apply category filter
      const matchesCategory = !category || data.category === category;

      // Apply status filter
      const matchesStatus = !status || data.status === status;

      return matchesSearch && matchesCategory && matchesStatus;
    };
  }

  applyFilters() {
    // Trigger the filter by re-applying the current search term
    this.dataSource.filter = this.searchCtrl.value?.trim().toLowerCase() || ' ';
  }

  clearFilters() {
    this.searchCtrl.setValue('');
    this.categoryFilter.setValue('');
    this.statusFilter.setValue('');
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'in-stock':
        return 'status-in-stock';
      case 'low-stock':
        return 'status-low-stock';
      case 'out-of-stock':
        return 'status-out-of-stock';
      case 'expired':
        return 'status-expired';
      case 'discontinued':
        return 'status-discontinued';
      default:
        return '';
    }
  }

  openCreateDialog() {
    const dialogRef = this.dialog.open(InventoryCreateUpdateComponent, {
      width: '600px',
      data: { mode: 'create' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadInventory();
      }
    });
  }

  openEditDialog(item: InventoryItem) {
    const dialogRef = this.dialog.open(InventoryCreateUpdateComponent, {
      width: '600px',
      data: { mode: 'update', item }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadInventory();
      }
    });
  }

  adjustStock(item: InventoryItem) {
    // You could open a dialog to adjust stock quantity up or down
    console.log('Adjust stock for item:', item);
    // For now, we'll just show a message
    this.snackBar.open('Stock adjustment feature coming soon', 'Close', { duration: 3000 });
  }

  viewHistory(item: InventoryItem) {
    // Open a dialog or navigate to a detailed history view for this item
    console.log('View history for item:', item);
    // For now, we'll just show a message
    this.snackBar.open('Transaction history feature coming soon', 'Close', { duration: 3000 });
  }

  deleteItem(item: InventoryItem) {
    if (confirm('Are you sure you want to delete this inventory item?')) {
      this.inventoryService.deleteInventoryItem(item.id).subscribe({
        next: () => {
          this.snackBar.open('Inventory item deleted successfully', 'Close', { duration: 3000 });
          this.loadInventory();
        },
        error: (error) => {
          console.error('Error deleting inventory item:', error);
          this.snackBar.open('Error deleting inventory item', 'Close', { duration: 3000 });
        }
      });
    }
  }

  exportInventory() {
    // Export the inventory data to CSV or Excel
    console.log('Export inventory');
    // For now, we'll just show a message
    this.snackBar.open('Export feature coming soon', 'Close', { duration: 3000 });
  }

  refreshInventory() {
    this.loadInventory();
  }

  // Helper methods for template bindings
  getLowStockItemsCount(): number {
    return this.dataSource.data.filter(i => i.status === 'low-stock').length;
  }

  getOutOfStockItemsCount(): number {
    return this.dataSource.data.filter(i => i.status === 'out-of-stock').length;
  }

  getExpiredItemsCount(): number {
    return this.dataSource.data.filter(i => i.status === 'expired').length;
  }

  getStockInfoClass(item: InventoryItem): { [key: string]: boolean } {
    return {
      'low-stock': item.currentStock <= item.minimumStockLevel,
      'out-of-stock': item.currentStock === 0
    };
  }

  isLowStock(item: InventoryItem): boolean {
    return item.currentStock <= item.minimumStockLevel && item.currentStock > 0;
  }
}
