export interface InventoryItem {
  id: number;
  name: string;
  description?: string;
  itemCode: string;
  category: string;
  currentStock: number;
  minimumStockLevel: number;
  unitPrice: number;
  unitOfMeasure: string;
  location: string;
  supplier?: string;
  manufacturerName?: string;
  expiryDate?: Date;
  lastUpdated: Date;
  status: 'in-stock' | 'low-stock' | 'out-of-stock' | 'expired' | 'discontinued';
}

export interface StockTransaction {
  id: number;
  inventoryItemId: number;
  transactionType: 'purchase' | 'consumption' | 'adjustment' | 'return' | 'transfer';
  quantity: number;
  transactionDate: Date;
  referenceNumber?: string;
  notes?: string;
  performedBy: string;
  sourceLocation?: string;
  destinationLocation?: string;
  unitCost?: number;
  totalCost?: number;
  batchNumber?: string;
}

export interface InventoryAdjustment {
  inventoryItemId: number;
  quantity: number;
  adjustmentType: 'increase' | 'decrease';
  reason: string;
  notes?: string;
}

export interface InventoryFilter {
  searchTerm?: string;
  category?: string;
  status?: string;
  location?: string;
}
