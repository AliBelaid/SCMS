import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { TranslateModule } from '@ngx-translate/core';
import { InventoryItem } from '../inventory.model';
import { InventoryService } from '../inventory.service';

export interface InventoryDialogData {
  mode: 'create' | 'update';
  item?: InventoryItem;
}

@Component({
  selector: 'app-inventory-create-update',
  templateUrl: './inventory-create-update.component.html',
  styleUrls: ['./inventory-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatSnackBarModule,
    TranslateModule
  ]
})
export class InventoryCreateUpdateComponent implements OnInit {
  form: FormGroup;
  isEditMode: boolean;
  isSubmitting = false;

  // Categories for the dropdown
  categories = [
    'Medications',
    'Medical Supplies',
    'Laboratory Supplies',
    'Surgical Supplies',
    'Office Supplies',
    'Cleaning Supplies',
    'Other'
  ];

  // Statuses for the dropdown
  statuses = [
    { value: 'in-stock', label: 'IN_STOCK' },
    { value: 'low-stock', label: 'LOW_STOCK' },
    { value: 'out-of-stock', label: 'OUT_OF_STOCK' },
    { value: 'expired', label: 'EXPIRED' },
    { value: 'discontinued', label: 'DISCONTINUED' }
  ];

  // Units of measure for the dropdown
  unitsOfMeasure = [
    'Each',
    'Box',
    'Pack',
    'Case',
    'Bottle',
    'Vial',
    'Ampule',
    'Tablet',
    'Capsule',
    'ML',
    'L',
    'G',
    'KG',
    'MG',
    'CM',
    'M'
  ];

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<InventoryCreateUpdateComponent>,
    private inventoryService: InventoryService,
    private snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: InventoryDialogData
  ) {
    this.isEditMode = data.mode === 'update';
    this.initializeForm();
  }

  ngOnInit() {
    if (this.isEditMode && this.data.item) {
      this.patchFormWithItemData();
    }
  }

  private initializeForm() {
    this.form = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      itemCode: ['', Validators.required],
      category: ['', Validators.required],
      currentStock: [0, [Validators.required, Validators.min(0)]],
      minimumStockLevel: [0, [Validators.required, Validators.min(0)]],
      unitPrice: [0, [Validators.required, Validators.min(0)]],
      unitOfMeasure: ['Each', Validators.required],
      location: ['', Validators.required],
      supplier: [''],
      manufacturerName: [''],
      expiryDate: [null],
      status: ['in-stock', Validators.required]
    });
  }

  private patchFormWithItemData() {
    // Create a copy of the item to avoid modifying the original
    const item = { ...this.data.item };

    // Format dates properly for the form
    if (item.expiryDate) {
      item.expiryDate = new Date(item.expiryDate);
    }

    this.form.patchValue(item);
  }

  onSubmit() {
    if (this.form.invalid || this.isSubmitting) {
      return;
    }

    this.isSubmitting = true;
    const formValue = this.form.value;

    // Add timestamp for lastUpdated
    formValue.lastUpdated = new Date();

    if (this.isEditMode && this.data.item) {
      this.updateItem(formValue);
    } else {
      this.createItem(formValue);
    }
  }

  private createItem(formValue: any) {
    this.inventoryService.createInventoryItem(formValue).subscribe({
      next: (response) => {
        this.snackBar.open('Inventory item created successfully', 'Close', { duration: 3000 });
        this.dialogRef.close(response);
      },
      error: (error) => {
        console.error('Error creating inventory item:', error);
        this.snackBar.open('Error creating inventory item', 'Close', { duration: 3000 });
        this.isSubmitting = false;
      }
    });
  }

  private updateItem(formValue: any) {
    if (!this.data.item?.id) {
      this.snackBar.open('Error: Missing item ID', 'Close', { duration: 3000 });
      this.isSubmitting = false;
      return;
    }

    this.inventoryService.updateInventoryItem(this.data.item.id, formValue).subscribe({
      next: (response) => {
        this.snackBar.open('Inventory item updated successfully', 'Close', { duration: 3000 });
        this.dialogRef.close(response);
      },
      error: (error) => {
        console.error('Error updating inventory item:', error);
        this.snackBar.open('Error updating inventory item', 'Close', { duration: 3000 });
        this.isSubmitting = false;
      }
    });
  }

  onCancel() {
    this.dialogRef.close();
  }
}
