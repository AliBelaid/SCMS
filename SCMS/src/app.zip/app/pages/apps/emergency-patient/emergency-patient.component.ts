import { AfterViewInit, Component, DestroyRef, inject, Input, OnInit, ViewChild } from '@angular/core';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { SelectionModel } from '@angular/cdk/collections';

import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { EmergencyPatient, EmergencyPatientService } from './emergency-patient.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { CompanionCreateUpdateComponent } from './companion-create-update/companion-create-update';
import { EmergencyPatientCreateUpdateComponent } from './emergency-patient-create-update/emergency-patient-create-update';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';

@Component({
  selector: 'vex-analysisLaboratory',
  templateUrl: './emergency-patient.component.html',
  styleUrls: ['./emergency-patient.component.scss'],
  animations: [
    fadeInUp400ms,
    stagger40ms ,

      trigger('detailExpand', [
        state('collapsed', style({ height: '0px', minHeight: '0' })),
        state('expanded', style({ height: '*' })),
        transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
      ]),
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'standard'
      } as unknown as MatFormFieldDefaultOptions
    }
  ]
  ,
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatListModule,
    MatCheckboxModule,
    TranslateModule ,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatTableModule,
    MatCheckboxModule,
    MatIconModule,
    MatDividerModule, MatSnackBarModule,
    CommonModule,
    MatDialogModule,      // إضافة MatDialogModule هنا
   VexBreadcrumbsComponent,
   TranslateModule,
   MatDatepickerModule,
   DialogModule,
   MatTreeModule,
   CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    MatRippleModule,
    CdkStepperModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatSnackBarModule,
    MatInputModule,VexPageLayoutComponent,
    MatDatepickerModule,
    MatNativeDateModule
  , MatNativeDateModule,
  MatSliderModule ,
  MatFormFieldModule,
     MatStepperModule,
    MatOptionModule
    ,VexPageLayoutContentDirective ,VexPageLayoutHeaderDirective ,
    FormsModule,
   MatRippleModule,
   MatIconModule ,
   MatTabsModule,
   MatIconModule,
   DragDropModule
  ]
})
export class EmergencyPatientComponent implements OnInit, AfterViewInit {

  layoutCtrl = new UntypedFormControl('fullwidth');
  subject$: ReplaySubject<EmergencyPatient[]> = new ReplaySubject<EmergencyPatient[]>(1);
  data$: Observable<EmergencyPatient[]> = this.subject$.asObservable();
  analysislaboratory: EmergencyPatient[];
  expandedElement: any | null;
  @Input() columns: TableColumn<any>[] = [
    // { label: this.translate.instant('ID'), property: 'id', type: 'text', visible: true },
    { label: this.translate.instant('patientName'), property: 'patientName', type: 'text', visible: true },
    { label: this.translate.instant('accommodation'), property: 'accommodation', type: 'text', visible: true },
    { label: this.translate.instant('codeTreatment'), property: 'codeTreatment', type: 'text', visible: true },

    { label: this.translate.instant('emergencyCreated'), property: 'EmergencyPatientId', type: 'text', visible: true },

    { label: this.translate.instant('ADMISSION_DATE'), property: 'admissionDate', type: 'text', visible: true },
    { label: this.translate.instant('CONDITION_DESCRIPTION'), property: 'conditionDescription', type: 'text', visible: true },
    { label: this.translate.instant('WARD'), property: 'ward', type: 'text', visible: true },
    { label: this.translate.instant('ROOM_NUMBER'), property: 'roomNumber', type: 'text', visible: true },
    { label: 'Actions', property: 'actions', type: 'button', visible: true },
    // { label: 'expandedDetail', property: 'expandedDetail', type: 'button', visible: true ,matColumnDef:'expandedDetail' },

     { label: 'TableExpanded', property: 'isExpanded', type: 'button', visible: true  },

  ];
  // subTableColumns: any[] = [
  //   { label: 'تاريخ الايراد', colspan: 1 ,matColumnDef:'treatmentDate', property: 'treatmentDate',   type: 'text' },
  //   { label: 'الايراد الصوتي', colspan: 1,matColumnDef:'treatmentDetails', property: 'treatmentDetails',  type: 'text'},

  // ];
  subTableColumns = ['treatmentDate', 'treatmentDetails', 'nurseNotes','actions'];

  toggleRow(element: any) {
    element.isExpanded = !element.isExpanded;
    this.expandedElement = this.expandedElement === element ? null : element;
  }
   masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }



  // TREATMENT_DATE TREATMENT_DETAILS
  // expandedRowIndex = -1;


  stateiniExt = false ;
  toggleExpand(element: any): void {

    this.stateiniExt=  !  element.isExpanded;


      this.dataSource.data.forEach((row: any) => {
        row.isExpanded = false;
      })
      element.isExpanded =this.stateiniExt;
      this.stateiniExt = false

    }

  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<EmergencyPatient> | null;
  selection = new SelectionModel<EmergencyPatient>(true, []);
  searchCtrl = new UntypedFormControl();

  labels = [];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private dialog: MatDialog, private _emergencyPatientService: EmergencyPatientService, private translate: TranslateService) {}

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  ngOnInit() {
    this._emergencyPatientService.getEmergencyPatients().subscribe(analysislaboratory => {
      console.log(analysislaboratory)
      this.subject$.next(analysislaboratory);
    });

    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter<EmergencyPatient[]>(Boolean)
    ).subscribe(analysisLaboratory => {

      this.analysislaboratory = analysisLaboratory;
      this.dataSource.data = analysisLaboratory;
    });

       this.searchCtrl.valueChanges
         .pipe(takeUntilDestroyed(this.destroyRef))
         .subscribe((value) => this.onFilterChange(value));





    this.dataSource.data.forEach((row: any) => {
      row.isExpanded = false;
    })
  }
  private readonly destroyRef: DestroyRef = inject(DestroyRef);





  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createanalysisLaboratory(row?:EmergencyPatient) {

    console.log(row)
    const dialogRef = this.dialog.open(EmergencyPatientCreateUpdateComponent, {
      minWidth: '600px',
      minHeight: '950px',
      data:row
    }).afterClosed().subscribe((analysisLaboratory: EmergencyPatient) => {
      if (analysisLaboratory) {
        this._emergencyPatientService.createEmergencyPatient(analysisLaboratory).subscribe(() => {
     //     analysisLaboratory.CompanionaTotal =0;
          this.analysislaboratory.unshift(analysisLaboratory);
          this.subject$.next(this.analysislaboratory);
        });
      }
    });
  }

  updateanalysisLaboratory(analysisLaboratory: EmergencyPatient) {
    this.dialog.open(EmergencyPatientCreateUpdateComponent, {
      minWidth: '600px',
      minHeight: '950px',
      data: analysisLaboratory
    }).afterClosed().subscribe(updatedanalysisLaboratory => {
      if (updatedanalysisLaboratory) {
        this._emergencyPatientService.createEmergencyPatient(updatedanalysisLaboratory).subscribe(() => {
          const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === updatedanalysisLaboratory.codeTreatment);
          this.analysislaboratory[index] = updatedanalysisLaboratory;
      //    this.analysislaboratory[index].EmergencyPatientId = 1;
          this.subject$.next(this.analysislaboratory);

          // analysisLaboratory.CompanionaTotal =0;
          // this.analysislaboratory.unshift(analysisLaboratory);
          // this.subject$.next(this.analysislaboratory);id
        });
      }
    });
  }

  addCompanion(analysisLaboratory: EmergencyPatient) {
    this.dialog.open(CompanionCreateUpdateComponent, {
   //   height:'900px',
      width:'900px',
      data: analysisLaboratory
    }).afterClosed().subscribe(updatedCompanion => {
      if (updatedCompanion) {
        this._emergencyPatientService.addCompanion(analysisLaboratory.id, updatedCompanion).subscribe(() => {
          const index = this.analysislaboratory.findIndex(c => c.id === analysisLaboratory.id);
          this.analysislaboratory[index]?.ambulance.companions?.push(updatedCompanion);
          this.subject$.next(this.analysislaboratory);
        });
      }
    });
  }

  deleteanalysisLaboratory(analysisLaboratory: EmergencyPatient) {
    this._emergencyPatientService.deleteEmergencyPatient(analysisLaboratory.id).subscribe(() => {
      this.analysislaboratory.splice(this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === analysisLaboratory.id), 1);
      this.selection.deselect(analysisLaboratory);
      this.subject$.next(this.analysislaboratory);
    });
  }

  deleteanalysisLaboratoryz(analysisLaboratory: EmergencyPatient[]) {
    analysisLaboratory.forEach(c => this.deleteanalysisLaboratory(c));
  }
  exitAnalysisLaboratory(analysisLaboratory: any) {
    this._emergencyPatientService.dischargePatient(analysisLaboratory.id).subscribe(() => {
      const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === analysisLaboratory.id);
   //   this.analysislaboratory[index].exit = true;
    //  this.analysislaboratory[index].exitDate = new Date().toISOString();
      this.subject$.next(this.analysislaboratory);
    });
    }
 deleteTreatment(treatment: any ,element:any) {
  this._emergencyPatientService.deleteTreatment(treatment.id).subscribe(() => {
    const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === element.id);
    const index_Companiona = element.Companiona.findIndex((existingTreatment: any) => existingTreatment.id === treatment.id);

    this.analysislaboratory[index].ambulance.companions.splice(index_Companiona, 1);
    this.subject$.next(this.analysislaboratory);


  });

}

    editTreatment(_t275: any) {


      if (_t275) {
        // this._emergencyPatientService.updateTreatment(updatedanalysisLaboratory.id, updatedanalysisLaboratory).subscribe(() => {
        //   const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === updatedanalysisLaboratory.id);
        //   this.analysislaboratory[index] = updatedanalysisLaboratory;
        //   this.subject$.next(this.analysislaboratory);
        // });
      }


     }
  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  toggleColumnVisibility(column, event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }



  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }

  onLabelChange(change: MatSelectChange, row: EmergencyPatient) {
    const index = this.analysislaboratory.findIndex(c => c === row);
    this.analysislaboratory[index].id = change.value;
    this.subject$.next(this.analysislaboratory);
  }

  // toggleRow(row: EmergencyPatient) {
  //   if (this.expandedRows.has(row.id)) {
  //     this.expandedRows.delete(row.id);
  //   } else {
  //     this.expandedRows.add(row.id);
  //   }
  // }

  // isRowExpanded(row: EmergencyPatient): boolean {
  //   return this.expandedRows.has(row.id);
  // }
}
