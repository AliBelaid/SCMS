import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { VexRoutes } from 'src/@vex/interfaces/vex-route.interface';
import { EmergencyPatientComponent } from './emergency-patient.component';


const routes: VexRoutes = [
  {
    path: '',
    component:EmergencyPatientComponent,
    data: {
      toolbarShadowEnabled: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule, ]
})
export class PharmaceuticalRoutingModule {
}

