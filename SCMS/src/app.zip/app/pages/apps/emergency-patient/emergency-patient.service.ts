import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmergencyPatientService {
  deleteTreatment(id: any) {
     return this.http.delete<void>(`${this.apiUrl}/Companion?id=${id}`);
  }
  private apiUrl = `${environment.apiUrl}/EmergencyPatient`;

  constructor(private http: HttpClient) { }

  getEmergencyPatients(): Observable<EmergencyPatient[]> {
    return this.http.get<EmergencyPatient[]>(`${this.apiUrl}`);
  }

  getEmergencyPatient(id: number): Observable<EmergencyPatient> {
    return this.http.get<EmergencyPatient>(`${this.apiUrl}/${id}`);
  }

  createEmergencyPatient(admission: EmergencyPatient): Observable<EmergencyPatient> {
    return this.http.post<EmergencyPatient>(this.apiUrl, admission);
  }

  updateEmergencyPatient(id: number, admission: EmergencyPatient): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, admission);
  }

  deleteEmergencyPatient(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  addCompanion(id: number, treatment: Companion): Observable<Companion> {
    return this.http.post<Companion>(`${this.apiUrl}/${id}/Companion`, treatment);
  }

  dischargePatient(id: number): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/${id}/discharge`, {});
  }
}
export interface EmergencyPatient {
  id:number
  name: string; // Name of the emergency case
  contactInfo: string; // Contact information
  arrivalCondition: string; // Condition of arrival
  isLinkedToPatient: boolean; // Indicates if linked to a patient
  patientId: number; // ID of the associated patient
  caseType: number; // Type of case
  treatmentDetails: string; // Details of the treatment
  ambulance: Ambulance; // Ambulance details
  operationDetails: string; // Details of the operation
  needsAdmission: boolean; // Indicates if admission is needed
}

export interface Ambulance {
  id:number
  licensePlate: string; // Ambulance license plate
  driverName: string; // Name of the ambulance driver
  contactNumber: string; // Contact number of the driver
  companions: Companion[]; // List of companions in the ambulance
}

export interface Companion {
  id:number
  name: string; // Name of the companion
  relationship: number; // Relationship type (enum or number)
  ambulanceId: number; // ID of the ambulance
  patientId: number; // ID of the associated patient
}
