import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-emergency-case-create-update',
  templateUrl: './emergency-patient-create-update.html',
  styleUrls: ['./emergency-patient-create-update.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    TranslateModule
  ]
})
export class EmergencyPatientCreateUpdateComponent implements OnInit {
  emergencyCaseForm: FormGroup;

  constructor(private fb: FormBuilder
,    private dialogRef: MatDialogRef<EmergencyPatientCreateUpdateComponent> ) {}

  ngOnInit(): void {
    this.emergencyCaseForm = this.fb.group({
      patientName: ['', [Validators.required]],
      caseDescription: ['', [Validators.required]],
      ambulance: this.fb.group({
        ambulanceNumber: ['', [Validators.required]],
        driverName: ['', [Validators.required]],
        contactNumber: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
        companions: this.fb.array([this.createCompanionForm()])
      }),

    });
  }


  get companions(): FormArray {
    return this.emergencyCaseForm.get('ambulance')?.get('companions') as FormArray;
  }
  createCompanionForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required]],
      relationship: ['', [Validators.required]],
      contactNumber: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
    });
  }
  get ambulanceFrm():FormGroup {
    return this.emergencyCaseForm.get('ambulance') as FormGroup;
  }

  addCompanion(): void {
    this.companions.push(this.createCompanionForm());
  }

  removeCompanion(index: number): void {
    this.companions.removeAt(index);
  }

  save(): void {
    //if (this.emergencyCaseForm.valid) {
      const formData = this.emergencyCaseForm.value;
      console.log('Emergency Case Data:', formData);
    this.dialogRef.close(formData)
  }
}
