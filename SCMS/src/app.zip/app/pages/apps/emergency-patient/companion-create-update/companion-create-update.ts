import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { Companion, EmergencyPatient } from '../emergency-patient.service';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { TranslateModule } from '@ngx-translate/core';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'vex-companion-create-update',
  templateUrl: './companion-create-update.html',
  styleUrls: ['./companion-create-update.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,MatDividerModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    TranslateModule,MatDividerModule
  ]
})
export class CompanionCreateUpdateComponent implements OnInit {
  form: UntypedFormGroup;
  mode: 'create' | 'update' = 'create';

  constructor(
    private dialogRef: MatDialogRef<CompanionCreateUpdateComponent>,
    @Inject(MAT_DIALOG_DATA) public data:EmergencyPatient,
    private fb: UntypedFormBuilder
  ) {}

  ngOnInit() {


      this.form = this.fb.group({
       // id: [this.data.treatment.id],
        EmergencyPatientId: [this.data.id],
        treatmentDate: [],
        treatmentDetails: [ ''],
        nurseNotes: ['']
      });

  }

  save() {
    if (this.form.valid) {
      const Companion: Companion = this.form.value;
      this.dialogRef.close(Companion);
    }
  }

  isCreateMode() {
    return this.mode === 'create';
  }

  isUpdateMode() {
    return this.mode === 'update';
  }
}
