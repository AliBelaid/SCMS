import { Routes } from '@angular/router';

export const EMERGENCY_PATIENT_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./emergency-patient.component').then(m => m.EmergencyPatientComponent)
  }
];
