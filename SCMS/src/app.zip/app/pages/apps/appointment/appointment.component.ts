import { Component, OnInit } from '@angular/core';
import { DatePipe, NgClass, NgFor, NgIf } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppointmentService } from './appointment.service';
import { AfterViewInit, ViewChild } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { SelectionModel } from '@angular/cdk/collections';
import { UntypedFormControl } from '@angular/forms';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Appointment } from 'src/assets/his.model';
import { AppointmentCreateUpdateComponent } from './appointment-create-update/appointment-create-update.component';
import { MatInputModule } from '@angular/material/input';
import { HttpClientModule } from '@angular/common/http';



@Component({
  selector: 'vox-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss'],
  animations: [fadeInUp400ms, stagger40ms],
  standalone: true,
    providers: [
    DatePipe,

  ],
  imports: [
    VexPageLayoutComponent,
    VexPageLayoutHeaderDirective,
    VexBreadcrumbsComponent,
    MatButtonToggleModule,
    ReactiveFormsModule,
    VexPageLayoutContentDirective,
    NgIf,
    MatButtonModule,
    MatTooltipModule,
    MatIconModule,
    MatMenuModule,
    MatTableModule,
    MatSortModule,
    MatCheckboxModule,
    NgFor,
    NgClass,
    MatPaginatorModule,
    FormsModule,
    MatDialogModule,
    MatInputModule
    ,HttpClientModule ,

  ]
})



export class AppointmentComponent implements OnInit, AfterViewInit {
  layoutCtrl = new UntypedFormControl('fullwidth');

  subject$: ReplaySubject<Appointment[]> = new ReplaySubject<Appointment[]>(1);
  data$: Observable<Appointment[]> = this.subject$.asObservable();
  appointments: Appointment[] = [];

  columns: TableColumn<Appointment>[] = [
    { label: 'Patient', property: 'patientName', type: 'text', visible: true },
    { label: 'Doctor', property: 'doctorName', type: 'text', visible: true },
    { label: 'Date', property: 'appointmentDate', type: 'text', visible: true },
    { label: 'Time', property: 'appointmentTime', type: 'text', visible: true },
    { label: 'Status', property: 'status', type: 'text', visible: true },
    { label: 'Actions', property: 'actions', type: 'button', visible: true }
  ];

  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<Appointment>;
  selection = new SelectionModel<Appointment>(true, []);
  searchCtrl = new UntypedFormControl();

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private dialog: MatDialog, private appointmentService: AppointmentService) {
    this.dataSource = new MatTableDataSource();
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  ngOnInit() {
    this.appointmentService.getAppointments().subscribe(appointments => {
      this.subject$.next(appointments);
    });

    this.data$.pipe(
      filter<Appointment[]>(Boolean)
    ).subscribe(appointments => {
      this.appointments = appointments;
      this.dataSource.data = appointments;
    });

    this.searchCtrl.valueChanges.subscribe((value: string) => {
      if (value !== null) {
        this.onFilterChange(value);
      }
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createAppointment() {
    this.dialog.open(AppointmentCreateUpdateComponent).afterClosed().subscribe((appointment: Appointment) => {
      if (appointment) {
        this.appointmentService.createAppointment(appointment).subscribe(response => {
          if (response) {
            this.appointments.unshift(appointment);
            this.subject$.next(this.appointments);
          }
        });
      }
    });
  }

  updateAppointment(appointment: Appointment) {
    this.dialog.open(AppointmentCreateUpdateComponent, {
      data: appointment
    }).afterClosed().subscribe(updatedAppointment => {
      if (updatedAppointment) {
        this.appointmentService.updateAppointment(updatedAppointment.id, updatedAppointment).subscribe(response => {
          if (response) {
            const index = this.appointments.findIndex(a => a.id === updatedAppointment.id);
            this.appointments[index] = updatedAppointment;
            this.subject$.next(this.appointments);
          }
        });
      }
    });
  }

  deleteAppointment(appointment: any) {
    this.appointmentService.deleteAppointment(parseInt(appointment.id)).subscribe(response => {
      if (response) {
        const index = this.appointments.findIndex(a => a.id === appointment.id);
        this.appointments.splice(index, 1);
        this.selection.deselect(appointment);
        this.subject$.next(this.appointments);
      }
    });
  }

  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

 toggleColumnVisibility(column: TableColumn<Appointment>, event: Event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }
}

