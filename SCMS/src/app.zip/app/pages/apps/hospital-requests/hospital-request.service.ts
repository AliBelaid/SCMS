import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { HospitalRequest, RequestItem, RequestStatus, ItemType } from './hospital-request.model';
import { environment } from 'src/assets/environments/environment';
import { delay, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HospitalRequestService {
  private baseUrl = `${environment.apiUrl}/HospitalRequests`;
  private requestsSubject = new BehaviorSubject<HospitalRequest[]>([]);
  public requests$ = this.requestsSubject.asObservable();

  // Mock data for testing
  private mockRequests: HospitalRequest[] = [
    {
      id: 1,
      requestNumber: 'REQ-2023-001',
      hospitalName: 'General Hospital',
      departmentName: 'Emergency Department',
      status: RequestStatus.Approved,
      createdDate: new Date(2023, 1, 15),
      updatedDate: new Date(2023, 1, 18),
      requestedBy: 'Dr. John Smith',
      approvedBy: 'Dr. Sarah Johnson',
      totalAmount: 5200,
      items: [
        {
          id: 1,
          name: 'Paracetamol 500mg',
          quantity: 200,
          type: ItemType.Medicine,
          unitPrice: 0.5,
          totalPrice: 100
        },
        {
          id: 2,
          name: 'Surgical Gloves',
          quantity: 500,
          type: ItemType.Supply,
          unitPrice: 0.2,
          totalPrice: 100
        },
        {
          id: 3,
          name: 'Infusion Pump',
          quantity: 2,
          type: ItemType.Equipment,
          unitPrice: 2500,
          totalPrice: 5000
        }
      ]
    },
    {
      id: 2,
      requestNumber: 'REQ-2023-002',
      hospitalName: 'City Medical Center',
      departmentName: 'Cardiology',
      status: RequestStatus.Pending,
      createdDate: new Date(2023, 2, 10),
      requestedBy: 'Dr. Michael Brown',
      totalAmount: 3750,
      items: [
        {
          id: 4,
          name: 'Cardiac Monitors',
          quantity: 3,
          type: ItemType.Equipment,
          unitPrice: 1200,
          totalPrice: 3600
        },
        {
          id: 5,
          name: 'Nitroglycerin 0.4mg',
          quantity: 100,
          type: ItemType.Medicine,
          unitPrice: 1.5,
          totalPrice: 150
        }
      ]
    },
    {
      id: 3,
      requestNumber: 'REQ-2023-003',
      hospitalName: 'Children\'s Hospital',
      departmentName: 'Pediatrics',
      status: RequestStatus.New,
      createdDate: new Date(2023, 3, 5),
      requestedBy: 'Dr. Emily Williams',
      totalAmount: 1800,
      items: [
        {
          id: 6,
          name: 'Amoxicillin 250mg',
          quantity: 300,
          type: ItemType.Medicine,
          unitPrice: 1.2,
          totalPrice: 360
        },
        {
          id: 7,
          name: 'Digital Thermometers',
          quantity: 20,
          type: ItemType.Equipment,
          unitPrice: 22,
          totalPrice: 440
        },
        {
          id: 8,
          name: 'Pediatric Face Masks',
          quantity: 500,
          type: ItemType.Supply,
          unitPrice: 0.3,
          totalPrice: 150
        },
        {
          id: 9,
          name: 'Syringes 5ml',
          quantity: 500,
          type: ItemType.Supply,
          unitPrice: 0.15,
          totalPrice: 75
        },
        {
          id: 10,
          name: 'Child-Friendly Bandages',
          quantity: 1000,
          type: ItemType.Supply,
          unitPrice: 0.1,
          totalPrice: 100
        }
      ]
    },
    {
      id: 4,
      requestNumber: 'REQ-2023-004',
      hospitalName: 'Neurology Institute',
      departmentName: 'Neurology',
      status: RequestStatus.Canceled,
      createdDate: new Date(2023, 2, 28),
      updatedDate: new Date(2023, 3, 2),
      requestedBy: 'Dr. Robert Taylor',
      totalAmount: 8500,
      notes: 'Request canceled due to budget constraints. Please resubmit with reduced quantities.',
      items: [
        {
          id: 11,
          name: 'MRI Contrast Agent',
          quantity: 50,
          type: ItemType.Medicine,
          unitPrice: 45,
          totalPrice: 2250
        },
        {
          id: 12,
          name: 'EEG Electrodes',
          quantity: 200,
          type: ItemType.Supply,
          unitPrice: 2.5,
          totalPrice: 500
        },
        {
          id: 13,
          name: 'Portable EEG Machine',
          quantity: 1,
          type: ItemType.Equipment,
          unitPrice: 5750,
          totalPrice: 5750
        }
      ]
    }
  ];

  constructor(private http: HttpClient) {
    // Initialize with mock data
    this.requestsSubject.next(this.mockRequests);
  }

  // Get all hospital requests
  getHospitalRequests(): Observable<HospitalRequest[]> {
    // For a real implementation:
    // return this.http.get<HospitalRequest[]>(this.baseUrl);

    // Mock implementation:
    return of(this.mockRequests).pipe(
      delay(500), // Simulate network delay
      tap(requests => this.requestsSubject.next(requests))
    );
  }

  // Get a single hospital request by ID
  getHospitalRequestById(id: number): Observable<HospitalRequest> {
    // For a real implementation:
    // return this.http.get<HospitalRequest>(`${this.baseUrl}/${id}`);

    // Mock implementation:
    const request = this.mockRequests.find(req => req.id === id);
    return of(request!).pipe(delay(300));
  }

  // Create a new hospital request
  createHospitalRequest(request: Omit<HospitalRequest, 'id' | 'requestNumber' | 'createdDate'>): Observable<HospitalRequest> {
    // For a real implementation:
    // return this.http.post<HospitalRequest>(this.baseUrl, request);

    // Mock implementation:
    const newId = Math.max(...this.mockRequests.map(req => req.id)) + 1;
    const newRequest: HospitalRequest = {
      ...request,
      id: newId,
      requestNumber: `REQ-${new Date().getFullYear()}-${String(newId).padStart(3, '0')}`,
      createdDate: new Date(),
      status: RequestStatus.New
    };

    this.mockRequests.push(newRequest);
    this.requestsSubject.next([...this.mockRequests]);

    return of(newRequest).pipe(delay(300));
  }

  // Update an existing hospital request
  updateHospitalRequest(id: number, request: Partial<HospitalRequest>): Observable<HospitalRequest> {
    // For a real implementation:
    // return this.http.put<HospitalRequest>(`${this.baseUrl}/${id}`, request);

    // Mock implementation:
    const index = this.mockRequests.findIndex(req => req.id === id);
    if (index !== -1) {
      const updatedRequest = {
        ...this.mockRequests[index],
        ...request,
        updatedDate: new Date()
      };
      this.mockRequests[index] = updatedRequest;
      this.requestsSubject.next([...this.mockRequests]);
      return of(updatedRequest).pipe(delay(300));
    }

    return of(null as unknown as HospitalRequest);
  }

  // Delete a hospital request
  deleteHospitalRequest(id: number): Observable<boolean> {
    // For a real implementation:
    // return this.http.delete<boolean>(`${this.baseUrl}/${id}`);

    // Mock implementation:
    const index = this.mockRequests.findIndex(req => req.id === id);
    if (index !== -1) {
      this.mockRequests.splice(index, 1);
      this.requestsSubject.next([...this.mockRequests]);
      return of(true).pipe(delay(300));
    }

    return of(false).pipe(delay(300));
  }

  // Change request status
  changeRequestStatus(id: number, status: RequestStatus): Observable<HospitalRequest> {
    return this.updateHospitalRequest(id, { status });
  }

  // Resubmit a canceled request
  resubmitCanceledRequest(id: number): Observable<HospitalRequest> {
    const request = this.mockRequests.find(req => req.id === id);
    if (request && request.status === RequestStatus.Canceled) {
      // Create a new request based on the canceled one
      const { id: _, ...requestWithoutId } = request;
      return this.createHospitalRequest({
        ...requestWithoutId,
        status: RequestStatus.New,
        notes: `Resubmitted from request ${request.requestNumber}`
      });
    }

    return of(null as unknown as HospitalRequest);
  }

  // Add a new item to a request
  addItemToRequest(requestId: number, item: Omit<RequestItem, 'id'>): Observable<HospitalRequest> {
    const request = this.mockRequests.find(req => req.id === requestId);
    if (request) {
      const newItemId = Math.max(...request.items.map(item => item.id), 0) + 1;
      const newItem: RequestItem = {
        ...item,
        id: newItemId,
        totalPrice: item.quantity * item.unitPrice
      };

      const updatedItems = [...request.items, newItem];
      const totalAmount = updatedItems.reduce((sum, item) => sum + item.totalPrice, 0);

      return this.updateHospitalRequest(requestId, {
        items: updatedItems,
        totalAmount
      });
    }

    return of(null as unknown as HospitalRequest);
  }

  // Update an item in a request
  updateRequestItem(requestId: number, itemId: number, updates: Partial<RequestItem>): Observable<HospitalRequest> {
    const request = this.mockRequests.find(req => req.id === requestId);
    if (request) {
      const itemIndex = request.items.findIndex(item => item.id === itemId);
      if (itemIndex !== -1) {
        const updatedItem = {
          ...request.items[itemIndex],
          ...updates
        };

        // Recalculate total price if quantity or unit price changed
        if (updates.quantity !== undefined || updates.unitPrice !== undefined) {
          updatedItem.totalPrice = updatedItem.quantity * updatedItem.unitPrice;
        }

        const updatedItems = [...request.items];
        updatedItems[itemIndex] = updatedItem;

        const totalAmount = updatedItems.reduce((sum, item) => sum + item.totalPrice, 0);

        return this.updateHospitalRequest(requestId, {
          items: updatedItems,
          totalAmount
        });
      }
    }

    return of(null as unknown as HospitalRequest);
  }

  // Remove an item from a request
  removeItemFromRequest(requestId: number, itemId: number): Observable<HospitalRequest> {
    const request = this.mockRequests.find(req => req.id === requestId);
    if (request) {
      const updatedItems = request.items.filter(item => item.id !== itemId);
      const totalAmount = updatedItems.reduce((sum, item) => sum + item.totalPrice, 0);

      return this.updateHospitalRequest(requestId, {
        items: updatedItems,
        totalAmount
      });
    }

    return of(null as unknown as HospitalRequest);
  }

  // Reorder items in a request
  reorderRequestItems(requestId: number, newOrder: number[]): Observable<HospitalRequest> {
    const request = this.mockRequests.find(req => req.id === requestId);
    if (request) {
      const itemMap = new Map(request.items.map(item => [item.id, item]));
      const reorderedItems = newOrder.map(id => itemMap.get(id)!).filter(Boolean);

      return this.updateHospitalRequest(requestId, {
        items: reorderedItems
      });
    }

    return of(null as unknown as HospitalRequest);
  }
}
