import { Component, OnInit, ViewChild, DestroyRef, inject, AfterViewInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectionModel } from '@angular/cdk/collections';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableModule } from '@angular/material/table';
import { VexPageLayoutComponent } from 'src/@vex/components/vex-page-layout/vex-page-layout.component';
import { VexBreadcrumbsComponent } from 'src/@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutHeaderDirective } from 'src/@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutContentDirective } from 'src/@vex/components/vex-page-layout/vex-page-layout-content.directive';

import { HospitalRequestService } from './hospital-request.service';
import { HospitalRequest, RequestItem, RequestStatus, ItemType } from './hospital-request.model';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { HospitalRequestCreateUpdateComponent } from './hospital-request-create-update/hospital-request-create-update.component';

@Component({
  selector: 'vex-hospital-requests',
  templateUrl: './hospital-requests.component.html',
  styleUrls: ['./hospital-requests.component.scss'],
  animations: [
    fadeInUp400ms,
    stagger40ms
  ],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatCheckboxModule,
    MatButtonToggleModule,
    MatMenuModule,
    TranslateModule,
    VexPageLayoutComponent,
    VexBreadcrumbsComponent,
    VexPageLayoutHeaderDirective,
    VexPageLayoutContentDirective
  ]
})
export class HospitalRequestsComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  private readonly destroyRef: DestroyRef = inject(DestroyRef);

  // Form controls
  layoutCtrl = new FormControl('fullwidth');
  searchCtrl = new FormControl();

  // Data source and selection
  dataSource: MatTableDataSource<HospitalRequest> = new MatTableDataSource();
  selection = new SelectionModel<HospitalRequest>(true, []);

  // RxJS subjects
  subject$: ReplaySubject<HospitalRequest[]> = new ReplaySubject<HospitalRequest[]>(1);
  data$: Observable<HospitalRequest[]> = this.subject$.asObservable();

  // Status filter
  statusFilter: RequestStatus | 'all' = 'all';

  // Table columns
  columns: TableColumn<HospitalRequest>[] = [
    { label: 'Checkbox', property: 'checkbox', type: 'checkbox', visible: true },
    { label: 'Request #', property: 'requestNumber', type: 'text', visible: true },
    { label: 'Hospital', property: 'hospitalName', type: 'text', visible: true },
    { label: 'Department', property: 'departmentName', type: 'text', visible: true },
    { label: 'Requested By', property: 'requestedBy', type: 'text', visible: true },
    { label: 'Total', property: 'totalAmount', type: 'number', visible: true },
    { label: 'Status', property: 'status', type: 'badge', visible: true },
    { label: 'Created Date', property: 'createdDate', type: 'date', visible: true },
    { label: 'Actions', property: 'actions', type: 'button', visible: true }
  ];

  // Status options
  statusOptions = [
    { value: 'all', label: 'All Statuses' },
    { value: RequestStatus.New, label: 'New' },
    { value: RequestStatus.Pending, label: 'Pending' },
    { value: RequestStatus.Approved, label: 'Approved' },
    { value: RequestStatus.Canceled, label: 'Canceled' }
  ];

  // Item type options
  itemTypes = [
    { value: ItemType.Medicine, label: 'Medicine' },
    { value: ItemType.Equipment, label: 'Equipment' },
    { value: ItemType.Supply, label: 'Supply' }
  ];

  constructor(
    private hospitalRequestService: HospitalRequestService,
    private dialog: MatDialog,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    this.hospitalRequestService.getHospitalRequests().subscribe(requests => {
      this.subject$.next(requests);
    });

    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter<HospitalRequest[]>(Boolean)
    ).subscribe(requests => {
      this.dataSource.data = requests;
    });

    this.searchCtrl.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(value => this.onFilterChange(value));
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  /**
   * Filter data based on search term
   */
  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  /**
   * Toggle column visibility
   */
  toggleColumnVisibility(column: TableColumn<HospitalRequest>, event: Event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }

  /**
   * Open create request dialog
   */
  createRequest() {
    this.dialog.open(HospitalRequestCreateUpdateComponent, {
      width: '800px',
      data: {
        mode: 'create'
      }
    }).afterClosed().subscribe((newRequest: HospitalRequest) => {
      if (newRequest) {
        this.hospitalRequestService.getHospitalRequests().subscribe();
      }
    });
  }

  /**
   * Open edit request dialog
   */
  updateRequest(request: HospitalRequest) {
    this.dialog.open(HospitalRequestCreateUpdateComponent, {
      width: '800px',
      data: {
        mode: 'update',
        request: request
      }
    }).afterClosed().subscribe((updatedRequest: HospitalRequest) => {
      if (updatedRequest) {
        this.hospitalRequestService.getHospitalRequests().subscribe();
      }
    });
  }

  /**
   * View request details
   */
  viewRequest(request: HospitalRequest) {
    this.dialog.open(HospitalRequestCreateUpdateComponent, {
      width: '800px',
      data: {
        mode: 'view',
        request: request
      }
    });
  }

  /**
   * Delete request
   */
  deleteRequest(request: HospitalRequest) {
    if (confirm(`Are you sure you want to delete request ${request.requestNumber}?`)) {
      this.hospitalRequestService.deleteHospitalRequest(request.id).subscribe(success => {
        if (success) {
          this.hospitalRequestService.getHospitalRequests().subscribe();
        }
      });
    }
  }

  /**
   * Change request status
   */
  changeStatus(request: HospitalRequest, status: RequestStatus) {
    this.hospitalRequestService.changeRequestStatus(request.id, status).subscribe(updatedRequest => {
      if (updatedRequest) {
        this.hospitalRequestService.getHospitalRequests().subscribe();
      }
    });
  }

  /**
   * Resubmit canceled request
   */
  resubmitRequest(request: HospitalRequest) {
    if (request.status === RequestStatus.Canceled) {
      this.hospitalRequestService.resubmitCanceledRequest(request.id).subscribe(newRequest => {
        if (newRequest) {
          this.hospitalRequestService.getHospitalRequests().subscribe();
        }
      });
    }
  }

  /**
   * Filter requests by status
   */
  filterByStatus(status: RequestStatus | 'all') {
    this.statusFilter = status;

    if (status === 'all') {
      this.hospitalRequestService.getHospitalRequests().subscribe(requests => {
        this.subject$.next(requests);
      });
    } else {
      this.hospitalRequestService.getHospitalRequests().subscribe(requests => {
        const filteredRequests = requests.filter(request => request.status === status);
        this.subject$.next(filteredRequests);
      });
    }
  }

  /**
   * Get badge color based on status
   */
  getBadgeColor(status: RequestStatus): { text: string, background: string } {
    switch(status) {
      case RequestStatus.New:
        return { text: 'text-blue', background: 'bg-blue-100' };
      case RequestStatus.Pending:
        return { text: 'text-orange', background: 'bg-orange-100' };
      case RequestStatus.Approved:
        return { text: 'text-green', background: 'bg-green-100' };
      case RequestStatus.Canceled:
        return { text: 'text-red', background: 'bg-red-100' };
      default:
        return { text: 'text-gray', background: 'bg-gray-100' };
    }
  }

  /**
   * Check if all rows are selected
   */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /**
   * Toggle all rows selection
   */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /**
   * Track property for columns
   */
  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }
}
