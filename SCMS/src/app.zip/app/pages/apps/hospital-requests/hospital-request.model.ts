export enum RequestStatus {
  New = 0,
  Pending = 1,
  Approved = 2,
  Canceled = 3
}

export enum ItemType {
  Medicine = 'Medicine',
  Equipment = 'Equipment',
  Supply = 'Supply'
}

export interface RequestItem {
  id: number;
  name: string;
  quantity: number;
  type: ItemType;
  unitPrice: number;
  totalPrice: number;
  isDisabled?: boolean;
  notes?: string;
}

export interface HospitalRequest {
  id: number;
  requestNumber: string;
  hospitalName: string;
  departmentName: string;
  status: RequestStatus;
  createdDate: Date;
  updatedDate?: Date;
  requestedBy: string;
  approvedBy?: string;
  totalAmount: number;
  items: RequestItem[];
  notes?: string;
}
