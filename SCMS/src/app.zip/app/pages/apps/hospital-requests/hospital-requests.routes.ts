import { Routes } from '@angular/router';
import { HospitalRequestsComponent } from './hospital-requests.component';

export const HOSPITAL_REQUESTS_ROUTES: Routes = [
  {
    path: '',
    component: HospitalRequestsComponent
  }
];
