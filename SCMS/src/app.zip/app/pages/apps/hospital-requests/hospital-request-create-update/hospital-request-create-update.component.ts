import { Component, Inject, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { CdkDragDrop, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';
import { TranslateModule } from '@ngx-translate/core';
import { HospitalRequest, ItemType, RequestItem, RequestStatus } from '../hospital-request.model';

export interface HospitalRequestCreateUpdateData {
  request?: HospitalRequest;
  mode: 'create' | 'update' | 'view';
}

@Component({
  selector: 'vex-hospital-request-create-update',
  templateUrl: './hospital-request-create-update.component.html',
  styleUrls: ['./hospital-request-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    ReactiveFormsModule,
    DragDropModule,
    TranslateModule
  ]
})
export class HospitalRequestCreateUpdateComponent implements OnInit {
  form: FormGroup;
  mode: 'create' | 'update' | 'view';
  editingIndex: number = -1;

  statusOptions = [
    { value: RequestStatus.New, label: 'New' },
    { value: RequestStatus.Pending, label: 'Pending' },
    { value: RequestStatus.Approved, label: 'Approved' },
    { value: RequestStatus.Canceled, label: 'Canceled' }
  ];

  itemTypeOptions = [
    { value: ItemType.Equipment, label: 'Equipment' },
    { value: ItemType.Medicine, label: 'Medicine' },
    { value: ItemType.Supply, label: 'Supply' }
  ];

  get isCreateMode(): boolean {
    return this.mode === 'create';
  }

  get isUpdateMode(): boolean {
    return this.mode === 'update';
  }

  get isViewMode(): boolean {
    return this.mode === 'view';
  }

  get items(): FormArray {
    return this.form.get('items') as FormArray;
  }

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: HospitalRequestCreateUpdateData,
    private dialogRef: MatDialogRef<HospitalRequestCreateUpdateComponent>,
    private fb: FormBuilder
  ) {
    this.mode = data.mode;
  }

  ngOnInit() {
    this.form = this.fb.group({
      hospitalName: ['', Validators.required],
      departmentName: ['', Validators.required],
      requestedBy: ['', Validators.required],
      status: [RequestStatus.New, Validators.required],
      notes: [''],
      items: this.fb.array([])
    });

    if (this.data.request) {
      this.form.patchValue({
        hospitalName: this.data.request.hospitalName,
        departmentName: this.data.request.departmentName,
        requestedBy: this.data.request.requestedBy,
        status: this.data.request.status,
        notes: this.data.request.notes
      });

      // Load items
      if (this.data.request.items && this.data.request.items.length > 0) {
        this.data.request.items.forEach(item => {
          this.items.push(this.createItemFormGroup(item));
        });
      }
    }

    // Disable form if in view mode
    if (this.isViewMode) {
      this.form.disable();
    }
  }

  createItemFormGroup(item?: RequestItem): FormGroup {
    return this.fb.group({
      id: [item?.id],
      name: [item?.name || '', Validators.required],
      type: [item?.type || ItemType.Supply, Validators.required],
      quantity: [item?.quantity || 1, [Validators.required, Validators.min(1)]],
      unitPrice: [item?.unitPrice || 0, [Validators.required, Validators.min(0)]],
      totalPrice: [item?.totalPrice || 0],
      notes: [item?.notes || ''],
      isDisabled: [item?.isDisabled || false]
    });
  }

  addItem() {
    this.items.push(this.createItemFormGroup());
    this.editItem(this.items.length - 1);
  }

  editItem(index: number) {
    this.editingIndex = index;
  }

  saveItemEdit() {
    if (this.editingIndex !== -1) {
      const itemControl = this.items.at(this.editingIndex);
      if (itemControl.valid) {
        // Calculate total price
        const quantity = itemControl.get('quantity')?.value || 0;
        const unitPrice = itemControl.get('unitPrice')?.value || 0;
        itemControl.get('totalPrice')?.setValue(quantity * unitPrice);
        this.editingIndex = -1;
      }
    }
  }

  cancelEdit() {
    // If it's a new item and nothing has been filled, remove it
    if (this.editingIndex === this.items.length - 1) {
      const itemControl = this.items.at(this.editingIndex);
      if (!itemControl.get('name')?.value) {
        this.items.removeAt(this.editingIndex);
      }
    }
    this.editingIndex = -1;
  }

  removeItem(index: number) {
    this.items.removeAt(index);
  }

  toggleItemDisabled(index: number) {
    const item = this.items.at(index);
    const currentValue = item.get('isDisabled')?.value;
    item.get('isDisabled')?.setValue(!currentValue);
  }

  dropItem(event: CdkDragDrop<any[]>) {
    moveItemInArray(this.items.controls, event.previousIndex, event.currentIndex);
  }

  getTotalActiveItems(): number {
    return this.items.controls.filter(item => !item.get('isDisabled')?.value).length;
  }

  calculateTotalAmount(): number {
    return this.items.controls
      .filter(item => !item.get('isDisabled')?.value)
      .reduce((total, item) => {
        const quantity = item.get('quantity')?.value || 0;
        const unitPrice = item.get('unitPrice')?.value || 0;
        return total + (quantity * unitPrice);
      }, 0);
  }

  save() {
    if (this.form.invalid) {
      return;
    }

    const formValue = this.form.getRawValue();
    const request: HospitalRequest = {
      id: this.data.request?.id || Math.floor(Math.random() * 10000),
      requestNumber: this.data.request?.requestNumber || `REQ-${new Date().getTime()}`,
      hospitalName: formValue.hospitalName,
      departmentName: formValue.departmentName,
      status: formValue.status,
      requestedBy: formValue.requestedBy,
      approvedBy: this.data.request?.approvedBy,
      items: formValue.items,
      createdDate: this.data.request?.createdDate || new Date(),
      updatedDate: new Date(),
      totalAmount: this.calculateTotalAmount(),
      notes: formValue.notes
    };

    this.dialogRef.close(request);
  }
}
