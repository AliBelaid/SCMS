import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { Drug, PharmaceuticalsService } from '../pharmaceuticals.service';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-drug-create-update',
  templateUrl: './drug-create-update.component.html',
  styleUrls: ['./drug-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDividerModule,
    TranslateModule
  ]
})
export class DrugCreateUpdateComponent implements OnInit {

  form: UntypedFormGroup;
  mode: 'create' | 'update' = 'create';

  constructor(@Inject(MAT_DIALOG_DATA) public defaults: Drug,
              private dialogRef: MatDialogRef<DrugCreateUpdateComponent>,
              private fb: UntypedFormBuilder,
              private pharmaceuticalsService: PharmaceuticalsService) {
  }

  ngOnInit(): void {
    console.log(this.defaults)
    if (this.defaults!==null) {
      this.mode = 'update';
      this.form = this.fb.group({
        id: [this.defaults.id],
        englishName: [this.defaults.englishName, Validators.required],
        arabicName: [this.defaults.arabicName, Validators.required],
        activeIngredient: [this.defaults.activeIngredient, Validators.required],
        company: [this.defaults.company, Validators.required],
        classification: [this.defaults.classification, Validators.required],
        units: [this.defaults.units, [Validators.required, Validators.min(1)]],
        form: [this.defaults.form, Validators.required],
        barcode: [this.defaults.barcode, Validators.required]
      });
    } else {
      console.log('neeewww')
      this.form = this.fb.group({
        englishName: ['', Validators.required],
        arabicName: ['', Validators.required],
        activeIngredient: ['', Validators.required],
        company: ['', Validators.required],
        classification: ['', Validators.required],
        units: [1, [Validators.required, Validators.min(1)]],
        form: ['', Validators.required],
        barcode: ['', Validators.required]
      });
    }
  }

  save(): void {
    if (this.form.valid) {
      if (this.mode === 'create') {
        this.createDrug();
      } else if (this.mode === 'update') {
        this.updateDrug();
      }
    }
  }

  createDrug(): void {
    const drug: Drug = this.form.value;
    console.log(drug)
    this.pharmaceuticalsService.createDrug(drug).subscribe(response => {
      this.dialogRef.close(response);
    }, error => {
      console.error('Error creating drug:', error);
    });
  }

  updateDrug(): void {
    const drug: Drug = this.form.value;
    drug.id = this.defaults.id;
    this.pharmaceuticalsService.updateDrug(drug.id, drug).subscribe(response => {
      this.dialogRef.close(response);
    }, error => {
      console.error('Error updating drug:', error);
    });
  }

  isCreateMode(): boolean {
    return this.mode === 'create';
  }

  isUpdateMode(): boolean {
    return this.mode === 'update';
  }
}
