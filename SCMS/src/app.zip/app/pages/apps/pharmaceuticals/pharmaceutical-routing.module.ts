import { Routes } from "@angular/router";
import { PharmaceuticalComponent } from "./pharmaceutical.component";



 
export const   Pharmaceutical_ROUTES: Routes = [
  {
    path: '',
    component: PharmaceuticalComponent
  }
];
 
