import { Drug, PharmaceuticalsService } from './pharmaceuticals.service';
import { AfterViewInit, Component, DestroyRef, inject, Input, OnInit, ViewChild } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { SelectionModel } from '@angular/cdk/collections';

import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { aioTableLabels, aioTableData } from 'src/static-data/aio-table-data';
import { DrugCreateUpdateComponent } from './drug-create-update/drug-create-update.component';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { MatButtonToggleModule } from '@angular/material/button-toggle';


@Component({
  selector: 'vex-pharmaceutical',
  templateUrl: './pharmaceutical.component.html',
  styleUrls: ['./pharmaceutical.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    TranslateModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatMenuModule,
    VexBreadcrumbsComponent,
    VexPageLayoutComponent,
    VexPageLayoutHeaderDirective,
    VexPageLayoutContentDirective,
    NgIf,
    NgFor,
    NgClass,
    MatButtonToggleModule
  ],
  animations: [
    fadeInUp400ms,
    stagger40ms
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'standard'
      } as unknown as MatFormFieldDefaultOptions
    }
  ]
})
export class PharmaceuticalComponent implements OnInit, AfterViewInit {

  layoutCtrl = new UntypedFormControl('fullwidth');

  /**
   * Simulating a service with HTTP that returns Observables
   * You probably want to remove this and do all requests in a service with HTTP
   */
  subject$: ReplaySubject<Drug[]> = new ReplaySubject<Drug[]>(1);
  data$: Observable<Drug[]> = this.subject$.asObservable();
  Pharmaceuticals: Drug[];

  @Input()
  columns: TableColumn<Drug>[] = [

       { label: this.translate.instant('ENGLISH_NAME'), property: 'englishName', type: 'text', visible: true },
      { label: this.translate.instant('ARABIC_NAME'), property: 'arabicName', type: 'text', visible: true },
      { label: this.translate.instant('ACTIVE_INGREDIENT'), property: 'activeIngredient', type: 'text', visible: true },
      { label: this.translate.instant('COMPANY'), property: 'company', type: 'text', visible: true },
      { label: this.translate.instant('CLASSIFICATION'), property: 'classification', type: 'text', visible: true },
      { label: this.translate.instant('UNITS'), property: 'units', type: 'text', visible: true },
      { label: this.translate.instant('FORM'), property: 'form', type: 'text', visible: true },
      { label: this.translate.instant('BARCODE'), property: 'barcode', type: 'text', visible: true }
    ];

  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<Drug> | null;
  selection = new SelectionModel<Drug>(true, []);
  searchCtrl = new UntypedFormControl();

  labels = aioTableLabels;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private dialog: MatDialog ,private PharmaceuticalsService:PharmaceuticalsService ,private translate:TranslateService) {
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  /**
   * Example on how to get data and pass it to the table - usually you would want a dedicated service with a HTTP request for this
   * We are simulating this request here.
   */

  ngOnInit() {
    this.PharmaceuticalsService.getDrugs().subscribe(Pharmaceuticals => {
      this.subject$.next(Pharmaceuticals);
    });

    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter<Drug[]>(Boolean)
    ).subscribe(Pharmaceuticals => {
      this.Pharmaceuticals = Pharmaceuticals;
      this.dataSource.data = Pharmaceuticals;
    });

       this.searchCtrl.valueChanges
         .pipe(takeUntilDestroyed(this.destroyRef))
         .subscribe((value) => this.onFilterChange(value));
    }
    private readonly destroyRef: DestroyRef = inject(DestroyRef);

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createPharmaceutical() {
    const dialogRef = this.dialog.open(DrugCreateUpdateComponent, {
      minWidth: '600px',
      minHeight:'750px',
    }).afterClosed().subscribe((Pharmaceutical: any) => {
      /**
       * Pharmaceutical is the updated Pharmaceutical (if the user pressed Save - otherwise it's null)
       */
      if (Pharmaceutical) {
        /**
         * Here we are updating our local array.
         * You would probably make an HTTP request here.
         */


        this.PharmaceuticalsService.createDrug(Pharmaceutical).subscribe((rep)=> {
          this.Pharmaceuticals.unshift( Pharmaceutical);
          this.subject$.next(this.Pharmaceuticals);
        })

      }
    });
  }

  updatePharmaceutical(Pharmaceutical: Drug) {
    this.dialog.open(DrugCreateUpdateComponent, {
      data: Pharmaceutical
    }).afterClosed().subscribe(updatedPharmaceutical => {
      /**
       * Pharmaceutical is the updated Pharmaceutical (if the user pressed Save - otherwise it's null)
       */
      if (updatedPharmaceutical) {
        /**
         * Here we are updating our local array.
         * You would probably make an HTTP request here.
         */


        this.PharmaceuticalsService.updateDrug(updatedPharmaceutical.id,updatedPharmaceutical).subscribe((rep)=> {
        const index = this.Pharmaceuticals.findIndex((existingPharmaceutical) => existingPharmaceutical.id === updatedPharmaceutical.id);
        this.Pharmaceuticals[index] = (updatedPharmaceutical);
        this.subject$.next(this.Pharmaceuticals);
      })}
    });
  }

  deletePharmaceutical(Pharmaceutical: Drug) {
    /**
     * Here we are updating our local array.
     * You would probably make an HTTP request here.
     */

    this.PharmaceuticalsService.deleteDrug(Pharmaceutical.id).subscribe((rep)=> {

    this.Pharmaceuticals.splice(this.Pharmaceuticals.findIndex((existingPharmaceutical) => existingPharmaceutical.id === Pharmaceutical.id), 1);
    this.selection.deselect(Pharmaceutical);
    this.subject$.next(this.Pharmaceuticals);
  }); }

  deletePharmaceuticals(Pharmaceuticals: Drug[]) {
    /**
     * Here we are updating our local array.
     * You would probably make an HTTP request here.
     */
    Pharmaceuticals.forEach(c => this.deletePharmaceutical(c));
  }

  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  toggleColumnVisibility(column, event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }

  onLabelChange(change: MatSelectChange, row: Drug) {
    const index = this.Pharmaceuticals.findIndex(c => c === row);
    this.Pharmaceuticals[index].id = change.value;
    this.subject$.next(this.Pharmaceuticals);
  }
}

