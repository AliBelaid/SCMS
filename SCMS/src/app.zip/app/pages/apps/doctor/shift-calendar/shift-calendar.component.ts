import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'vex-shift-calendar',
  templateUrl: './shift-calendar.component.html',
  styleUrls: ['./shift-calendar.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    TranslateModule
  ]
})
export class ShiftCalendarComponent implements OnInit {
  form: UntypedFormGroup;
  weekDays = [
    { value: 0, label: 'SUNDAY' },
    { value: 1, label: 'MONDAY' },
    { value: 2, label: 'TUESDAY' },
    { value: 3, label: 'WEDNESDAY' },
    { value: 4, label: 'THURSDAY' },
    { value: 5, label: 'FRIDAY' },
    { value: 6, label: 'SATURDAY' }
  ];

  constructor(private fb: UntypedFormBuilder) {}

  ngOnInit() {
    this.form = this.fb.group({
      weekDay: ['', Validators.required],
      startTime: ['', Validators.required],
      endTime: ['', Validators.required],
      maxPatients: [10, [Validators.required, Validators.min(1)]],
      isRecurring: [true]
    });
  }

  save() {
    if (this.form.valid) {
      // Handle form submission
      console.log(this.form.value);
    }
  }
}
