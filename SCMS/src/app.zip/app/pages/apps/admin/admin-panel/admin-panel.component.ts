import { Component, OnInit } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { MatTabsModule, MatTabChangeEvent } from '@angular/material/tabs';
import { Router, RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { FormsModule, ReactiveFormsModule, UntypedFormControl, FormControl } from '@angular/forms';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RolesManagementComponent } from '../Modals/roles-management/roles-management.component';
import { RequestManagementComponent } from '../Modals/request-management/request-management.component';
import { SpecialtiesManagementComponent } from '../Modals/specialties-management/specialties-management.component';
import { UserManagementComponent } from '../user-management/user-management.component';
import { CategoryManagementComponent } from '../category-management/category-management.component';

import { fadeInUp400ms } from '@vex/animations/fade-in-up.animation';
import { stagger40ms } from '@vex/animations/stagger.animation';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.scss'],
  animations: [
    fadeInUp400ms,
    stagger40ms,
    trigger('tabTransition', [
      state('void', style({
        opacity: 0,
        transform: 'translateY(10px)'
      })),
      state('*', style({
        opacity: 1,
        transform: 'translateY(0)'
      })),
      transition('void => *', animate('300ms ease-in')),
      transition('* => void', animate('300ms ease-out'))
    ])
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'outline'
      } as unknown as MatFormFieldDefaultOptions
    }
  ],
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatMenuModule,
    MatInputModule,
    VexBreadcrumbsComponent,
    VexPageLayoutComponent,
    VexPageLayoutHeaderDirective,
    VexPageLayoutContentDirective,
    MatButtonToggleModule,
    NgIf,
    NgFor,
    NgClass,
    MatDividerModule,
    MatListModule,
    TranslateModule,
    MatTabsModule,
    RouterModule,
   RolesManagementComponent,
   RequestManagementComponent,
   UserManagementComponent,
    SpecialtiesManagementComponent,
    CategoryManagementComponent
  ]
})
export class AdminPanelComponent implements OnInit {
  layoutCtrl = new FormControl('fullwidth');
  breadcrumbs: string[] = ['Admin', 'User Management'];
  isTableExpanded = false;

  constructor(private router: Router) {}

  ngOnInit(): void {}

  onTabChange(event: MatTabChangeEvent): void {
    const tabIndex = event.index;
    if (tabIndex === 0) {
      this.breadcrumbs = ['Admin', 'User Management'];
      this.router.navigate(['/admin/user-management']);
    } else if (tabIndex === 1) {
      this.breadcrumbs = ['Admin', 'Category Management'];
      this.router.navigate(['/admin/category-management']);
    } else if (tabIndex === 2) {
      this.breadcrumbs = ['Admin', 'Request Management'];
      this.router.navigate(['/admin/request-management']);
    }
  }
}
