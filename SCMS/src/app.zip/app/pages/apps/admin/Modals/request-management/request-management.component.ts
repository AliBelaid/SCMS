import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { RequestDetailsDialogComponent } from '../request-details-dialog/request-details-dialog.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { Request } from 'src/app/models/request.model';
import { CommonModule, NgIf, NgFor, NgClass } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { 
  VexBreadcrumbsComponent,
  VexPageLayoutComponent,
  VexPageLayoutContentDirective,
  VexPageLayoutHeaderDirective
} from '@vex/components';
import { RolesManagementComponent } from '../roles-management/roles-management.component';
import { SpecialtiesManagementComponent } from '../specialties-management/specialties-management.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { CreateRequestDialogComponent } from '../create-request-dialog/create-request-dialog.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-request-management',
  templateUrl: './request-management.component.html',
  styleUrls: ['./request-management.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatMenuModule,
    MatInputModule,
    VexBreadcrumbsComponent,
    VexPageLayoutComponent,
    VexPageLayoutHeaderDirective,
    VexPageLayoutContentDirective,
    MatButtonToggleModule,
    NgIf,
    NgFor,
    NgClass,
    MatDividerModule,
    MatListModule,
    TranslateModule,
    MatTabsModule,
    MatDatepickerModule,
    RouterModule,
    RolesManagementComponent,
    SpecialtiesManagementComponent,
    MatCardModule,
    MatExpansionModule,
    MatProgressSpinnerModule
  ]
})
export class RequestManagementComponent implements OnInit {
  requests: Request[] = [];
  filteredRequests: Request[] = [];
  loading = false;
  error: string | null = null;

  filters = {
    status: '',
    type: '',
    priority: '',
    dateFrom: '',
    dateTo: ''
  };

  constructor(
    private requestService: RequestService,
    private dialog: MatDialog,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.loadRequests();
  }

  loadRequests(): void {
    this.loading = true;
    this.error = null;

    this.requestService.getRequests().subscribe({
      next: (requests) => {
        this.requests = requests;
        this.filteredRequests = requests;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load requests. Please try again later.';
        this.loading = false;
        console.error('Error loading requests:', err);
      }
    });
  }

  applyFilters(): void {
    this.loading = true;
    this.error = null;

    this.requestService.filterRequests(this.filters).subscribe({
      next: (requests) => {
        this.filteredRequests = requests;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to filter requests. Please try again later.';
        this.loading = false;
        console.error('Error filtering requests:', err);
      }
    });
  }

  clearFilters(): void {
    this.filters = {
      status: '',
      type: '',
      priority: '',
      dateFrom: '',
      dateTo: ''
    };
    this.loadRequests();
  }

  viewDetails(request: Request): void {
    const dialogRef = this.dialog.open(RequestDetailsDialogComponent, {
      width: '600px',
      data: request
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadRequests();
      }
    });
  }

  createNewRequest(): void {
    const dialogRef = this.dialog.open(CreateRequestDialogComponent, {
      width: '600px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.requestService.createRequest(result).subscribe({
          next: () => {
            this.toastr.success('Request created successfully');
            this.loadRequests();
          },
          error: (err) => {
            this.toastr.error('Failed to create request');
            console.error('Error creating request:', err);
          }
        });
      }
    });
  }

  approveRequest(request: Request): void {
    this.loading = true;
    this.error = null;

    this.requestService.approveRequest(request.id).subscribe({
      next: () => {
        this.toastr.success('Request approved successfully');
        this.loadRequests();
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to approve request. Please try again later.';
        this.toastr.error('Failed to approve request');
        this.loading = false;
        console.error('Error approving request:', err);
      }
    });
  }

  rejectRequest(request: Request): void {
    this.loading = true;
    this.error = null;

    this.requestService.rejectRequest(request.id).subscribe({
      next: () => {
        this.toastr.success('Request rejected successfully');
        this.loadRequests();
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to reject request. Please try again later.';
        this.toastr.error('Failed to reject request');
        this.loading = false;
        console.error('Error rejecting request:', err);
      }
    });
  }
}
