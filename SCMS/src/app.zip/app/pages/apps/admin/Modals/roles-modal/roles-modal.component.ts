import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Clinic, IUserNew, Role } from 'src/assets/user';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { SpecialtiesService } from '../../../../../../assets/services/specialty.service';
import { TranslateModule } from '@ngx-translate/core';
import { CategoryService } from 'src/assets/his.model';
import { AdminService } from '../../admin.service';
import { TranslateService } from '@ngx-translate/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { CategoriesService } from 'src/app/services/category.service';
import { MatIconModule } from '@angular/material/icon';
 
@Component({
  selector: 'app-roles-modal',
  templateUrl: './roles-modal.component.html',
  styleUrls: ['./roles-modal.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    TranslateModule,
    MatSelectModule,
    NgFor,
    MatSlideToggleModule,
    NgIf,
    MatTabsModule,
    MatIconModule
  ]
})
export class RolesModalComponent implements OnInit {
  user: IUserNew;
  roles: Role[] = [];
  clinics: Clinic[] = [];
  categories: any[] = [];
  specialties: any[] = [];
  rolesForm: FormGroup;
  selectedRole: any;
  
  constructor(
    public dialogRef: MatDialogRef<RolesModalComponent>,
    private specialtyService: SpecialtiesService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private adminService: AdminService,
    private translate: TranslateService,
    private snackBar: MatSnackBar,
    private categoriesService: CategoriesService
  ) {
    console.log(data)
    this.user = data?.user;
    this.roles = data?.roles || [];
    this.selectedRole = this.roles.filter(i => i.name === 'Reception');
    this.specialties = data?.specialties || [];
    this.clinics = data?.clinics || [];
    this.categories = data?.categories || [];
  }

  ngOnInit(): void {
    this.loadRoles();
    this.loadClinics();
    this.loadCategories();
  }

  loadRoles(): void {
    console.log('User data:', this.user);
    console.log('User roles before initialization:', this.user.roles);
    
    // Create a fresh array of roles with proper checked states
    this.roles = [
      { name: 'Admin', checked: false },
      { name: 'Doctor', checked: false },
      { name: 'Patient', checked: false },
      { name: 'Pharmacy', checked: false },
      { name: 'Reception', checked: false },
      { name: 'LAB', checked: false },
      { name: 'Emergency', checked: false },
      { name: 'Surgery', checked: false },
      { name: 'Imaging', checked: false },
      { name: 'Insurance', checked: false },
      { name: 'Hospital', checked: false },
      { name: 'Finance', checked: false },
      { name: 'Treasury', checked: false },
      { name: 'MedicalTechnician', checked: false }
    ];

    // Set initial checked state based on user's current roles
    if (this.user.roles && Array.isArray(this.user.roles)) {
      console.log('Setting initial role checked states from:', this.user.roles);
      this.roles.forEach(role => {
        role.checked = this.user.roles.includes(role.name);
        console.log(`Role ${role.name}: ${role.checked ? 'checked' : 'unchecked'}`);
      });
    } else {
      console.warn('User roles are not properly defined:', this.user.roles);
    }
  }

  loadClinics(): void {
    this.adminService.getClinics().subscribe(
      (clinics: any[]) => {
        this.clinics = clinics },
     
      error => {
        console.error('Error loading clinics:', error);
        this.snackBar.open(
          this.translate.instant('ERROR_LOADING_CLINICS'),
          this.translate.instant('CLOSE'),
          { duration: 3000 }
        );
      }
    );
  }

  loadCategories(): void {
    this.categoriesService.getAllCategories().subscribe(
      (categories: any[]) => {
        this.categories = categories.map(category => ({
          id: Number(category.id),
          name: category.name,
          checked: this.user.enabledCategories?.some(c => Number(c) === Number(category.id)) || false
        }));
        console.log('Loaded categories:', this.categories);
      },
      error => {
        console.error('Error loading categories:', error);
        this.snackBar.open(
          this.translate.instant('ERROR_LOADING_CATEGORIES'),
          this.translate.instant('CLOSE'),
          { duration: 3000 }
        );
      }
    );
  }

  addSpecialtyToUser(userId: number, specialtyId: number) {
    this.specialtyService.addSpecialtyToUser(userId, specialtyId).subscribe(response => {
      console.log(response);
    }, error => {
      console.error(error);
    });
  }

  removeSpecialtyFromUser(userId: number, specialtyId: number) {
    this.specialtyService.removeSpecialtyFromUser(userId, specialtyId).subscribe(response => {
      console.log(response);
    }, error => {
      console.error(error);
    });
  }

  getUsersBySpecialty(specialtyId: number) {
    this.specialtyService.getUsersBySpecialty(specialtyId).subscribe(response => {
      console.log(response);
    }, error => {
      console.error(error);
    });
  }

  closeDialog() {
    this.dialogRef.close();
  }
  
  toggleCategory(category: any): void {
    category.checked = !category.checked;
  }

  updateRoles(): void {
    const selectedRoles = this.roles.filter(role => role.checked).map(role => role.name);
    console.log('Selected roles:', selectedRoles);
    const selectedClinicIds = this.clinics.filter(clinic => clinic.checked).map(clinic => clinic.id);
    console.log('Selected clinics:', selectedClinicIds);
    const selectedCategories = this.categories
      .filter(category => category.checked)
      .map(category => category.id);

    console.log('Sending roles update with:', {
      roles: selectedRoles,
      clinicIds: selectedClinicIds,
      categories: selectedCategories
    });

    this.adminService.updateUserRolesAndRegions(
      this.user.id,
      selectedRoles,
      selectedClinicIds,
      selectedCategories
    ).subscribe(
      response => {
        console.log('Role update successful:', response);
        this.snackBar.open(
          this.translate.instant('ROLES_UPDATED_SUCCESSFULLY'),
          this.translate.instant('CLOSE'),
          { duration: 3000 }
        );
        this.dialogRef.close(true);
      },
      error => {
        console.error('Error updating roles:', error);
        this.snackBar.open(
          this.translate.instant('ERROR_UPDATING_ROLES'),
          this.translate.instant('CLOSE'),
          { duration: 3000 }
        );
      }
    );
  }

  trackByRole(index: number, role: Role): string {
    return role.name;
  }

  trackByClinic(index: number, clinic: Clinic): number {
    return clinic.id;
  }

  trackByCategory(index: number, category: any): number {
    return category.id;
  }

  // Get the appropriate icon for each role
  getRoleIcon(roleName: string): string {
    const roleIcons = {
      'Admin': 'mat:admin_panel_settings',
      'Doctor': 'mat:medical_services',
      'Patient': 'mat:personal_injury',
      'Pharmacy': 'mat:medication',
      'Reception': 'mat:people',
      'LAB': 'mat:biotech',
      'Emergency': 'mat:emergency',
      'Surgery': 'mat:medical_information',
      'Imaging': 'mat:image',
      'Insurance': 'mat:health_and_safety',
      'Hospital': 'mat:local_hospital',
      'Finance': 'mat:payments',
      'Treasury': 'mat:account_balance',
      'MedicalTechnician': 'mat:engineering'
    };

    return roleIcons[roleName] || 'mat:security';
  }
}
