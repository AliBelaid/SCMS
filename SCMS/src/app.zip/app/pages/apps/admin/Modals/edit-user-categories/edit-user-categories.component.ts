import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule, NgFor } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { TranslateModule } from '@ngx-translate/core';
import { IUserNew } from 'src/assets/user';
import { AdminService } from 'src/app/pages/apps/admin/admin.service';
import { ToastrService } from 'ngx-toastr';
import { CategoryService } from 'src/assets/his.model';

interface CheckedCategory extends CategoryService {
  checked: boolean;
}

interface Clinic {
  id: number;
  name: string;
  checked: boolean;
}

@Component({
  selector: 'app-edit-user-categories',
  templateUrl: './edit-user-categories.component.html',
  styleUrls: ['./edit-user-categories.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    FormsModule,
    MatIconModule,
    NgFor,
    TranslateModule
  ]
})
export class EditUserCategoriesComponent implements OnInit {
  user: IUserNew;
  categories: CheckedCategory[] = [];
  clinics: Clinic[] = [];
  roles: string[] = [];
  selectedCategories: number[] = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<EditUserCategoriesComponent>,
    private adminService: AdminService,
    private toastr: ToastrService
  ) {
    this.user = data.user;
  }

  ngOnInit(): void {
    this.loadCategories();
    this.loadClinics();
    this.loadRoles();
  }

  loadCategories(): void {
    this.adminService.getCategories().subscribe({
      next: (categories) => {
        this.categories = categories.map(category => ({
          ...category,
          checked: this.data.enabledCategories.includes(category.id)
        }));
      },
      error: (error) => {
        console.error('Error loading categories:', error);
      }
    });
  }

  loadClinics(): void {
    this.adminService.getClinics().subscribe(
      (clinics: any[]) => {
        this.clinics = clinics.map(clinic => ({
          id: clinic.id,
          name: clinic.name,
          checked: this.user.clinics?.some(c => c.id === clinic.id) || false
        }));
      },
      error => {
        console.error('Error loading clinics:', error);
        this.toastr.error('Failed to load clinics');
      }
    );
  }

  loadRoles(): void {
    this.roles = this.user.roles || [];
  }

  toggleCategory(category: CheckedCategory): void {
    category.checked = !category.checked;
  }

  toggleClinic(clinic: Clinic): void {
    clinic.checked = !clinic.checked;
  }

  save(): void {
    const selectedCategories = this.categories
      .filter(category => category.checked)
      .map(category => category.id);

    const selectedClinicIds = this.clinics
      .filter(clinic => clinic.checked)
      .map(clinic => clinic.id);

    this.adminService.updateUserRolesAndRegions(
      this.user.id,
      this.roles,
      selectedClinicIds,
      selectedCategories
    ).subscribe({
      next: () => {
        this.toastr.success('User permissions updated successfully');
        this.user.enabledCategories = selectedCategories;
        this.user.clinics = this.clinics
          .filter(clinic => clinic.checked)
          .map(clinic => ({ 
            id: clinic.id, 
            name: clinic.name,
            doctorsCount: 0 // Default value since we don't have this information
          }));
        this.dialogRef.close(this.user);
      },
      error: (error) => {
        this.toastr.error('Failed to update user permissions');
        console.error('Error updating user permissions:', error);
      }
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }
} 