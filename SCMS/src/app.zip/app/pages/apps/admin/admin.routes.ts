import { Routes } from '@angular/router';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { PhotoManagementComponent } from './photo-management/photo-management.component';
import { CategoryManagementComponent } from './category-management/category-management.component';
import { RequestManagementComponent } from './Modals/request-management/request-management.component';

export const ADMIN_ROUTES: Routes = [
  {
    path: '',
    component: AdminPanelComponent,
    children: [
      {
        path: '',
        redirectTo: 'user-management',
        pathMatch: 'full'
      },
      {
        path: 'user-management',
        component: UserManagementComponent,
        data: {
          title: 'User Management'
        }
      },
      {
        path: 'photo',
        component: PhotoManagementComponent,
        data: {
          title: 'Photo Management'
        }
      },
      {
        path: 'category-management',
        component: CategoryManagementComponent,
        data: {
          title: 'Category Management' 
        }
      },
     {
      path: 'request-management',
      component: RequestManagementComponent,
      data: {
        title: 'Request Management'
      }
     }
    ]
  }
];
