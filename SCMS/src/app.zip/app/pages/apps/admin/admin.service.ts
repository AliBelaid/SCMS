import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, concatMap, map, of, throwError } from 'rxjs';
import { IUser, IUserNew } from 'src/assets/user';
import { environment } from 'src/assets/environments/environment';
import { CategoryService } from 'src/assets/his.model';
import { CategoriesService } from 'src/app/services/category.service';
import { ClinicService } from 'src/assets/services/clinic.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = `${environment.apiUrl}/admin`;
  baseUrl = environment.apiUrl;

  constructor(
    private http: HttpClient,
    private categoriesService: CategoriesService ,
    private clinicService: ClinicService
  ) { }

  getUsers(): Observable<IUserNew[]> {
    return this.http.get<IUserNew[]>(`${this.apiUrl}/users`);
  }

  getClinics(): Observable<any[]> {
    return this.clinicService.getClinics();
  }

  getCategories(): Observable<CategoryService[]> {
    return this.categoriesService.getAllCategories();
  }

  restPassword(userId: number, pwd: string): Observable<any> {
    const data = {
      userId: userId,
      pwd: pwd
    };
    return this.http.post(`${this.baseUrl}/Admin/reset-password/`, data).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error('Error resetting password:', error);
        return throwError(() => new Error(error.message || 'Failed to reset password'));
      })
    );
  }

  deleteAdmin(user: IUserNew | number) {
    const userId = typeof user === 'number' ? user : user.id;
    return this.http.delete(`${this.baseUrl}/Admin/delete-user/${userId}`).pipe(
      map(rep => rep),
      catchError((error: HttpErrorResponse) => {
        console.error('Error deleting user:', error);
        return throwError(() => error);
      })
    );
  }

  getUserWithRoles() {
    return this.http.get<Partial<any[]>>(this.baseUrl + '/Admin/users-with-roles').pipe(map((rep) => {
      console.log(rep)
      return rep;
    }));
  }

  updateUserRoles(username: string, roles: string[]) {
    const data = {
      roles: roles
    };
    return this.http.post<boolean>(`${this.baseUrl}/Admin/edit-roles/${username}`, data).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error('Error updating user roles:', error);
        return throwError(() => error);
      })
    );
  }

  updateUserRegion(username: string, clinicIds: number[]) {
    const data = {
      userId: username,
      regionId: clinicIds
    };
    return this.http.post<any>(`${this.baseUrl}/Admin/add-region-to-user`, data).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error(error);
        return throwError(() => error);
      })
    );
  }

  updateUserRolesAndRegions(userId: number, roles: string[], clinicIds: number[] = [], categories: number[] = []) {
    const data = {
      roles: roles,
      clinicIds: clinicIds,
      categories: categories
    };
    
    return this.http.post(`${this.baseUrl}/Admin/edit-roles/${userId}`, data).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error('Error in updateUserRolesAndRegions:', error);
        return throwError(() => error);
      })
    );
  }

  createUser(newUser: any) {
    console.log('Creating user with data:', newUser);
    return this.http.post(this.baseUrl + '/Admin/create-user', newUser, {
      headers: { 'Content-Type': 'application/json' }
    }).pipe(
      map(response => response),
      catchError((error: HttpErrorResponse) => {
        console.error('Error creating user:', error);
        return throwError(() => error);
      })
    );
  }

  updateUserCategories(username: string, categories: number[]) {
    return this.http.post(`${this.baseUrl}/Admin/edit-user-categories/${username}`, categories).pipe(
      map(response => response)
    );
  }

  // Method to assign clinics to user after creation if needed
  assignClinicsToUser(userId: number, clinicIds: number[]) {
    return this.http.post<any>(`${this.apiUrl}/edit-roles/${userId}`, {
      ClinicIds: clinicIds
    }).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error('Error assigning clinics to user:', error);
        return throwError(() => error);
      })
    );
  }
}
