import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslateModule } from '@ngx-translate/core';
import { CategoryDialogComponent } from './category-dialog/category-dialog.component';
import { CategoriesService } from 'src/app/services/category.service';
import { CategoryService } from 'src/assets/his.model';
import { MatTreeModule } from '@angular/material/tree';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CategoryTreeComponent } from 'src/app/shared/components/category-tree/category-tree.component';

@Component({
  selector: 'app-category-management',
  templateUrl: './category-management.component.html',
  styleUrls: ['./category-management.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatTreeModule,
    MatProgressSpinnerModule,
    TranslateModule,
    CategoryTreeComponent
  ]
})
export class CategoryManagementComponent implements OnInit {
  categories: CategoryService[] = [];
  isLoading = false;
  selectedCategory: CategoryService | null = null;
  @ViewChild(CategoryTreeComponent) categoryTree!: CategoryTreeComponent;

  constructor(
    private categoriesService: CategoriesService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.isLoading = true;
    this.categoriesService.getCategoryTree().subscribe({
      next: (categories) => {
        this.categories = categories;
        this.isLoading = false;
        
        // If we had a selected category, try to re-select it after reload
        if (this.selectedCategory) {
          const reselect = categories.find(c => c.id === this.selectedCategory?.id);
          if (reselect) {
            this.selectedCategory = reselect;
            // After reloading categories, update the tree selection as well
            setTimeout(() => {
              if (this.categoryTree) {
                this.categoryTree.selectCategoryById(reselect.id);
              }
            }, 0);
          } else {
            // If the previously selected category no longer exists, clear selection
            this.selectedCategory = null;
          }
        }
      },
      error: (error) => {
        this.snackBar.open('Error loading categories', 'Close', { duration: 3000 });
        console.error('Error loading categories:', error);
        this.isLoading = false;
      }
    });
  }

  onCategorySelected(category: CategoryService) {
    this.selectedCategory = category;
  }

  openDialog(category?: CategoryService, parentId?: number): void {
    const dialogRef = this.dialog.open(CategoryDialogComponent, {
      width: '600px',
      data: {
        category: category ? { ...category } : null,
        parentId: parentId || null,
        categories: this.categories.filter(c => c.id !== category?.id)
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (category) {
          this.updateCategory(category.id, result);
        } else {
          this.createCategory(result);
        }
      }
    });
  }

  createCategory(category: CategoryService) {
    this.isLoading = true;
    this.categoriesService.createCategory(category).subscribe({
      next: (newCategory) => {
        this.snackBar.open('Category created successfully', 'Close', { duration: 3000 });
        
        // After creating, refresh the tree
        this.loadCategories();
        
        // Wait for categories to load then select the new category
        if (newCategory?.id) {
          setTimeout(() => this.findAndSelectCategory(newCategory.id), 100);
        }
      },
      error: (error) => {
        this.snackBar.open('Error creating category', 'Close', { duration: 3000 });
        console.error('Error creating category:', error);
        this.isLoading = false;
      }
    });
  }

  updateCategory(id: number, category: CategoryService) {
    this.isLoading = true;
    this.categoriesService.updateCategory(id, category).subscribe({
      next: () => {
        this.snackBar.open('Category updated successfully', 'Close', { duration: 3000 });
        
        // After updating, refresh the tree and maintain selection
        const previouslySelectedId = this.selectedCategory?.id;
        this.loadCategories();
        
        // Re-select the updated category after loading completes
        if (previouslySelectedId) {
          setTimeout(() => this.findAndSelectCategory(previouslySelectedId), 100);
        }
      },
      error: (error) => {
        this.snackBar.open('Error updating category', 'Close', { duration: 3000 });
        console.error('Error updating category:', error);
        this.isLoading = false;
      }
    });
  }

  deleteCategory(id: number) {
    this.isLoading = true;
    this.categoriesService.deleteCategory(id).subscribe({
      next: () => {
        this.snackBar.open('Category deleted successfully', 'Close', { duration: 3000 });
        
        // After deleting, refresh the tree and clear selection if the deleted category was selected
        if (this.selectedCategory?.id === id) {
          this.selectedCategory = null;
        }
        this.loadCategories();
        
        // If this is a child category and parent was selected before, reselect the parent
        if (this.selectedCategory && this.selectedCategory.id !== id) {
          const currentSelectedId = this.selectedCategory.id;
          setTimeout(() => this.findAndSelectCategory(currentSelectedId), 100);
        }
      },
      error: (error) => {
        this.snackBar.open('Error deleting category. Make sure it has no children.', 'Close', { duration: 3000 });
        console.error('Error deleting category:', error);
        this.isLoading = false;
      }
    });
  }

  addChildCategory(parent: CategoryService) {
    if (!parent.allowChildren) {
      this.snackBar.open('This category does not allow children', 'Close', { duration: 3000 });
      return;
    }
    
    // Select the parent category in the UI before opening the dialog
    this.selectedCategory = parent;
    
    // Update tree selection to match the selected parent
    if (this.categoryTree) {
      this.categoryTree.selectCategoryById(parent.id);
    }
    
    // Open dialog with parent ID
    this.openDialog(undefined, parent.id);
  }

  // Helper method to find and select a category by ID with improved reliability
  findAndSelectCategory(categoryId: number) {
    // Find the category by ID in the flat list
    const categoryToSelect = this.findCategoryById(categoryId);
    if (categoryToSelect) {
      this.selectedCategory = categoryToSelect;
      
      // Use the ViewChild reference to call the tree component's method
      if (this.categoryTree) {
        this.categoryTree.selectCategoryById(categoryId);
      }
    }
  }
  
  // Helper method to find a category by ID in the flat list
  findCategoryById(id: number): CategoryService | null {
    // First try to find in the root categories
    let category = this.categories.find(c => c.id === id);
    if (category) return category;
    
    // If not found, recursively search in children
    for (const parent of this.categories) {
      if (parent.children) {
        category = this.findCategoryInChildren(parent.children, id);
        if (category) return category;
      }
    }
    
    return null;
  }
  
  // Helper method to recursively search for a category in children
  findCategoryInChildren(children: CategoryService[], id: number): CategoryService | null {
    for (const child of children) {
      if (child.id === id) return child;
      if (child.children) {
        const found = this.findCategoryInChildren(child.children, id);
        if (found) return found;
      }
    }
    return null;
  }
} 