import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { CategoryService } from 'src/assets/his.model';
import { TranslateModule } from '@ngx-translate/core';
import { MatIconModule } from '@angular/material/icon';
import { CategoryTreeComponent } from 'src/app/shared/components/category-tree/category-tree.component';
import { CategoriesService } from 'src/app/services/category.service';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';

interface DialogData {
  category: CategoryService | null;
  parentId: number | null;
  categories: CategoryService[];
}

interface CategoryNode {
  id: number;
  name: string;
  allowChildren: boolean;
  children?: CategoryNode[];
}

interface CategoryFlatNode {
  expandable: boolean;
  name: string;
  level: number;
  id: number;
  allowChildren: boolean;
}

interface CategoryFormResult {
  id?: number;
  name: string;
  description: string;
  parentId: number | null;
  isActive: boolean;
  displayOrder: number;
  allowChildren: boolean;
  icon: string;
}

@Component({
  selector: 'app-category-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    CategoryTreeComponent,
    MatTabsModule,
    MatDividerModule,
    MatTooltipModule,
    TranslateModule
  ],
  template: `
    <div class="p-6 category-dialog-container">
      <div class="flex items-center justify-between mb-4">
        <h2 class="headline-1">{{ data.category ? 'Edit' : 'Add' }} Category</h2>
        <button mat-icon-button mat-dialog-close>
          <mat-icon>close</mat-icon>
        </button>
      </div>
      
      <form [formGroup]="categoryForm" (ngSubmit)="onSubmit()">
        <!-- Name -->
        <mat-form-field appearance="outline" class="w-full">
          <mat-label>Name</mat-label>
          <input matInput formControlName="name" placeholder="Enter category name" required>
          <mat-error *ngIf="categoryForm.get('name')?.hasError('required')">Name is required</mat-error>
        </mat-form-field>
        
        <!-- Description -->
        <mat-form-field appearance="outline" class="w-full">
          <mat-label>Description</mat-label>
          <textarea matInput formControlName="description" placeholder="Enter category description" rows="3"></textarea>
        </mat-form-field>
        
        <!-- Parent Category Selection -->
        <div *ngIf="!data.category" class="mb-4">
          <div class="parent-category-section">
            <h3 class="mb-2">Parent Category</h3>
            
            <mat-divider class="mb-3"></mat-divider>
            
            <div class="parent-selection-options mb-2">
              <mat-slide-toggle [checked]="isRootCategory" (change)="toggleRootCategory($event.checked)" color="primary" [disabled]="data.parentId !== null">
                Root Category (No Parent)
              </mat-slide-toggle>
            </div>
            
            <div *ngIf="!isRootCategory" class="parent-tree-container">
              <div class="selected-parent mb-2" *ngIf="selectedParentCategory">
                <strong>Selected Parent:</strong> {{ selectedParentCategory.name }}
                <button mat-icon-button color="warn" type="button" (click)="clearSelectedParent()" 
                    matTooltip="Clear selected parent" [disabled]="data.parentId !== null">
                  <mat-icon>clear</mat-icon>
                </button>
              </div>
              
              <div class="tree-container">
                <app-category-tree
                  [categories]="availableParentCategories"
                  [selectedCategoryId]="selectedParentId"
                  [enableEditing]="false"
                  (categorySelected)="onParentCategorySelected($event)">
                </app-category-tree>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Display Order -->
        <mat-form-field appearance="outline" class="w-full">
          <mat-label>Display Order</mat-label>
          <input matInput type="number" formControlName="displayOrder" placeholder="Enter display order">
        </mat-form-field>
        
        <!-- Active Status -->
        <div class="mb-4">
          <mat-slide-toggle formControlName="isActive" color="primary">Active</mat-slide-toggle>
        </div>
        
        <!-- Allow Children -->
        <div class="mb-6">
          <mat-slide-toggle formControlName="allowChildren" color="primary">
            Allow Children
            <span class="icon-preview">
              <mat-icon [svgIcon]="categoryForm.get('allowChildren')?.value ? 'mat:folder' : 'mat:article'"></mat-icon>
            </span>
          </mat-slide-toggle>
        </div>
        
        <!-- Actions -->
        <div class="flex justify-end gap-2">
          <button mat-button mat-dialog-close type="button">Cancel</button>
          <button mat-raised-button color="primary" type="submit" [disabled]="categoryForm.invalid">
            {{ data.category ? 'Update' : 'Create' }}
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .category-dialog-container {
      min-width: 500px;
      width: 100%;
      max-width: 600px;
    }
    
    .mat-form-field {
      margin-bottom: 16px;
    }
    
    .parent-category-section {
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      padding: 12px;
      margin-bottom: 16px;
    }
    
    .parent-tree-container {
      margin-top: 12px;
    }
    
    .tree-container {
      height: 250px;
      overflow-y: auto;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
    }
    
    .selected-parent {
      padding: 8px 12px;
      background-color: #f5f5f5;
      border-radius: 4px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .icon-preview {
      margin-left: 8px;
      display: inline-flex;
      align-items: center;
      vertical-align: middle;
    }
  `]
})
export class CategoryDialogComponent implements OnInit {
  categoryForm: FormGroup;
  isRootCategory = true;
  selectedParentId: number | null = null;
  selectedParentCategory: CategoryService | null = null;
  availableParentCategories: CategoryService[] = [];

  constructor(
    private fb: FormBuilder,
    private categoriesService: CategoriesService,
    public dialogRef: MatDialogRef<CategoryDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
    this.categoryForm = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      parentId: [null],
      isActive: [true],
      displayOrder: [0],
      allowChildren: [true],
      icon: ['folder']
    });
    
    // Initialize with parent ID if provided
    if (data.parentId) {
      this.isRootCategory = false;
      this.selectedParentId = data.parentId;
      
      // Auto-set the parent ID in the form when creating child
      this.categoryForm.patchValue({
        parentId: data.parentId
      });
      
      // Find the parent category to display
      const parent = data.categories.find(c => c.id === data.parentId);
      if (parent) {
        this.selectedParentCategory = parent;
      }
    }
  }

  ngOnInit(): void {
    // Filter categories that can have children
    this.prepareParentCategories();
    
    // If editing a category
    if (this.data.category) {
      this.categoryForm.patchValue({
        name: this.data.category.name,
        description: this.data.category.description,
        parentId: this.data.category.parentId,
        isActive: this.data.category.isActive,
        displayOrder: this.data.category.displayOrder || 0,
        allowChildren: this.data.category.allowChildren,
        icon: this.data.category.icon || (this.data.category.allowChildren ? 'folder' : 'article')
      });
      
      // If the category has a parent, find it
      if (this.data.category.parentId) {
        const parent = this.data.categories.find(c => c.id === this.data.category?.parentId);
        if (parent) {
          this.selectedParentCategory = parent;
          this.selectedParentId = parent.id;
          this.isRootCategory = false;
        }
      }
    } else if (this.data.parentId) {
      // If creating a child category
      this.categoryForm.patchValue({
        parentId: this.data.parentId
      });
      
      // Find the parent category
      const parent = this.data.categories.find(c => c.id === this.data.parentId);
      if (parent) {
        this.selectedParentCategory = parent;
        this.selectedParentId = parent.id;
        this.isRootCategory = false;
      }
    }
    
    // Listen for changes to allowChildren to update the icon
    this.categoryForm.get('allowChildren')?.valueChanges.subscribe(allowChildren => {
      this.categoryForm.get('icon')?.setValue(allowChildren ? 'folder' : 'article');
    });
  }

  prepareParentCategories(): void {
    // Filter out the current category (if editing) and any categories that don't allow children
    this.availableParentCategories = this.data.categories
      .filter(c => {
        // Exclude the current category (to prevent self-reference)
        if (this.data.category && c.id === this.data.category.id) {
          return false;
        }
        
        // Only include categories that allow children
        return c.allowChildren;
      });
    
    // If we're creating with a parent ID specified, make sure it's included in the selected ID
    if (this.data.parentId && !this.data.category) {
      this.selectedParentId = this.data.parentId;
      this.isRootCategory = false;
      
      // Find the parent category
      const parent = this.data.categories.find(c => c.id === this.data.parentId);
      if (parent) {
        this.selectedParentCategory = parent;
      }
    }
  }

  toggleRootCategory(isRoot: boolean): void {
    this.isRootCategory = isRoot;
    if (isRoot) {
      this.selectedParentId = null;
      this.selectedParentCategory = null;
      this.categoryForm.get('parentId')?.setValue(null);
    }
  }

  onParentCategorySelected(category: CategoryService): void {
    if (category) {
      this.selectedParentId = category.id;
      this.selectedParentCategory = category;
      this.categoryForm.get('parentId')?.setValue(category.id);
    }
  }

  clearSelectedParent(): void {
    this.selectedParentId = null;
    this.selectedParentCategory = null;
    this.categoryForm.get('parentId')?.setValue(null);
  }
  
  updateIconBasedOnAllowChildren(): void {
    const allowChildren = this.categoryForm.get('allowChildren')?.value;
    // Set icon based on allowChildren value
    this.categoryForm.get('icon')?.setValue(allowChildren ? 'folder' : 'article');
  }

  onSubmit(): void {
    if (this.categoryForm.invalid) {
      return;
    }

    const formValue = this.categoryForm.getRawValue();
    
    const result: CategoryFormResult = {
      name: formValue.name,
      description: formValue.description,
      parentId: this.isRootCategory ? null : formValue.parentId,
      isActive: formValue.isActive,
      displayOrder: formValue.displayOrder,
      allowChildren: formValue.allowChildren,
      icon: formValue.icon
    };
    
    if (this.data.category) {
      result.id = this.data.category.id;
    }
    
    this.dialogRef.close(result);
  }
} 