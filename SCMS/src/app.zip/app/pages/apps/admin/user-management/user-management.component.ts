import { AfterViewInit, Component, DestroyRef, inject, Input, OnInit, ViewChild } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogConfig, MatDialogModule } from '@angular/material/dialog';
import { SelectionModel } from '@angular/cdk/collections';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { aioTableLabels, aioTableData } from 'src/static-data/aio-table-data';

import { AdminService } from '../admin.service';
import { RolesModalComponent } from '../Modals/roles-modal/roles-modal.component';
import { PasswordRestComponent } from '../Modals/password-rest/password-rest.component';
import { CreateUserComponent } from '../Modals/create-user/create-user.component';
import { EditUserCategoriesComponent } from '../Modals/edit-user-categories/edit-user-categories.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { SpecialtiesService } from '../../../../../assets/services/specialty.service';
import { IUserNew, Clinic } from 'src/assets/user';
import { ToastrService } from 'ngx-toastr';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { MatInputModule } from '@angular/material/input';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { TranslateModule } from '@ngx-translate/core';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss'],
  standalone: true,
  animations: [
    fadeInUp400ms,
    stagger40ms
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'outline'
      } as unknown as MatFormFieldDefaultOptions
    }
  ],
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatMenuModule,
    MatInputModule,
    MatButtonToggleModule,
    NgIf,
    NgFor,
    NgClass,
    MatDividerModule,
    MatListModule,
    TranslateModule
],
  // animations: [
  //   fadeInUp400ms,
  //   stagger40ms,
  //   stagger,
  //   trigger('detailExpand', [
  //     state('collapsed', style({ height: '0px', minHeight: '0' })),
  //     state('expanded', style({ height: '*' })),
  //     transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
  //   ]),
  // ],
  // providers: [
  //   {
  //     provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
  //     useValue: {
  //       appearance: 'standard'
  //     } as unknown as MatFormFieldDefaultOptions
  //   }
  // ]
})
export class UserManagementComponent implements OnInit, AfterViewInit {

  layoutCtrl = new UntypedFormControl('fullwidth');
  isTableExpanded = false;

  toggleTableRows() {
    this.isTableExpanded = !this.isTableExpanded;

    this.dataSource.data.forEach((row: any) => {
      row.isExpanded = this.isTableExpanded;
    })
  }
  /**
   * Simulating a service with HTTP that returns Observables
   * You probably want to remove this and do all requests in a service with HTTP
   */
  subject$: ReplaySubject<IUserNew[]> = new ReplaySubject<IUserNew[]>(1);
  data$: Observable<IUserNew[]> = this.subject$.asObservable();
  customers: IUserNew[] = [];

  @Input()
  // columns: TableColumn<PaymentAcademicYear>[] = [

  //   { label: 'الايصال', property: 'paymentCode', type: 'text', visible: true, cssClasses: ['font-medium'] },
  //   { label: 'ولي الامر', property: 'parentName', type: 'text', visible: true, cssClasses: ['font-medium'] },
  //   { label: 'قيمة المتبقة', property: 'totalDebit', type: 'text', visible: true, cssClasses: ['font-medium'] },
  //   { label: 'القيمة المدفوع', property: 'totalAmount', type: 'text', visible: true, cssClasses: ['font-medium'] },
  //    { label: 'القيمة الكلية', property: 'totalOrder', type: 'text', visible: true, cssClasses: ['font-medium'] },
  //   { label: 'تاريخ الفاتورة,' ,property: 'paymentCreate', type: 'text', visible: true, cssClasses: ['font-medium'] },
  //   { label: 'حالة الدفع', property: 'paymentStatues', type: 'button', visible: true, cssClasses: ['font-medium'] },

  //    { label: 'تعديلات', property: 'actions', type: 'button', visible: true } ,

  // ];


  columns: TableColumn<IUserNew>[] = [
    { label: 'Id', property: 'id', type: 'text', visible: true, cssClasses: ['font-medium'], matColumnDef: 'id' },
    { label: 'المستخدم', property: 'userName', type: 'text', visible: true, cssClasses: ['font-medium'], matColumnDef: 'userName' },
    { label: 'البريد الإلكتروني', property: 'email', type: 'text', visible: true, cssClasses: ['font-medium'], matColumnDef: 'email' },
    { label: 'الصلاحيات', property: 'roles', type: 'text', visible: true, cssClasses: ['font-medium'], matColumnDef: 'roles' },
   { label: 'التصنيفات', property: 'specialties', type: 'text', visible: true, cssClasses: ['font-medium'], matColumnDef: 'specialties' },
    { label: 'تعديلات', property: 'actions', type: 'button', visible: true, matColumnDef: 'actions' },
   ];
  // Expanded detail table columns


  givePayment(row:any){
console.log(row)
row.paymentStatues =row.paymentStatues===1?0:1;
  }




  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<IUserNew> | null;
  selection = new SelectionModel<IUserNew>(true, []);
  searchCtrl = new UntypedFormControl();

  labels = aioTableLabels;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  specialties:Clinic[]=[];
  constructor(private adminService: AdminService, private dialog: MatDialog ,private specialtyService:SpecialtiesService,
    private snackbarService:ToastrService) {
      this.specialtyService.getClinics().subscribe((rep) =>{
        this.specialties=rep;
      }) ;
  }


  users: Partial<IUserNew[]>;




  getUsersWithRoles() {
    this.adminService.getUserWithRoles().subscribe(users => {
      console.log(users)
      this.users = users;
    });
  }

  openRolesDialog(user: IUserNew): void {
    this.dialog.open(RolesModalComponent, {
      width: '800px',
      data: {
        user,
        roles: this.getRoles(user),
        specialties: this.getSpecialty(user)
      }
    }).afterClosed().subscribe(result => {
      if (result) {
        // Extract selected roles, specialties, and categories
        const rolesToUpdate = result.selectedRoles.map(role => role.name);
        const specialtiesToUpdate = result.selectedSpecialties.map(specialty => specialty.id);
        const categoriesToUpdate = result.selectedCategories || [];
        this.adminService.updateUserRolesAndRegions(
          user.id,
          rolesToUpdate,
          specialtiesToUpdate,
          categoriesToUpdate
        ).subscribe({
          next: () => {
            this.adminService.getUserWithRoles().subscribe(users => {
              this.subject$.next(users);
              this.snackbarService.success('User updated successfully');
            });
          },
          error: (error) => {
            this.snackbarService.error('Failed to update user: ' + error);
          }
        });
      }
    });
  }

  openDialogRestPassword(user: IUserNew): void {
    const dialogRef = this.dialog.open(PasswordRestComponent, {
      width: '500px',
      data: {
        user
      }
    });

    dialogRef.afterClosed().subscribe((password: string) => {
      if (password) {
        console.log('Resetting password for user:', user.userName);
         this.snackbarService.info('Resetting password for user: ' + user.userName);
        this.adminService.restPassword(user.id, password)
          .subscribe({
            next: (response) => {
              this.snackbarService.success('Password reset successful');
            },
            error: (error) => {
              console.error('Error resetting password:', error);
              this.snackbarService.error('Failed to reset password: ' + (error.message || 'Unknown error'));
            }
          });
      }
    });
  }
    
    // this.roles = [
    //   { name: 'Admin', checked: false },
    //   { name: 'Doctor', checked: false },
    //   { name: 'Patient', checked: false },
    //   { name: 'Pharmacy', checked: false },
    //   { name: 'Reception', checked: false },
    //   { name: 'LAB', checked: false },
    //   { name: 'Emergency', checked: false },
    //   { name: 'Surgery', checked: false },
    //   { name: 'Imaging', checked: false },
    //   { name: 'Insurance', checked: false },
    //   { name: 'Hospital', checked: false }
    // ];
  getRoles(user: IUserNew): any[] {
    // Standard roles
    const roles = [
      { name: 'Admin', checked: user.roles?.includes('Admin') || false },
      { name: 'Doctor', checked: user.roles?.includes('Doctor') || false },
      { name: 'Patient', checked: user.roles?.includes('Patient') || false },
      { name: 'Pharmacy', checked: user.roles?.includes('Pharmacy') || false },
      { name: 'Reception', checked: user.roles?.includes('Reception') || false },
      { name: 'LAB', checked: user.roles?.includes('LAB') || false },
      { name: 'Emergency', checked: user.roles?.includes('Emergency') || false },
      { name: 'Surgery', checked: user.roles?.includes('Surgery') || false },
      { name: 'Imaging', checked: user.roles?.includes('Imaging') || false },
      { name: 'Insurance', checked: user.roles?.includes('Insurance') || false },
      { name: 'Hospital', checked: user.roles?.includes('Hospital') || false },
      { name: 'Finance', checked: user.roles?.includes('Finance') || false },
      { name: 'Treasury', checked: user.roles?.includes('Treasury') || false },
      { name: 'MedicalTechnician', checked: user.roles?.includes('MedicalTechnician') || false }
    ];

    return roles;
  }


  getSpecialty(user: IUserNew): any[] {
    const UserSpecialties: any[] = [];
    const userRoles = user.specialties || [];
    const availableSpecialties: any[] = this.specialties || [];

    availableSpecialties.forEach(item => {
      let isMatch = false;
      // Check if userRoles is iterable
      if (Array.isArray(userRoles)) {
        for (const specialty of userRoles) {
          if (specialty && typeof specialty === 'string' && specialty.includes(item.specialtyName)) {
            item.checked = true;
            isMatch = true;
            UserSpecialties.push(item);
            break;
          }
        }
      }

      if (!isMatch) {
        item.checked = false;
        UserSpecialties.push(item);
      }
    });

    return UserSpecialties;
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }


  ngOnInit() {
    this.adminService.getUserWithRoles().subscribe(users => {
      this.subject$.next(users);
      this.users = users;
    });



    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter<IUserNew[]>(Boolean)
    ).subscribe(customers => {
      this.users = customers;
        this.dataSource.data = customers;
    });

     this.searchCtrl.valueChanges
       .pipe(takeUntilDestroyed(this.destroyRef))
       .subscribe((value) => this.onFilterChange(value));
  }
  private readonly destroyRef: DestroyRef = inject(DestroyRef);
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createCustomer() {
    const dialogConfig = new MatDialogConfig();
    this.dialog.open(
      CreateUserComponent,
      dialogConfig
    ).afterClosed().subscribe((customer: IUserNew) => {
      if (customer) {
        this.adminService.getUserWithRoles().subscribe({
          next: (rep) => {
            this.subject$.next(rep);
            this.snackbarService.success('User created successfully');
          },
          error: (err) => {
            this.snackbarService.error('Failed to refresh user list after creation');
          }
        });
      }
    });
  }

  updateCustomer(customer: IUserNew) {
    this.dialog.open(RolesModalComponent, {
      data: customer ,minWidth:'1000px' ,height:'auto'
    }).afterClosed().subscribe(updatedCustomer => {
      /**
       * Customer is the updated customer (if the user pressed Save - otherwise it's null)
       */
      if (updatedCustomer) {
        /**
         * Here we are updating our local array.
         * You would probably make an HTTP request here.
         */
        const index = this.customers.findIndex((existingCustomer) => existingCustomer.id === updatedCustomer.id);
        this.customers[index] = (updatedCustomer);
        this.subject$.next(this.customers);
      }
    });
  }

  deleteCustomer(customer: IUserNew) {
    this.dialog
      .open(ConfirmDialogComponent, {
        data: {
          title: 'Delete User',
          message: `Are you sure you want to delete the user: ${customer.userName}?`
        }
      })
      .afterClosed()
      .subscribe((confirm) => {
        if (confirm) {
          this.adminService.deleteAdmin(customer).subscribe({
            next: (rep) => {
              this.adminService.getUserWithRoles().subscribe(users => {
                this.subject$.next(users);
                this.snackbarService.success('User deleted successfully');
              });
            },
            error: (err) => {
              this.snackbarService.error('Failed to delete user');
            }
          });
        }
      });
  }

  handleFileUpload(event: any, subject: any): void {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      subject.orderFileUpload = base64String;
    };
    reader.readAsDataURL(file);
  }

  handleAddClick(subject: any): void {
  console.log(subject)
    let item = {
      id: subject.id,
      paymentAcademicYearId: subject.paymentAcademicYearId,
      paymentDateTiket: subject.paymentDateTiket,
      orderFileUpload: subject.orderFileUpload
    };
    // this.adminService.getUserWithRoles(item).subscribe((rep) => {
    //   this.member.getPaymentAcademicYear().subscribe((rep) => {
    //     this.subject$.next(rep);
    //   });
    // });
  }
  downloadFile(file: string) {
    const link = document.createElement('a');
    link.href = file;
    link.download = 'file';
    link.target = '_blank';
    link.click();
  }
  isImageType(file: string): boolean {
    return file.startsWith('data:image/');
  }

  isPdfType(file: string): boolean {
    return file.startsWith('data:application/pdf');
  }

  isWordType(file: string): boolean {
    return file.startsWith('data:application/vnd.openxmlformats-officedocument.wordprocessingml.document')
      || file.startsWith('data:application/msword');
  }

  isExcelType(file: string): boolean {
    return file.startsWith('data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
      || file.startsWith('data:application/vnd.ms-excel');
  }
  getFormattedAmount(amount: any): string {
    const parsedAmount = parseFloat(amount);
    return isNaN(parsedAmount) ? '' : parsedAmount.toFixed(2);
  }

      deleteCustomers(customers: IUserNew[]) {
        /**
         * Here we are updating our local array.
         * You would probably make an HTTP request here.
         */
        customers.forEach(c => this.deleteCustomer(c));
      }

      onFilterChange(value: string) {
        if (!this.dataSource) {
          return;
        }
        value = value.trim();
        value = value.toLowerCase();
        this.dataSource.filter = value;
      }

      toggleColumnVisibility(column, event) {
        event.stopPropagation();
        event.stopImmediatePropagation();
        column.visible = !column.visible;
      }

      /** Whether the number of selected elements matches the total number of rows. */
      isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.data.length;
        return numSelected === numRows;
      }

      /** Selects all rows if they are not all selected; otherwise clear selection. */
      masterToggle() {
        this.isAllSelected() ?
          this.selection.clear() :
          this.dataSource.data.forEach(row => this.selection.select(row));
      }

      trackByProperty<T>(index: number, column: TableColumn<T>) {
        return column.property;
      }

      onLabelChange(change: MatSelectChange, row: IUserNew) {
        const index = this.customers.findIndex(c => c === row);
        this.customers[index] = change.value;
        this.subject$.next(this.customers);
      }

      editUserCategories(user: IUserNew) {
        this.dialog.open(EditUserCategoriesComponent, {
          data: user,
          width: '600px'
        }).afterClosed().subscribe(updatedUser => {
          if (updatedUser) {
            // Refresh the user list to show updated permissions
            this.adminService.getUserWithRoles().subscribe(users => {
              this.subject$.next(users);
            });
          }
        });
      }
    }
