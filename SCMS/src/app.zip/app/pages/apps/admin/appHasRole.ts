import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { UserService } from 'src/app/user/user.service';
import { ToastrService } from 'ngx-toastr';

@Directive({
  selector: '[appHasRole]'
})
export class HasRoleDirective {
  @Input() set appHasRole(requiredRoles: string[]) {
    this.checkRoles(requiredRoles);
  }

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private accountService: UserService,
    private toastr: ToastrService // Inject the ToastrService
  ) {}

  private checkRoles(requiredRoles: string[]) {
    this.accountService.currentUser$.subscribe(user => {

      console.log(user)
      if (user && user.roles && user.roles.some(role => requiredRoles.includes(role))) {

        console.log('user')

        // User has at least one of the required roles, so render the content
        this.viewContainer.createEmbeddedView(this.templateRef);
      } else {
        // User doesn't have any of the required roles, so clear the view
        this.viewContainer.clear();

        // Display error toastr
        this.toastr.error('You do not have the required role(s)', 'Access Denied');
      }
    });
  }
}
