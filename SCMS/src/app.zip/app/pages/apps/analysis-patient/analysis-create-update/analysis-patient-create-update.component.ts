import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UntypedFormBuilder, UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { analysisLaboratoryService } from '../analysis-patient.service';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TranslateModule } from '@ngx-translate/core';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { MatMenuModule } from '@angular/material/menu';
import { MedicalAnalysis } from 'src/app/patients/patient.service';

@Component({
  selector: 'vex-analysis-patient-create-update',
  templateUrl: './analysis-patient-create-update.component.html',
  styleUrls: ['./analysis-patient-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    TranslateModule,
    MatMenuModule,
    MatListModule ,
    MatDividerModule
  ]
})
export class analysisPatientCreateUpdateComponent implements OnInit {

  form: UntypedFormGroup;
  mode: 'create' | 'update' = 'create';


  constructor(@Inject(MAT_DIALOG_DATA) public defaults: MedicalAnalysis,
              private dialogRef: MatDialogRef<analysisPatientCreateUpdateComponent>,

              private _analysisPatient: analysisLaboratoryService,
              private fb: UntypedFormBuilder) {


  }
  onFileCardSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const previewImg = document.getElementById('FileCardSelectedPreview') as HTMLImageElement;
        if (previewImg) {
          previewImg.src = e.target.result;
        }
        this.form.get('file').setValue(file);
      };
      reader.readAsDataURL(file);
    }
  }
  ngOnInit() {

    console.log(this.defaults)

      this.mode = 'update';
      this.form = this.fb.group({
        id: [this.defaults.id],
        report:[],
        file:[],
        iS_EXIST:[false]

      });



  }





  save() {
    if (this.form.valid) {
      const formData = new FormData();
      formData.append('id', this.form.get('id').value);
      formData.append('report', this.form.get('report').value);
      formData.append('file', this.form.get('file').value);

      this._analysisPatient.uploadReport(formData).subscribe(
        response => {
          console.log('Report sent successfully', response);
           this.dialogRef.close(response);
        },
        error => {
          console.error('Error sending report', error);
          alert('An error occurred while sending the report.');
        }
      );
    }
  }



  generateReport() {
    const reportData = {
      code: this.defaults.code,
      patientName: this.defaults.patientName,
      status: this.defaults.status, // تأكد من أن `status` موجودة في `defaults`
      lastUpdate: this.defaults.lastUpdate
    };

    // this.http.post('https://your-api-url/repciter', reportData).subscribe(
    //   (response: any) => {
    //     console.log('Report sent successfully', response);
    //     this.dialog.open(this.reportDialog, {
    //       width: '300px',
    //       data: reportData
    //     });
    //   },
    //   (error: any) => {
    //     console.error('Error sending report', error);
    //     alert('An error occurred while sending the report.');
    //   }
    // );
  }
  createmedicalrecord() {
    const medicalrecord = this.form.value;
    this.dialogRef.close(medicalrecord);
  }

  updatemedicalrecord() {
    const medicalrecord = this.form.value;
    medicalrecord.id = this.defaults.id;
    this.dialogRef.close(medicalrecord);
  }

  isCreateMode() {
    return this.mode === 'create';
  }

  isUpdateMode() {
    return this.mode === 'update';
  }
}
