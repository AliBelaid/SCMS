import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/assets/environments/environment';
import { MedicalAnalysis } from '../analysis-laboratory/analysis-laboratory.service';

@Injectable({
  providedIn: 'root'
})
export class analysisLaboratoryService {





  private apiUrl = environment.apiUrl+'/MedicalRecords';

  constructor(private http: HttpClient) { }


  uploadReport(formData: FormData): Observable<any> {
    return this.http.post(this.apiUrl+'/repciter', formData);
  }
  createMedicalAnalysis(formData: FormData): Observable<any> {
    return this.http.post(this.apiUrl, formData);
  }
  getMedicalAnalyses(): Observable<MedicalAnalysis[]> {
    return this.http.get<MedicalAnalysis[]>(this.apiUrl);
  }

  getMedicalAnalysis(id: number): Observable<MedicalAnalysis> {
    return this.http.get<MedicalAnalysis>(`${this.apiUrl}/${id}`);
  }



  updateMedicalAnalysis(id: number, medicalAnalysis: MedicalAnalysis): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, medicalAnalysis);
  }

  deleteMedicalAnalysis(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

}
// src/app/models/medical-analysis.model.ts
// src/app/models/medical-analysis.model.ts
