import { Routes } from '@angular/router';
import { AnalysisPatientComponent } from './analysis-patient.component';

export const ANALYSIS_PATIENT_ROUTES: Routes = [
  {
    path: '',
    component: AnalysisPatientComponent
  }
];
