import {  analysisLaboratoryService } from './analysis-patient.service';
import { AfterViewChecked, AfterViewInit, ChangeDetectorRef, Component, DestroyRef, inject, Input, OnInit, ViewChild } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { SelectionModel } from '@angular/cdk/collections';

import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { aioTableLabels, aioTableData } from 'src/static-data/aio-table-data';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MedicalAnalysis } from 'src/assets/his.model';
import { analysisPatientCreateUpdateComponent } from './analysis-create-update/analysis-patient-create-update.component';
import { AnalysisPatientCreateComponent } from './analysis-create/analysis-create.component';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatDividerModule } from '@angular/material/divider';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatOptionModule } from '@angular/material/core';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatListModule } from '@angular/material/list';
import { VexScrollbarComponent } from '@vex/components/vex-scrollbar/vex-scrollbar.component';

@Component({
  selector: 'app-analysis-patient',
  templateUrl: './analysis-patient.component.html',
  styleUrls: ['./analysis-patient.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatSelectModule,
    MatListModule,
    VexBreadcrumbsComponent,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatSortModule,
    MatCheckboxModule,
    MatIconModule,
    MatButtonModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatInputModule,
    MatRadioModule,
    MatDividerModule,
    MatDatepickerModule,
    MatFormFieldModule,
    TranslateModule,
    MatOptionModule,
    MaterialFileInputModule,
    VexScrollbarComponent,
    VexPageLayoutComponent,
    VexPageLayoutHeaderDirective,
    VexPageLayoutContentDirective,
    NgIf,
    NgFor,
    NgClass
  ],
  animations: [
    fadeInUp400ms,
    stagger40ms
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'standard'
      } as unknown as MatFormFieldDefaultOptions
    }
  ]
})
export class AnalysisPatientComponent implements  OnInit, AfterViewInit, AfterViewChecked{

  layoutCtrl = new UntypedFormControl('fullwidth');

  /**
   * Simulating a service with HTTP that returns Observables
   * You probably want to remove this and do all requests in a service with HTTP
   */
  subject$: ReplaySubject<MedicalAnalysis[]> = new ReplaySubject<MedicalAnalysis[]>(1);
  data$: Observable<MedicalAnalysis[]> = this.subject$.asObservable();
  analysislaboratory: MedicalAnalysis[];

  @Input()


  columns: TableColumn<any>[] = [
    { label: this.translate.instant('PATIENT_NAME'), property: 'patientName', type: 'text', visible: true },

    { label: this.translate.instant('ID'), property: 'id', type: 'text', visible: false },
    { label: this.translate.instant('CODE'), property: 'code', type: 'text', visible: true },
    { label: this.translate.instant('NAME'), property: 'name', type: 'text', visible: true },
    { label: this.translate.instant('IS_EXIST'), property: 'iS_EXIST', type: 'text', visible: true },
    { label: this.translate.instant('STATUS'), property: 'status', type: 'text', visible: true },
    { label: this.translate.instant('LAST_UPDATE'), property: 'lastUpdate', type: 'text', visible: true },
    { label: this.translate.instant('MEDICAL_TYPE'), property: 'medicalType', type: 'text', visible: true },
    { label: this.translate.instant('FILE_TYPE'), property: 'fileType', type: 'text', visible: false },
    { label: this.translate.instant('FILE'), property: 'fileUrl', type: 'image', visible: true },
    { label: this.translate.instant('Actions'), property: 'actions', type: 'button', visible: true }
  ];

  triggerDownload(row: any) {
    const url = row.fileUrl;
    const a = document.createElement('a');
    a.href = url;
    a.download = this.getFileName(row.fileUrl); // استخدم اسم الملف المناسب
    a.click();
  }
  downloadImage(imageUrl: MedicalAnalysis): void {
    const link = document.createElement('a');
    link.href = imageUrl.fileUrl;
    link.setAttribute('download', this.getFileName(imageUrl.fileUrl)); // تخصيص اسم الملف المحمل
    link.setAttribute('type', 'application/octet-stream'); // تحديد نوع المحتوى
    link.style.display = 'none'; // إخفاء الرابط
    link.target = '_blank';

    link.click();
   }


  private getFileName(filePath: string): string {
    return filePath?.split('/').pop();
  }

  isImage(row: any): boolean {
    const fileType = row.fileUrl?.split('.').pop().toLowerCase();
    return ['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(fileType);
  }


  blobUrls: { [id: number]: string } = {};

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }


  getFileExtension(filePath: string): string {
    return filePath.split('.').pop();
  }

  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<MedicalAnalysis> | null;
  selection = new SelectionModel<MedicalAnalysis>(true, []);
  searchCtrl = new UntypedFormControl();

  labels = aioTableLabels;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private cdr: ChangeDetectorRef,private dialog: MatDialog ,private analysislaboratoryService:analysisLaboratoryService ,private translate:TranslateService) {
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  /**
   * Example on how to get data and pass it to the table - usually you would want a dedicated service with a HTTP request for this
   * We are simulating this request here.
   */

  ngOnInit() {
    this.analysislaboratoryService.getMedicalAnalyses().subscribe(analysislaboratory => {
      this.subject$.next(analysislaboratory);
    });

    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter<MedicalAnalysis[]>(Boolean)
    ).subscribe(analysisLaboratory => {
      this.analysislaboratory = analysisLaboratory;
      this.dataSource.data = analysisLaboratory;
    });

     this.searchCtrl.valueChanges
         .pipe(takeUntilDestroyed(this.destroyRef))
         .subscribe((value) => this.onFilterChange(value));
    }
    private readonly destroyRef: DestroyRef = inject(DestroyRef);
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createanalysisLaboratory() {
    const dialogRef = this.dialog.open(AnalysisPatientCreateComponent, {
      minWidth: '600px',
      minHeight:'750px',
    }).afterClosed().subscribe((analysisLaboratory: any) => {
      /**
       * analysisLaboratory is the updated analysisLaboratory (if the user pressed Save - otherwise it's null)
       */
      if (analysisLaboratory) {
        /**
         * Here we are updating our local array.
         * You would probably make an HTTP request here.
         */


        // this.analysislaboratoryService.createMedicalAnalysis(analysisLaboratory).subscribe((rep)=> {
        //   this.analysislaboratory.unshift( analysisLaboratory);
        //   this.subject$.next(this.analysislaboratory);
        // })

      }
    });
  }

  updateanalysisLaboratory(analysisLaboratory: MedicalAnalysis) {
    this.dialog.open(analysisPatientCreateUpdateComponent, {
      data: analysisLaboratory

     , minWidth: '600px',
      minHeight:'750px',

    }).afterClosed().subscribe(updatedanalysisLaboratory => {
      /**
       * analysisLaboratory is the updated analysisLaboratory (if the user pressed Save - otherwise it's null)
       */
      if (updatedanalysisLaboratory) {
        /**
         * Here we are updating our local array.
         * You would probably make an HTTP request here.
         */


        this.analysislaboratoryService.updateMedicalAnalysis(updatedanalysisLaboratory.id,updatedanalysisLaboratory).subscribe((rep)=> {
        const index = this.analysislaboratory.findIndex((existinganalysisLaboratory) => existinganalysisLaboratory.id === updatedanalysisLaboratory.id);
        this.analysislaboratory[index].report = (updatedanalysisLaboratory.report);
        this.analysislaboratory[index].fileType = (updatedanalysisLaboratory.fileType);
        this.analysislaboratory[index].fileUrl = (updatedanalysisLaboratory.fileUrl);
        this.subject$.next(this.analysislaboratory);
      })}
    });
  }

  deleteanalysisLaboratory(analysisLaboratory: any) {
    /**
     * Here we are updating our local array.
     * You would probably make an HTTP request here.
     */

    this.analysislaboratoryService.deleteMedicalAnalysis(analysisLaboratory.id).subscribe((rep)=> {

    this.analysislaboratory.splice(this.analysislaboratory.findIndex((existinganalysisLaboratory) => existinganalysisLaboratory.id === analysisLaboratory.id), 1);
    this.selection.deselect(analysisLaboratory);
    this.subject$.next(this.analysislaboratory);
  }); }

  deleteanalysisLaboratoryz(analysisLaboratory: MedicalAnalysis[]) {
    /**
     * Here we are updating our local array.
     * You would probably make an HTTP request here.
     */
    analysisLaboratory.forEach(c => this.deleteanalysisLaboratory(c));
  }

  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  toggleColumnVisibility(column, event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }

  onLabelChange(change: MatSelectChange, row: any) {
    const index = this.analysislaboratory.findIndex(c => c === row);
    this.analysislaboratory[index].id = change.value;
    this.subject$.next(this.analysislaboratory);
  }
}

