import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { analysisLaboratoryService } from '../analysis-patient.service';
import { MedicalAnalysis, TreatmentDto } from 'src/assets/his.model';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { analysisPatientCreateUpdateComponent } from '../analysis-create-update/analysis-patient-create-update.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { MedicalRecordsService } from 'src/app/pages/medical-record/reception-manager.service';
import { TreatmentService } from 'src/app/pages/treatment/treatment.service';

@Component({
  selector: 'vex-analysis-Patient-createe',
  templateUrl: './analysis-create.component.html',
  styleUrls: ['./analysis-create.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatOptionModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatIconModule,
    TranslateModule ,
    MatMenuModule ,
    MatDividerModule,
    MatListModule
  ]
})
export class  AnalysisPatientCreateComponent implements OnInit {
generateReport() {
throw new Error('Method not implemented.');
}

  form = this.fb.group({
    medicalAnalysisId:[''],
     report: [ '', Validators.required],
    file: [null],
    iS_EXIST: [false],
    treatmentId: [null, Validators.required] // إضافة حقل لتحديد العلاج
  });

  mode: 'create' | 'update' = 'create';
  treatments: TreatmentDto[]; // تحميل البيانات من الخدمة
  medicalAnalysis: MedicalAnalysis[]; // تحميل البيانات من الخدمة

  constructor(
              private dialogRef: MatDialogRef<AnalysisPatientCreateComponent>,
              private _treatmentService: TreatmentService,
              private  _medicalRecordsService:   MedicalRecordsService,
              private _analysisPatient:analysisLaboratoryService,
              private fb: UntypedFormBuilder) {}

  ngOnInit() {
    this._treatmentService.getAllTreatments().subscribe((rep)=>{
      this.treatments =rep;
    }); // تحميل البيانات من الخدمة
    this._medicalRecordsService.getMedicalRecords().subscribe((rep)=>{
      this.medicalAnalysis =rep;
    }); // تحميل البيانات من الخدمة



  }

  onFileCardSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const previewImg = document.getElementById('FileCardSelectedPreview') as HTMLImageElement;
        if (previewImg) {
          previewImg.src = e.target.result;
        }
        this.form.get('file').setValue(file);
      };
      reader.readAsDataURL(file);
    }
  }

  save() {
    if (this.form.valid) {
      const formData = new FormData();
      formData.append('iS_EXIST', this.form.get('iS_EXIST').value);
      formData.append('report', this.form.get('report').value);
      formData.append('file', this.form.get('file').value);
      formData.append('treatmentId', this.form.get('treatmentId').value);
       formData.append('medicalAnalysisId', this.form.get('medicalAnalysisId').value);

      this._analysisPatient.createMedicalAnalysis(formData).subscribe(
        response => {
          console.log('Report sent successfully', response);
          this.dialogRef.close(response);
        },
        error => {
          console.error('Error sending report', error);
          alert('An error occurred while sending the report.');
        }
      );
    }
  }

  isCreateMode() {
    return this.mode === 'create';
  }

  isUpdateMode() {
    return this.mode === 'update';
  }
}
