import { Routes } from '@angular/router';
import { EmergencyAdmissionComponent } from './emergency-admission.component';

export const EMERGENCY_ADMISSION_ROUTES: Routes = [
  {
    path: '',
    component: EmergencyAdmissionComponent,
    children: [
      {
        path: 'create',
        loadComponent: () => import('./emergency-admission-create-update/emergency-admission-create-update')
          .then(m => m.EmergencyAdmissionCreateUpdateComponent)
      },
      {
        path: 'update/:id',
        loadComponent: () => import('./emergency-admission-create-update/emergency-admission-create-update')
          .then(m => m.EmergencyAdmissionCreateUpdateComponent)
      }
    ]
  }
];
