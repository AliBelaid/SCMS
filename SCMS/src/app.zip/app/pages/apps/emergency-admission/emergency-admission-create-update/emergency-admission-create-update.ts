import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UntypedFormBuilder, UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { PatientService } from 'src/app/patients/patient.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { Bed, EmergencyAdmission, Room, Ward } from '../emergency-admission.service';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { Patients } from 'src/assets/his.model';
import { RoomService } from '../../room/room.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'vex-emergency-admission-create-update',
  templateUrl: './emergency-admission-create-update.html',
  styleUrls: ['./emergency-admission-create-update.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    TranslateModule
  ]
})
export class EmergencyAdmissionCreateUpdateComponent implements OnInit {
  changeName(event: MatSelectChange) {
    var patient = event.value as Patients;
    this.form.get('patientName').setValue(patient.firstName + ' ' + patient.lastName);
    this.form.get('patientId').setValue(patient.id);
  }
  form: UntypedFormGroup;
  patients: Patients[] = [];
  wards: Ward[] = [];
  constructor(
    private dialogRef: MatDialogRef<EmergencyAdmissionCreateUpdateComponent>,
    private patientService: PatientService,
    private fb: UntypedFormBuilder,
    private translate: TranslateService,
    private roomService: RoomService,
    @Inject(MAT_DIALOG_DATA) public data: EmergencyAdmission,
  ) {
    console.log('data');
    console.log(data);
    this.patientService.getPatients().subscribe((rep) => {
      this.patients = rep;
    });

    this.roomService.getWards().subscribe((rep) => {
      this.wards = rep;
    });
  }

  ngOnInit() {
    this.form = this.fb.group({
      patientId: [this.data.patientId],
      patientName: [this.data.patientName],
      admissionDate: [new Date()],
      conditionDescription: [''],
      wardId: [''],
      roomId: [''],
      check_IN: [new Date()],
      check_Out: [new Date()],
      codeTreatment: [this.data.codeTreatment],
      treatmentId: [this.data.id],
      bedId: ['']
    });
  }
  rooms: Room[] = [];
  onWardChange(event$: any) {
    console.log(event$);
    this.rooms = this.wards.flatMap(i => i.rooms).filter(t => t.id === event$.value);
    // Filter designations based on the selected department
  }
  beds: Bed[] = [];
  onRoomChange(roomEvent$: any) {
    console.log(roomEvent$);
    this.beds = this.wards.flatMap(i => i.rooms).filter(r => r.id === roomEvent$.value).flatMap(y => y.beds);
    // Filter designations based on the selected department
  }

  // getFilteredRooms(wardId: any): Room[] {
  //   if (!wardId) return []; // Handle case when no ward is selected
  //   return this.wards.flatMap(ward => ward.rooms).filter(room => room.id === wardId);
  // }

  // getFilteredBeds(roomId: any): Bed[] {
  //   if (!roomId) return []; // Handle case when no room is selected
  //   return this.wards
  //     .flatMap(ward => ward.rooms)
  //     .flatMap(room => room.beds)
  //     .filter(bed => bed.id === roomId);
  // }

  save() {
    if (this.form.valid) {
      const emergencyAdmission: EmergencyAdmission = this.form.value;
      this.dialogRef.close(emergencyAdmission);
    }
  }
}
