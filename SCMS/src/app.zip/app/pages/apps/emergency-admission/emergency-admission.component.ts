import { AfterViewInit, Component, DestroyRef, inject, Input, OnInit, ViewChild } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { SelectionModel } from '@angular/cdk/collections';

import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { EmergencyAdmissionCreateUpdateComponent } from './emergency-admission-create-update/emergency-admission-create-update';
import { EmergencyAdmission, EmergencyAdmissionService } from './emergency-admission.service';
import { DailyTreatmentCreateUpdateComponent } from './daily-treatment-create-update/daily-treatment-create-update';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { MatButtonToggleModule } from '@angular/material/button-toggle';

@Component({
  selector: 'vex-analysisLaboratory',
  templateUrl: './emergency-admission.component.html',
  styleUrls: ['./emergency-admission.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    TranslateModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatMenuModule,
    VexBreadcrumbsComponent,
    VexPageLayoutComponent,
    VexPageLayoutHeaderDirective,
    VexPageLayoutContentDirective,
    NgIf,
    NgFor,
    NgClass,
    MatButtonToggleModule
  ],
  animations: [
    fadeInUp400ms,
    stagger40ms,
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'standard'
      } as unknown as MatFormFieldDefaultOptions
    }
  ]
})
export class EmergencyAdmissionComponent implements OnInit, AfterViewInit {

  layoutCtrl = new UntypedFormControl('fullwidth');
  subject$: ReplaySubject<EmergencyAdmission[]> = new ReplaySubject<EmergencyAdmission[]>(1);
  data$: Observable<EmergencyAdmission[]> = this.subject$.asObservable();
  analysislaboratory: EmergencyAdmission[];
  expandedElement: any | null;
  @Input() columns: TableColumn<any>[] = [
    // { label: this.translate.instant('ID'), property: 'id', type: 'text', visible: true },
    { label: this.translate.instant('patientName'), property: 'patientName', type: 'text', visible: true },
    { label: this.translate.instant('accommodation'), property: 'accommodation', type: 'text', visible: true },
    { label: this.translate.instant('codeTreatment'), property: 'codeTreatment', type: 'text', visible: true },

    { label: this.translate.instant('emergencyCreated'), property: 'emergencyAdmissionId', type: 'text', visible: true },

    { label: this.translate.instant('ADMISSION_DATE'), property: 'admissionDate', type: 'text', visible: true },
    { label: this.translate.instant('CONDITION_DESCRIPTION'), property: 'conditionDescription', type: 'text', visible: true },
    { label: this.translate.instant('WARD'), property: 'ward', type: 'text', visible: true },
    { label: this.translate.instant('ROOM_NUMBER'), property: 'roomNumber', type: 'text', visible: true },
    { label: 'Actions', property: 'actions', type: 'button', visible: true },
    // { label: 'expandedDetail', property: 'expandedDetail', type: 'button', visible: true ,matColumnDef:'expandedDetail' },

     { label: 'TableExpanded', property: 'isExpanded', type: 'button', visible: true  },

  ];
  // subTableColumns: any[] = [
  //   { label: 'تاريخ الايراد', colspan: 1 ,matColumnDef:'treatmentDate', property: 'treatmentDate',   type: 'text' },
  //   { label: 'الايراد الصوتي', colspan: 1,matColumnDef:'treatmentDetails', property: 'treatmentDetails',  type: 'text'},

  // ];
  subTableColumns = ['treatmentDate', 'treatmentDetails', 'nurseNotes','actions'];

  toggleRow(element: any) {
    element.isExpanded = !element.isExpanded;
    this.expandedElement = this.expandedElement === element ? null : element;
  }
   masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }



  // TREATMENT_DATE TREATMENT_DETAILS
  // expandedRowIndex = -1;


  stateiniExt = false ;
  toggleExpand(element: any): void {

    this.stateiniExt=  !  element.isExpanded;


      this.dataSource.data.forEach((row: any) => {
        row.isExpanded = false;
      })
      element.isExpanded =this.stateiniExt;
      this.stateiniExt = false

    }

  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<EmergencyAdmission> | null;
  selection = new SelectionModel<EmergencyAdmission>(true, []);
  searchCtrl = new UntypedFormControl();

  labels = [];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private dialog: MatDialog, private analysislaboratoryService: EmergencyAdmissionService, private translate: TranslateService) {}

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  ngOnInit() {
    this.analysislaboratoryService.getEmergencyAdmissions().subscribe(analysislaboratory => {
      this.subject$.next(analysislaboratory);
    });

    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter<EmergencyAdmission[]>(Boolean)
    ).subscribe(analysisLaboratory => {
      this.analysislaboratory = analysisLaboratory;
      this.dataSource.data = analysisLaboratory;
    });


    this.searchCtrl.valueChanges
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe((value) => this.onFilterChange(value));
    this.dataSource.data.forEach((row: any) => {
      row.isExpanded = false;
    })
  }


      private readonly destroyRef: DestroyRef = inject(DestroyRef);

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createanalysisLaboratory(row?:EmergencyAdmission) {

    console.log(row)
    const dialogRef = this.dialog.open(EmergencyAdmissionCreateUpdateComponent, {
      minWidth: '600px',
      minHeight: '950px',
      data:row
    }).afterClosed().subscribe((analysisLaboratory: EmergencyAdmission) => {
      if (analysisLaboratory) {
        this.analysislaboratoryService.createEmergencyAdmission(analysisLaboratory).subscribe(() => {
          analysisLaboratory.dailyTreatmentaTotal =0;
          this.analysislaboratory.unshift(analysisLaboratory);
          this.subject$.next(this.analysislaboratory);
        });
      }
    });
  }

  updateanalysisLaboratory(analysisLaboratory: EmergencyAdmission) {
    this.dialog.open(EmergencyAdmissionCreateUpdateComponent, {
         height:'629px',
         width:'900px',
      data: analysisLaboratory
    }).afterClosed().subscribe(updatedanalysisLaboratory => {
      if (updatedanalysisLaboratory) {
        this.analysislaboratoryService.createEmergencyAdmission(updatedanalysisLaboratory).subscribe(() => {
          const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.codeTreatment === updatedanalysisLaboratory.codeTreatment);
          this.analysislaboratory[index] = updatedanalysisLaboratory;
          this.analysislaboratory[index].emergencyAdmissionId = 1;
          this.subject$.next(this.analysislaboratory);

          // analysisLaboratory.dailyTreatmentaTotal =0;
          // this.analysislaboratory.unshift(analysisLaboratory);
          // this.subject$.next(this.analysislaboratory);
        });
      }
    });
  }

  addDailyTreatment(analysisLaboratory: EmergencyAdmission) {
    this.dialog.open(DailyTreatmentCreateUpdateComponent, {
   //   height:'900px',
      width:'900px',
      data: analysisLaboratory
    }).afterClosed().subscribe(updatedDailyTreatment => {
      if (updatedDailyTreatment) {
        this.analysislaboratoryService.addDailyTreatment(analysisLaboratory.id, updatedDailyTreatment).subscribe(() => {
          const index = this.analysislaboratory.findIndex(c => c.id === analysisLaboratory.id);
          this.analysislaboratory[index]?.dailyTreatment?.push(updatedDailyTreatment);
          this.subject$.next(this.analysislaboratory);
        });
      }
    });
  }

  deleteanalysisLaboratory(analysisLaboratory: EmergencyAdmission) {
    this.analysislaboratoryService.deleteEmergencyAdmission(analysisLaboratory.id).subscribe(() => {
      this.analysislaboratory.splice(this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === analysisLaboratory.id), 1);
      this.selection.deselect(analysisLaboratory);
      this.subject$.next(this.analysislaboratory);
    });
  }

  deleteanalysisLaboratoryz(analysisLaboratory: EmergencyAdmission[]) {
    analysisLaboratory.forEach(c => this.deleteanalysisLaboratory(c));
  }
  exitAnalysisLaboratory(analysisLaboratory: any) {
    this.analysislaboratoryService.dischargePatient(analysisLaboratory.id).subscribe(() => {
      const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === analysisLaboratory.id);
      this.analysislaboratory[index].exit = true;
      this.analysislaboratory[index].exitDate = new Date().toISOString();
      this.subject$.next(this.analysislaboratory);
    });
    }
 deleteTreatment(treatment: any ,element:any) {
  this.analysislaboratoryService.deleteTreatment(treatment.id).subscribe(() => {
    const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === element.id);
    const index_dailyTreatmenta = element.dailyTreatmenta.findIndex((existingTreatment: any) => existingTreatment.id === treatment.id);

    this.analysislaboratory[index].dailyTreatment.splice(index_dailyTreatmenta, 1);
    this.subject$.next(this.analysislaboratory);


  });

}

    editTreatment(_t275: any) {


      if (_t275) {
        // this.analysislaboratoryService.updateTreatment(updatedanalysisLaboratory.id, updatedanalysisLaboratory).subscribe(() => {
        //   const index = this.analysislaboratory.findIndex(existinganalysisLaboratory => existinganalysisLaboratory.id === updatedanalysisLaboratory.id);
        //   this.analysislaboratory[index] = updatedanalysisLaboratory;
        //   this.subject$.next(this.analysislaboratory);
        // });
      }


     }
  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  toggleColumnVisibility(column, event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }



  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }

  onLabelChange(change: MatSelectChange, row: EmergencyAdmission) {
    const index = this.analysislaboratory.findIndex(c => c === row);
    this.analysislaboratory[index].id = change.value;
    this.subject$.next(this.analysislaboratory);
  }

  // toggleRow(row: EmergencyAdmission) {
  //   if (this.expandedRows.has(row.id)) {
  //     this.expandedRows.delete(row.id);
  //   } else {
  //     this.expandedRows.add(row.id);
  //   }
  // }

  // isRowExpanded(row: EmergencyAdmission): boolean {
  //   return this.expandedRows.has(row.id);
  // }
}
