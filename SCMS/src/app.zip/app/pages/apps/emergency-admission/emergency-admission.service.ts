import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmergencyAdmissionService {
  deleteTreatment(id: any) {
     return this.http.delete<void>(`${this.apiUrl}/dailytreatment?id=${id}`);
  }
  private apiUrl = `${environment.apiUrl}/emergencyadmission`;

  constructor(private http: HttpClient) { }

  getEmergencyAdmissions(): Observable<EmergencyAdmission[]> {
    return this.http.get<EmergencyAdmission[]>(`${this.apiUrl}`);
  }

  getEmergencyAdmission(id: number): Observable<EmergencyAdmission> {
    return this.http.get<EmergencyAdmission>(`${this.apiUrl}/${id}`);
  }

  createEmergencyAdmission(admission: EmergencyAdmission): Observable<EmergencyAdmission> {
    return this.http.post<EmergencyAdmission>(this.apiUrl, admission);
  }

  updateEmergencyAdmission(id: number, admission: EmergencyAdmission): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, admission);
  }

  deleteEmergencyAdmission(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  addDailyTreatment(id: number, treatment: DailyTreatment): Observable<DailyTreatment> {
    return this.http.post<DailyTreatment>(`${this.apiUrl}/${id}/dailytreatment`, treatment);
  }

  dischargePatient(id: number): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/${id}/discharge`, {});
  }
}

export interface DailyTreatment {
  id: number;
  emergencyAdmissionId: number;
  treatmentDate: Date;
  treatmentDetails?: string;
  nurseNotes?: string;
}


export interface  EmergencyAdmission {//TreatmentEmergency {
  patientId: number;
  patientName: string | null;
  admissionDate: string; // Use Date if you want to parse it later
  codeTreatment: string;
  conditionDescription: string | null;
  ward: string | null;
  roomNumber: string | null;
  bed:Bed;
  BedId:number;
  dailyTreatment: DailyTreatment[] ;
  exitDate: string; // Use Date if you want to parse it later
  exit: boolean;
  dailyTreatmentaTotal: number | null;
  id: number;
  isExpanded?:any;
  accommodation:boolean
  emergencyCreated :boolean
 emergencyAdmissionId?: number;
}


export interface EmergencyAdmission_items {
  patientId: number;
  patientName: string;
  admissionDate: string; // ISO 8601 date string
  conditionDescription: string;
  ward: string;
  roomNumber: string;
  dailyTreatment: DailyTreatment[];
  exitDate: string; // ISO 8601 date string
  exit: boolean;
  dailyTreatmentaTotal: number;
  id: number;
  isExpanded?:any;
}


export interface Bed {
  id: number;
  bedNumber: string;
  status: number;
  state: boolean;
}

export interface Room {
  id: number;
  roomNumber: string;
  name: string;
  capacity: number;
  beds: Bed[];
}

export interface Ward {
  id: number;
  wardType: string;
  wardDescription: string;
  rooms: Room[];
}
