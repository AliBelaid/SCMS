import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UntypedFormBuilder, UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { DailyTreatment, EmergencyAdmission } from '../emergency-admission.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatButtonModule } from '@angular/material/button';
import { TranslateModule } from '@ngx-translate/core';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'vex-daily-treatment-create-update',
  templateUrl: './daily-treatment-create-update.html',
  styleUrls: ['./daily-treatment-create-update.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    TranslateModule
  ]
})
export class DailyTreatmentCreateUpdateComponent implements OnInit {
  form: UntypedFormGroup;
  mode: 'create' | 'update' = 'create';

  constructor(
    private dialogRef: MatDialogRef<DailyTreatmentCreateUpdateComponent>,
    @Inject(MAT_DIALOG_DATA) public data:EmergencyAdmission,
    private fb: UntypedFormBuilder
  ) {}

  ngOnInit() {


      this.form = this.fb.group({
       // id: [this.data.treatment.id],
        emergencyAdmissionId: [this.data.id],
        treatmentDate: [],
        treatmentDetails: [ ''],
        nurseNotes: ['']
      });

  }

  save() {
    if (this.form.valid) {
      const dailyTreatment: DailyTreatment = this.form.value;
      this.dialogRef.close(dailyTreatment);
    }
  }

  isCreateMode() {
    return this.mode === 'create';
  }

  isUpdateMode() {
    return this.mode === 'update';
  }
}
