import { NgModule } from '@angular/core';
import { CommonModule, DatePipe, NgClass, NgFor, NgIf } from '@angular/common';

import {   AnalysisLaboratoryRoutingModule } from './analysis-laboratory-routing.module';

import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonToggleModule } from '@angular/material/button-toggle';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatFormFieldModule } from '@angular/material/form-field';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { MatDividerModule } from '@angular/material/divider';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatOptionModule } from '@angular/material/core';
import { MaterialFileInputModule } from 'ngx-material-file-input';

import { AnalysisCreateUpdateComponent } from './analysis-create-update/analysis-create-update.component';
import { AnalysisLaboratoryComponent } from './analysis-laboratory.component';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { AnalysisPatientCreateComponent } from '../analysis-patient/analysis-create/analysis-create.component';
import { analysisPatientCreateUpdateComponent } from '../analysis-patient/analysis-create-update/analysis-patient-create-update.component';
import { MatListModule } from '@angular/material/list';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MatCardModule } from '@angular/material/card';
import { DragDropModule } from '@angular/cdk/drag-drop';


@NgModule({
   imports: [
    CommonModule,
    AnalysisLaboratoryRoutingModule,
TranslateModule,
    VexBreadcrumbsComponent,
    MatPaginatorModule,
    MatTableModule,
    MatSortModule,
    MatCheckboxModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
     HttpClientModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonToggleModule ,
    MatDialogModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatRadioModule,
    MatSelectModule,
    MatMenuModule,
MatDatepickerModule,
MatFormFieldModule,
    MatDividerModule,
      TranslateModule,
    MatSelectModule
    ,MatOptionModule,




 MatCardModule

   , DragDropModule,


   MatDialogModule,      // إضافة MatDialogModule هنا
   VexBreadcrumbsComponent,
   TranslateModule,



    MaterialFileInputModule,
    MatPaginatorModule
   , MatListModule ,
   VexPageLayoutComponent,
VexPageLayoutHeaderDirective,
VexPageLayoutContentDirective,
NgIf,
NgFor,
NgClass,
  ],  providers: [
    DatePipe,

  ],


})
export class analysisLaboratoryModule {
}

