import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class analysisLaboratoryService {


  private apiUrl = environment.apiUrl+'/MedicalAnalyses';

  constructor(private http: HttpClient) { }

  getMedicalAnalyses(): Observable<MedicalAnalysis[]> {
    return this.http.get<MedicalAnalysis[]>(this.apiUrl);
  }

  getMedicalAnalysis(id: number): Observable<MedicalAnalysis> {
    return this.http.get<MedicalAnalysis>(`${this.apiUrl}/${id}`);
  }

  createMedicalAnalysis(medicalAnalysis: MedicalAnalysis): Observable<MedicalAnalysis> {
    return this.http.post<MedicalAnalysis>(this.apiUrl, medicalAnalysis);
  }

  updateMedicalAnalysis(id: number, medicalAnalysis: MedicalAnalysis): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, medicalAnalysis);
  }

  deleteMedicalAnalysis(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

}
// src/app/models/medical-analysis.model.ts
export interface MedicalAnalysis {
  id: number;
  code: string;
  name: string;
  iS_EXIST: boolean;
  status: boolean;
  lastUpdate: string;
  medicalType: number;
  medicalAnalysisPatient: any;
 }
