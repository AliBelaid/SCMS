import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { DoctorService } from 'src/app/doctor/doctor.service';
import { CalendarEvent } from 'angular-calendar';
import { Patients, Doctor, ShiftDto, DoctorShifts, QueuePatient } from 'src/assets/his.model';
import { PatientService } from 'src/app/patients/patient.service';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { TranslateModule } from '@ngx-translate/core';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { MatRadioModule } from '@angular/material/radio';
import { MaterialFileInputModule } from 'ngx-material-file-input';

@Component({
  selector: 'vex-analysis-create-update',
  templateUrl: './analysis-create-update.component.html',
  styleUrls: ['./analysis-create-update.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatOptionModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatMenuModule,
    MatTableModule,
    MatCheckboxModule,
    MatMenuModule ,
    MatDividerModule,
    MatListModule,
    TranslateModule ,
    MatRadioModule,
    MaterialFileInputModule
  ]
})
export class AnalysisCreateUpdateComponent implements OnInit {


  form: UntypedFormGroup;
  mode: 'create' | 'update' = 'create';
  patients:Patients[]=[];
doctors:Doctor[]=[];
 DoctorShifts: ShiftDto[] = [];
displayedColumns: string[] = ['select', 'day', 'count', 'start', 'end'];


  constructor(@Inject(MAT_DIALOG_DATA) public defaults: CalendarEvent,
              private dialogRef: MatDialogRef<AnalysisCreateUpdateComponent>,private _patientService:PatientService,
              private _doctorService:DoctorService,
              private fb: UntypedFormBuilder) {

                this._patientService.getPatients().subscribe((rep)=>{
                  this.patients = rep;
                });
                this._doctorService.getDoctors().subscribe((rep)=>{
                  this.doctors = rep;

                });

              //   {
              //     "id": 3,
              //     "name": "DrLee",
              //     "start": "2024-05-07T20:00:00.000Z",
              //     "end": "2024-05-07T00:00:00.000Z",
              //     "title": "DrLee-علم الأعصاب",
              //     "color": {
              //         "primary": "#1e90ff",
              //         "secondary": "#D1E8FF"
              //     },
              //     "meta": {
              //         "doctorId": 3
              //     }
              // }

  }

  ngOnInit() {
    if (this.defaults) {
      this.mode = 'update';
      this.form = this.fb.group({
        id: [this.defaults.id],
        patientId: [''],
         doctorId: [this.defaults.doctorId || ''],
        meetingType:[2] ,
       numberOfQueue:[0] ,   shiftId:[]
      });

      this.onDoctorCall();
      console.log(this.form.value)
    } else {
      this.form = this.fb.group({
         patientId: [''],
         doctorId: [''],
        shiftId:[],
        meetingType:[2] ,
       numberOfQueue:[0]

      });

    }


  }

  onShiftChange(event: any) {
    //const selectedShift = event.checked ? event.source.value : null;
    console.log(event)
    this.form.patchValue({ shiftId: event.id });


      if(event.totalNumbersIssued==0)
     {  this.form.patchValue({ numberOfQueue: 1 });}else {
      this.form.patchValue({ numberOfQueue: event.totalNumbersIssued+1 });
     }

  }
  onPatientChange(event): void {
    const selectedPatient = this.patients.find(patient => patient.id === event.value);
    if (selectedPatient) {
      if(this.defaults.id) {
       let  shift =  this.DoctorShifts[0];
        if(shift.totalNumbersIssued==0)
          {  this.form.patchValue({ numberOfQueue: 1 });}else {
           this.form.patchValue({ numberOfQueue: shift.totalNumbersIssued+1 });
          }

      }
    //  this.form.get('patientName').setValue(`${selectedPatient.firstName} ${selectedPatient.lastName}`);
    }
  }

  onDoctorChange(event): void {
    console.log(event);
    const selectedDoctor = this.doctors.find(doctor => doctor.id === event.value);
    if (selectedDoctor) {
      this._doctorService.getDoctorShiftDetails(event.value).subscribe(
        (data) => {
          // Convert response to ShiftDto[] 
          this.DoctorShifts = Array.isArray(data) ? data : [data]; 
          // Filter active queues
          this.DoctorShifts = this.DoctorShifts.filter(shift => shift.isActiveQueue);
        },
        (error) => {
          console.error('Error fetching shift details', error);
        }
      );
    }
  }
  onDoctorCall(): void {
    const selectedDoctor = this.doctors.find(doctor => doctor.id === this.defaults.doctorId);
    if (selectedDoctor) {
      this._doctorService.getShiftById(Number(this.defaults.id)).subscribe(
        (data: ShiftDto) => {
          this.DoctorShifts = [data];
          this.form.patchValue({ shiftId: this.defaults.id });

          // Update queue number based on totalNumbersIssued
          if (data.totalNumbersIssued === 0) {
            this.form.patchValue({ numberOfQueue: 1 });
          } else {
            this.form.patchValue({ numberOfQueue: data.totalNumbersIssued + 1 });
          }
        },
        (error) => {
          console.error('Error fetching shift details', error);
        }
      );
    }
    
    if (selectedDoctor) {
      this.form.get('doctorName').setValue(`${selectedDoctor.firstName} ${selectedDoctor.lastName} / ${selectedDoctor.specialization}`);
    }
  }
  save() {
    if (this.form.valid) {
      this._doctorService.addToQueue(this.form.value).subscribe(
        (response: QueuePatient) => {
          console.log(response);
          this.dialogRef.close(response);
        },
        (error: any) => {
          console.error(error);
          alert('An error occurred while adding the patient to the queue.');
        }
      );
    }
  }

  createmedicalrecord() {
    const medicalrecord = this.form.value;



    this.dialogRef.close(medicalrecord);
  }

  updatemedicalrecord() {
    const medicalrecord = this.form.value;
    medicalrecord.id = this.defaults.id;

    this.dialogRef.close(medicalrecord);
  }

  isCreateMode() {
    return this.mode === 'create';
  }

  isUpdateMode() {
    return this.mode === 'update';
  }
}

