import { Routes } from '@angular/router';
import { AnalysisLaboratoryComponent } from './analysis-laboratory.component';

export const ANALYSIS_LABORATORY_ROUTES: Routes = [
  {
    path: '',
    component: AnalysisLaboratoryComponent
  }
];
