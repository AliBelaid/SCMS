import { AfterViewInit, Component, DestroyRef, inject, Input, OnInit, ViewChild } from '@angular/core';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { SelectionModel } from '@angular/cdk/collections';

import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import {Bed, BedStatus, Room,RoomService } from './room.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { RoomCreateUpdateComponent } from './room-create-update/room-create-update.component';
import { BedCreateUpdateComponent } from './bed-create-update/bed-create-update.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';

@Component({
  selector: 'vex-rooms',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.scss'],
  animations: [
    fadeInUp400ms,
    stagger40ms ,

      trigger('detailExpand', [
        state('collapsed', style({ height: '0px', minHeight: '0' })),
        state('expanded', style({ height: '*' })),
        transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
      ]),
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'standard'
      } as unknown as MatFormFieldDefaultOptions
    }
  ],

  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatListModule,
    MatCheckboxModule,
    TranslateModule ,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatTableModule,
    MatCheckboxModule,
    MatIconModule,
    MatDividerModule, MatSnackBarModule,
    CommonModule,
    MatDialogModule,      // إضافة MatDialogModule هنا
   VexBreadcrumbsComponent,
   TranslateModule,
   MatDatepickerModule,
   DialogModule,
   MatTreeModule,
   CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    MatRippleModule,
    CdkStepperModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatSnackBarModule,
    MatInputModule,VexPageLayoutComponent,
    MatDatepickerModule,
    MatNativeDateModule
  , MatNativeDateModule,
  MatSliderModule ,
  MatFormFieldModule,
     MatStepperModule,
    MatOptionModule
    ,VexPageLayoutContentDirective ,VexPageLayoutHeaderDirective ,
    FormsModule,
   MatRippleModule,
   MatIconModule ,
   MatTabsModule,
   MatIconModule,
   DragDropModule
  ]
})
export class RoomComponent implements OnInit, AfterViewInit {

  layoutCtrl = new UntypedFormControl('fullwidth');
  subject$: ReplaySubject<Room[]> = new ReplaySubject<Room[]>(1);
  data$: Observable<Room[]> = this.subject$.asObservable();
  rooms:Room[];
  expandedElement: any | null;
  @Input() columns: TableColumn<any>[] = [
    { label: this.translate.instant('ROOM_NAME'), property: 'name', type: 'text', visible: true },
    { label: this.translate.instant('CAPACITY'), property: 'capacity', type: 'text', visible: true },
    { label: this.translate.instant('Total_Beds'), property: 'totalBeds', type: 'text', visible: true },
    { label: 'Actions', property: 'actions', type: 'button', visible: true },
    { label: 'TableExpanded', property: 'isExpanded', type: 'button', visible: true },
  ];
  subTableColumns = ['bedNumber', 'status', 'actions'];


  // changeBedState(bedId: number, newState: boolean, status: BedStatus) {
  //   this.roomService.changeBedState(bedId, newState, status).subscribe(response => {
  //     console.log('Bed state changed successfully');
  //   }, error => {
  //     console.error('Error changing bed state', error);
  //   });
  // }
  toggleRow(element: any) {
    element.isExpanded = !element.isExpanded;
    this.expandedElement = this.expandedElement === element ? null : element;
  }
   masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }



  // TREATMENT_DATE TREATMENT_DETAILS
  // expandedRowIndex = -1;


  stateiniExt = false ;
  toggleExpand(element: any): void {

    this.stateiniExt=  !  element.isExpanded;


      this.dataSource.data.forEach((row: any) => {
        row.isExpanded = false;
      })
      element.isExpanded =this.stateiniExt;
      this.stateiniExt = false

    }

  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 20, 50];
  dataSource: MatTableDataSource<Room> | null;
  selection = new SelectionModel<Room>(true, []);
  searchCtrl = new UntypedFormControl();

  labels = [];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private dialog: MatDialog, private roomService:RoomService, private translate: TranslateService) {}

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  ngOnInit() {
    this.roomService.getRooms().subscribe(rooms => {
      this.subject$.next(rooms);
    });

    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter<Room[]>(Boolean)
    ).subscribe(rooms => {
      this.rooms = rooms;
      this.dataSource.data = rooms;
    });

      this.searchCtrl.valueChanges
         .pipe(takeUntilDestroyed(this.destroyRef))
         .subscribe((value) => this.onFilterChange(value));
    }
    private readonly destroyRef: DestroyRef = inject(DestroyRef);

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  createRoom() {
    const dialogRef = this.dialog.open(RoomCreateUpdateComponent, {
      minWidth: '600px',
      minHeight: '750px',
    }).afterClosed().subscribe((rooms:Room) => {
      if (rooms) {
        this.roomService.createRoom(rooms).subscribe(() => {
          rooms.totalBeds =0;
          this.rooms.unshift(rooms);
          this.subject$.next(this.rooms);
        });
      }
    });
  }

  updateRoom(rooms:Room) {
    this.dialog.open(RoomCreateUpdateComponent, {
      data: rooms
    }).afterClosed().subscribe(updatedrooms => {
      if (updatedrooms) {
        this.roomService.updateRoom(updatedrooms).subscribe(() => {
          const index = this.rooms.findIndex(existingrooms => existingrooms.id === updatedrooms.id);
          this.rooms[index] = updatedrooms;
          this.subject$.next(this.rooms);
        });
      }
    });
  }

  addBed(rooms:Room) {

   const  defaults = {
    mode: 'create'
   }
    this.dialog.open(BedCreateUpdateComponent, {
      data: rooms
    }).afterClosed().subscribe(updatedBed => {
      if (updatedBed) {
        this.roomService.addBed(rooms.id, updatedBed).subscribe(() => {
          const index = this.rooms.findIndex(c => c.id === rooms.id);
          this.rooms[index].beds.push(updatedBed);
          this.subject$.next(this.rooms);
        });
      }
    });
  }

  deleteRoom(rooms:Room) {
    this.roomService.deleteRoom(rooms.id).subscribe(() => {
      this.rooms.splice(this.rooms.findIndex(existingrooms => existingrooms.id === rooms.id), 1);
      this.selection.deselect(rooms);
      this.subject$.next(this.rooms);
    });
  }

  deleteroomsz(rooms:Room[]) {
    rooms.forEach(c => this.deleteRoom(c));
  }
  exitrooms(rooms: any) {
    // this.roomService.dischargePatient(rooms.id).subscribe(() => {
    //   const index = this.rooms.findIndex(existingrooms => existingrooms.id === rooms.id);
    //  this.rooms[index]. = true;
   //   this.rooms[index].exitDate = new Date().toISOString();
  //    this.subject$.next(this.rooms);
//    });
    }
//  deleteBed(treatment: any ,element:any) {
//   this.roomService.deleteBed(treatment.id).subscribe(() => {
//     const index = this.rooms.findIndex(existingrooms => existingrooms.id === element.id);
//     const index_Beda = element.Beda.findIndex((existingTreatment: any) => existingTreatment.id === treatment.id);

//     this.rooms[index].Beds.splice(index_Beda, 1);
//     this.subject$.next(this.rooms);

//   });

// }
bedStatuses = Object.values(BedStatus);

changeBedStatus(bed: Bed) {
  this.roomService.changeBedState(bed.id, bed.state, bed.status).subscribe(response => {
    console.log('Bed status changed successfully');
  }, error => {
    console.error('Error changing bed status', error);
  });
}

changeBedState(bed: Bed) {
  this.roomService.changeBedState(bed.id, bed.state, bed.status).subscribe(response => {
    console.log('Bed state changed successfully');
  }, error => {
    console.error('Error changing bed state', error);
  });
}

deleteBed(bed: Bed) {
  this.roomService.deleteBed(bed.id).subscribe(response => {
    console.log('Bed deleted successfully');
    // تحديث البيانات بعد الحذف
  }, error => {
    console.error('Error deleting bed', error);
  });
}
    editTreatment(_t275: any) {


      if (_t275) {
        // this.roomService.updateTreatment(updatedrooms.id, updatedrooms).subscribe(() => {
        //   const index = this.rooms.findIndex(existingrooms => existingrooms.id === updatedrooms.id);
        //   this.rooms[index] = updatedrooms;
        //   this.subject$.next(this.rooms);
        // });
      }


     }
  onFilterChange(value: string) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  toggleColumnVisibility(column, event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    column.visible = !column.visible;
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }



  trackByProperty<T>(index: number, column: TableColumn<T>) {
    return column.property;
  }

  onLabelChange(change: MatSelectChange, row:Room) {
    const index = this.rooms.findIndex(c => c === row);
    this.rooms[index].id = change.value;
    this.subject$.next(this.rooms);
  }


}
