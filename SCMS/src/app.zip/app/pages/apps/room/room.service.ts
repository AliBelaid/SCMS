import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ward } from '../emergency-admission/emergency-admission.service';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  private apiUrl = environment.apiUrl; // استبدل بـ URL الخاص بواجهة برمجة التطبيقات

  constructor(private http: HttpClient) {}

  getRooms(): Observable<Room[]> {
    return this.http.get<Room[]>(`${this.apiUrl}/rooms`);
  }

  getWards(): Observable<Ward[]> {
    return this.http.get<Ward[]>(`${this.apiUrl}/rooms/wards`);
  }

  getRoomById(id: number): Observable<Room> {
    return this.http.get<Room>(`${this.apiUrl}/rooms/${id}`);
  }

  createRoom(room: any): Observable<Room> {
    return this.http.post<Room>(`${this.apiUrl}/rooms`, room);
  }

  updateRoom(room: Room): Observable<Room> {
    return this.http.put<Room>(`${this.apiUrl}/rooms/${room.id}`, room);
  }

  deleteRoom(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/rooms/${id}`);
  }

  addBed(roomId: number, bed: any): Observable<Bed> {
    return this.http.post<Bed>(`${this.apiUrl}/rooms/${roomId}/beds`, bed);
  }

  deleteBed(bedId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/beds/${bedId}`);
  }
  changeBedState(bedId: number, newState: boolean, status: BedStatus): Observable<Bed> {
    return this.http.patch<Bed>(`${this.apiUrl}/beds/${bedId}`, { newState, status });
  }
}

export interface Room {
  id: number;
  name: string;
  capacity: number;
  totalBeds: number;
  beds: Bed[];
  isExpanded?:boolean

}

export interface Bed {
  id: number;  bedNumber:string
  roomId: number;
  status: BedStatus; // استخدام التعداد
  state: boolean; // حالة السرير (مثال: true أو false)
}

export enum BedStatus {
  Available =1,
  Occupied = 2,
  Maintenance = 3
}


// export interface Room {
//   id: number;
//   name: string;
//   capacity: number;
//   totalBeds :number
//   Beds:Bed[]
// }
// export interface Bed {
//   id: number;
//   roomId: number;
//   status: string; // يمكن أن يكون "متاح"، "مشغول"، إلخ
// }
