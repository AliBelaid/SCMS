import { Routes } from '@angular/router';

export const ROOM_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./room.component').then(m => m.RoomComponent)
  }
];
