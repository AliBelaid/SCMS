import { Component, Inject, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { Room, Bed, RoomService } from '../room.service';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { TranslateModule } from '@ngx-translate/core';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';

@Component({
  selector: 'vex-bed-create-update',
  templateUrl: './bed-create-update.component.html',
  styleUrls: ['./bed-create-update.component.scss']
  ,
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatListModule,
    MatCheckboxModule,
    TranslateModule ,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatTableModule,
    MatCheckboxModule,
    MatIconModule,
    MatDividerModule, MatSnackBarModule,
    CommonModule,
    MatDialogModule,      // إضافة MatDialogModule هنا
   VexBreadcrumbsComponent,
   TranslateModule,
   MatDatepickerModule,
   DialogModule,
   MatTreeModule,
   CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    MatRippleModule,
    CdkStepperModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatSnackBarModule,
    MatInputModule,VexPageLayoutComponent,
    MatDatepickerModule,
    MatNativeDateModule
  , MatNativeDateModule,
  MatSliderModule ,
  MatFormFieldModule,
     MatStepperModule,
    MatOptionModule
    ,VexPageLayoutContentDirective ,VexPageLayoutHeaderDirective ,
    FormsModule,
   MatRippleModule,
   MatIconModule ,
   MatTabsModule,
   MatIconModule,
   DragDropModule
  ]
})
export class BedCreateUpdateComponent implements OnInit {
  form: UntypedFormGroup;
  mode: 'create' | 'update' = 'create';
  rooms: Room[] = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public defaults: any,
    private dialogRef: MatDialogRef<BedCreateUpdateComponent>,
    private fb: UntypedFormBuilder,
    private roomService: RoomService
  ) {}

  ngOnInit() {
    this.roomService.getRooms().subscribe((rooms) => {
      this.rooms = rooms;
    });

    if (this.defaults.mode === 'update') {

      this.form = this.fb.group({
         id: [this.defaults.id],
        roomId: [this.defaults.roomId || ''],
        status: [this.defaults.status || ''] ,bedNumber:[this.defaults.bedNumber]

      });
    }

    else {
      this.form = this.fb.group({
        roomId: [''],
        status: ['available'] ,bedNumber:[]
      });
    }
  }

  save() {
    if (this.form.valid) {
      const bed = this.form.value;
      this.dialogRef.close(bed);
    }
  }

  isCreateMode() {
    return this.mode === 'create';
  }

  isUpdateMode() {
    return this.mode === 'update';
  }
}
