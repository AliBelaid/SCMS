import { NgModule } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';

import {   PharmaceuticalRoutingModule } from './room-routing.module';

import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { HttpClientModule } from '@angular/common/http';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatFormFieldModule } from '@angular/material/form-field';
import { TranslateModule } from '@ngx-translate/core';
import { MatDividerModule } from '@angular/material/divider';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatOptionModule } from '@angular/material/core';
import { MaterialFileInputModule } from 'ngx-material-file-input';

import { RoomComponent } from './room.component';
import { RoomCreateUpdateComponent } from './room-create-update/room-create-update.component';
import { BedCreateUpdateComponent } from './bed-create-update/bed-create-update.component';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PharmaceuticalRoutingModule,
TranslateModule,

    VexBreadcrumbsComponent,
    MatPaginatorModule,
    MatTableModule,
    MatSortModule,
    MatCheckboxModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
     HttpClientModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonToggleModule ,TranslateModule,MatIconModule,
    MatDialogModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatRadioModule,
    MatSelectModule,
    MatMenuModule,
MatDatepickerModule,
MatFormFieldModule,
    MatDividerModule,
      TranslateModule,
    MatSelectModule
    ,MatOptionModule,
    MaterialFileInputModule,
 TranslateModule,

 VexPageLayoutComponent,
 VexPageLayoutHeaderDirective,
 VexPageLayoutContentDirective,
 NgIf,
 NgFor,
 NgClass,
 TranslateModule

  ]
})
export class  RoomsModule {
}

