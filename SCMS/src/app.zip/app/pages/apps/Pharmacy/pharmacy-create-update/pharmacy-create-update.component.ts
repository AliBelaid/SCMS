import { Component, Inject, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { DoctorService } from 'src/app/doctor/doctor.service';
import { CalendarEvent } from 'angular-calendar';
import { DialogModule } from '@angular/cdk/dialog';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule, MatRippleModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';
import { TranslateModule } from '@ngx-translate/core';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { PatientService } from 'src/app/patients/patient.service';
import { Patients, Doctor, ShiftDto, DoctorShifts, QueuePatient } from 'src/assets/his.model';

@Component({
  selector: 'vex-pharmacy-create-update',
  templateUrl: './pharmacy-create-update.component.html',
  styleUrls: ['./pharmacy-create-update.component.scss']
  ,
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    TranslateModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatMenuModule,
    MatTableModule,
    MatListModule,
    MatCheckboxModule,
    TranslateModule,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatTableModule,
    MatCheckboxModule,
    MatIconModule,
    MatDividerModule, MatSnackBarModule,
    CommonModule,
    MatDialogModule,
    TranslateModule,
    MatDatepickerModule,
    DialogModule,
    MatTreeModule,
    CdkTreeModule,
    MaterialFileInputModule,
    MatTabsModule,
    MatChipsModule,
    MatRippleModule,
    MatRippleModule,
    CdkStepperModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatSnackBarModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatNativeDateModule,
    MatSliderModule,
    MatFormFieldModule,
    MatStepperModule,
    MatOptionModule,
    FormsModule,
    MatRippleModule,
    MatIconModule,
    MatTabsModule,
    MatIconModule,
    DragDropModule
]

})
export class PharmacyCreateUpdateComponent implements OnInit {


  form: UntypedFormGroup;
  mode: 'create' | 'update' = 'create';
  patients:Patients[]=[];
doctors:Doctor[]=[];
 DoctorShifts: ShiftDto[] = [];
displayedColumns: string[] = ['select', 'day', 'count', 'start', 'end'];


  constructor(@Inject(MAT_DIALOG_DATA) public defaults: CalendarEvent,
              private dialogRef: MatDialogRef<PharmacyCreateUpdateComponent>,private _patientService:PatientService,
              private _doctorService:DoctorService,
              private fb: UntypedFormBuilder) {

                this._patientService.getPatients().subscribe((rep)=>{
                  this.patients = rep;
                });
                this._doctorService.getDoctors().subscribe((rep)=>{
                  this.doctors = rep;

                });

              //   {
              //     "id": 3,
              //     "name": "DrLee",
              //     "start": "2024-05-07T20:00:00.000Z",
              //     "end": "2024-05-07T00:00:00.000Z",
              //     "title": "DrLee-علم الأعصاب",
              //     "color": {
              //         "primary": "#1e90ff",
              //         "secondary": "#D1E8FF"
              //     },
              //     "meta": {
              //         "doctorId": 3
              //     }
              // }

  }

  ngOnInit() {
    if (this.defaults) {
      this.mode = 'update';
      this.form = this.fb.group({
        id: [this.defaults.id],
        patientId: [''],
         doctorId: [this.defaults.doctorId || ''],
        meetingType:[2] ,
       numberOfQueue:[0] ,   shiftId:[]
      });

      this.onDoctorCall();
      console.log(this.form.value)
    } else {
      this.form = this.fb.group({
         patientId: [''],
         doctorId: [''],
        shiftId:[],
        meetingType:[2] ,
       numberOfQueue:[0]

      });

    }


  }

  onShiftChange(event: any) {
    //const selectedShift = event.checked ? event.source.value : null;
    console.log(event)
    this.form.patchValue({ shiftId: event.id });


      if(event.totalNumbersIssued==0)
     {  this.form.patchValue({ numberOfQueue: 1 });}else {
      this.form.patchValue({ numberOfQueue: event.totalNumbersIssued+1 });
     }

  }
  onPatientChange(event): void {
    const selectedPatient = this.patients.find(patient => patient.id === event.value);
    if (selectedPatient) {
      if(this.defaults.id) {
       let  shift =  this.DoctorShifts[0];
        if(shift.totalNumbersIssued==0)
          {  this.form.patchValue({ numberOfQueue: 1 });}else {
           this.form.patchValue({ numberOfQueue: shift.totalNumbersIssued+1 });
          }

      }
    //  this.form.get('patientName').setValue(`${selectedPatient.firstName} ${selectedPatient.lastName}`);
    }
  }

  onDoctorChange(event): void {
    console.log(event);
    const selectedDoctor = this.doctors.find(doctor => doctor.id === event.value);
    if (selectedDoctor) {
      this._doctorService.getDoctorShiftDetails(event.value).subscribe(
        (data) => {
          // Handle both array and single object responses
          if (Array.isArray(data)) {
            this.DoctorShifts = data;
          } else if (data) {
            // If it's a single object, convert to array
            this.DoctorShifts = [data];
          } else {
            this.DoctorShifts = [];
          }
          
          // Filter or transform shifts if needed
          this.DoctorShifts = this.DoctorShifts.filter(shift => shift.isActiveQueue);
        },
        (error) => {
          console.error('Error fetching shift details', error);
        }
      );
    }
  }
  onDoctorCall(): void {
    const selectedDoctor = this.doctors.find(doctor => doctor.id === this.defaults.doctorId);
    if (selectedDoctor) {
      this._doctorService.getShiftById(Number(this.defaults.id)).subscribe(
        (data: ShiftDto) => {
          this.DoctorShifts = [data];
          this.form.patchValue({ shiftId: this.defaults.id });

          // Update queue number based on totalNumbersIssued
          if (data.totalNumbersIssued === 0) {
            this.form.patchValue({ numberOfQueue: 1 });
          } else {
            this.form.patchValue({ numberOfQueue: data.totalNumbersIssued + 1 });
          }
        },
        (error) => {
          console.error('Error fetching shift details', error);
        }
      );
    }
    
    if (selectedDoctor) {
      this.form.get('doctorName').setValue(`${selectedDoctor.firstName} ${selectedDoctor.lastName} / ${selectedDoctor.specialization}`);
    }
  }
  save() {
    if (this.form.valid) {
      this._doctorService.addToQueue(this.form.value).subscribe(
        (response: QueuePatient) => {
          console.log(response);
          this.dialogRef.close(response);
        },
        (error: any) => {
          console.error(error);
          alert('An error occurred while adding the patient to the queue.');
        }
      );
    }
  }

  createmedicalrecord() {
    const medicalrecord = this.form.value;



    this.dialogRef.close(medicalrecord);
  }

  updatemedicalrecord() {
    const medicalrecord = this.form.value;
    medicalrecord.id = this.defaults.id;

    this.dialogRef.close(medicalrecord);
  }

  isCreateMode() {
    return this.mode === 'create';
  }

  isUpdateMode() {
    return this.mode === 'update';
  }
}

