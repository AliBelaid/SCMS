import { Routes } from '@angular/router';
import { PharmacyComponent } from './pharmacy.component';

export const PHARMACY_ROUTES: Routes = [
  {
    path: '',
    component: PharmacyComponent,
    children: [
      {
        path: 'create',
        loadComponent: () => import('./pharmacy-create-update/pharmacy-create-update.component')
          .then(m => m.PharmacyCreateUpdateComponent)
      }
    ]
  }
];
