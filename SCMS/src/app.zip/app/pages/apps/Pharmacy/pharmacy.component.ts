import { Router } from '@angular/router';
import { AfterViewInit, Component, Input, OnInit, ViewChild, Pipe, DestroyRef, inject } from '@angular/core';
import { Observable, of, ReplaySubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { SelectionModel } from '@angular/cdk/collections';

import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { fadeInUp400ms } from 'src/@vex/animations/fade-in-up.animation';
import { stagger40ms } from 'src/@vex/animations/stagger.animation';
import { TableColumn } from 'src/@vex/interfaces/table-column.interface';
import { aioTableLabels, aioTableData } from 'src/static-data/aio-table-data';

import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { CommonModule } from '@angular/common';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTabsModule } from '@angular/material/tabs';
import { VexBreadcrumbsComponent } from '@vex/components/vex-breadcrumbs/vex-breadcrumbs.component';
import { VexPageLayoutContentDirective } from '@vex/components/vex-page-layout/vex-page-layout-content.directive';
import { VexPageLayoutHeaderDirective } from '@vex/components/vex-page-layout/vex-page-layout-header.directive';
import { VexPageLayoutComponent } from '@vex/components/vex-page-layout/vex-page-layout.component';
import { DoctorService } from 'src/app/doctor/doctor.service';
import { PatientService } from 'src/app/patients/patient.service';
import { AddMedicalPlanComponent } from 'src/app/patients/patient/patient-medical-conditions/add-medical-plan/add-medical-plan.component';
import { QueuePatient } from 'src/assets/his.model';
import { TreatmentDto } from 'src/assets/his.model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTableModule } from '@angular/material/table';
import { PharmacyCreateUpdateComponent } from './pharmacy-create-update/pharmacy-create-update.component';
import { ReceptionManagerCreateUpdateComponent } from 'src/app/pages/medical-record/reception-manager-create-update/reception-manager-create-update.component';
import { TreatmentService } from '../../treatment/treatment.service';

@Component({
  selector: 'vex-pharmacy',
  templateUrl: './pharmacy.component.html',
  styleUrls: ['./pharmacy.component.scss'],
  animations: [
    fadeInUp400ms,
    stagger40ms
  ],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCardModule,
    MatSnackBarModule,
    MatDialogModule,
    MatAutocompleteModule,
    MatTabsModule,
    MatStepperModule,
    MatMenuModule,
    TranslateModule,
    VexBreadcrumbsComponent,
    VexPageLayoutComponent,
    VexPageLayoutHeaderDirective,
    VexPageLayoutContentDirective,
    MatSlideToggleModule,
    MatButtonToggleModule,
    MatPaginatorModule,
    MatTableModule
  ]
})

export class PharmacyComponent implements OnInit, AfterViewInit {

  PrinterPlan(row:QueuePatient) {
    this.treatmentService.downloadAndPrintPDF(row.treatment.id);
   }

     selectTreatmentDto:TreatmentDto;





    layoutCtrl = new UntypedFormControl('fullwidth');

    /**
     * Simulating a service with HTTP that returns Observables
     * You probably want to remove this and do all requests in a service with HTTP
     */
    subject$: ReplaySubject<QueuePatient[]> = new ReplaySubject<QueuePatient[]>(1);
    data$: Observable<QueuePatient[]> = this.subject$.asObservable();
    QueuePatients: QueuePatient[];

    @Input()
    columns: TableColumn<QueuePatient>[] = [
      { label: 'Queue Number', property: 'numberOfQueue', type: 'text', visible: true },
      { label: 'Patient Name', property: 'patientName', type: 'text', visible: true, cssClasses: ['font-medium'] },

      { label: 'Doctor Name', property: 'doctorName', type: 'text', visible: true, cssClasses: ['font-medium'] },
      { label: 'Day', property: 'day', type: 'text', visible: true },


      { label: 'Finished', property: 'isFinished', type: 'text', visible: true },
      { label: 'Meeting Type', property: 'meetingType', type: 'text', visible: true },
      { label: 'SPECIALIZATION', property: 'doctorSpecialization', type: 'text', visible: true },
      { label: 'Actions', property: 'actions', type: 'button', visible: true },
    ];



    selectedSpecialization: string =this.translate.instant("SPECIALIZATION");
    specializations: string[] = ['Cardiology', 'Neurology', 'Pediatrics', 'Dermatology']; // Example specializations

    filterBySpecialization(specialization: string) {
      if (specialization) {
        this.dataSource.data = this.QueuePatients.filter(patient => patient.doctorSpecialization === specialization);
      } else {
        this.dataSource.data = this.QueuePatients;
      }
    }

    viewTodayRecords() {
      const today = new Date()//.toLocaleDateString('en-CA'); // Get today's date in YYYY-MM-DD format
      console.log(today)
      this.dataSource.data = this.QueuePatients.filter(patient => patient.day === today);
    }

    resetFilters() {
      this.selectedSpecialization = '';
      this.searchCtrl.setValue('');
      this.dataSource.data = this.QueuePatients;
    }



    getMeetingTypeLabel(meetingType: number): string {
      switch (meetingType) {
        case 0:
          return this.translate.instant('EMERGENCY'); // حالة طارئة
        case 1:
          return this.translate.instant('FOLLOW_UP'); // حالة مراجعة
        case 2:
          return this.translate.instant('CHECKUP'); // حالة كشف
        default:
          return this.translate.instant('Unknown');
      }
    }
    pageSize = 10;
    pageSizeOptions: number[] = [5, 10, 20, 50];
     dataSource: MatTableDataSource<QueuePatient> | null;

    selection = new SelectionModel<QueuePatient>(true, []);
    searchCtrl = new UntypedFormControl();

    labels = aioTableLabels;

    @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
    @ViewChild(MatSort, { static: true }) sort: MatSort;

    constructor(private dialog: MatDialog ,private treatmentService:TreatmentService,
      private patientService:PatientService ,
       private doctorService:DoctorService ,
       private router:Router,
      private translate:TranslateService
  ,private toaster:ToastrService

     ) {
    }

    get visibleColumns() {
      return this.columns.filter(column => column.visible).map(column => column.property);
    }

    /**
     * Example on how to get data and pass it to the table - usually you would want a dedicated service with a HTTP request for this
     * We are simulating this request here.
     */

    ngOnInit() {
      this.patientService.getAllQueuePatients().subscribe(QueuePatients => {
        const filteredQueuePatients = QueuePatients.filter(dto =>dto.isFinished===true);

        this.subject$.next(filteredQueuePatients);
      });

      this.dataSource = new MatTableDataSource();

      this.data$.pipe(
        filter<QueuePatient[]>(Boolean)
      ).subscribe(QueuePatients => {
        this.QueuePatients = QueuePatients;
        this.dataSource.data = QueuePatients;
      });

      this.searchCtrl.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((value) => this.onFilterChange(value));
  }

  private readonly destroyRef: DestroyRef = inject(DestroyRef);

    ngAfterViewInit() {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }

    createMedicalRecord() {
      const dialogRef = this.dialog.open(PharmacyCreateUpdateComponent, {
        minWidth: '600px',
        minHeight:'750px',
      }).afterClosed().subscribe((QueuePatient: any) => {
        /**
         * QueuePatient is the updated QueuePatient (if the user pressed Save - otherwise it's null)
         */
        if (QueuePatient) {
          /**
           * Here we are updating our local array.
           * You would probably make an HTTP request here.
           */

          const dataToSend = {

            patientId: QueuePatient.patientId,
            dateOfVisit: QueuePatient.dateOfVisit ,
            doctorId: QueuePatient.doctorId,
            diagnosis: QueuePatient.diagnosis ,
            treatmentDescription: QueuePatient.treatmentDescription
          }
          // this.patientService.createQueueP(dataToSend).subscribe((rep)=> {
          //   this.QueuePatients.unshift( QueuePatient);
          //   this.subject$.next(this.QueuePatients);
          // })

        }
      });
    }

    updateMedicalRecord(QueuePatient: QueuePatient) {
      this.dialog.open(PharmacyCreateUpdateComponent, {
        data: QueuePatient
      }).afterClosed().subscribe(updatedQueuePatient => {
        /**
         * QueuePatient is the updated QueuePatient (if the user pressed Save - otherwise it's null)
         */
        if (updatedQueuePatient) {

        }});}
   navigateToMedicalConditions(patient: QueuePatient) {
    console.log(patient)
      let pp = patient;



     if(!pp.isTreatment&& !pp.isFinished && pp.treatment  ) {

      this.dialog.open(AddMedicalPlanComponent, {
        data: patient.treatment
      }
     ).afterClosed().subscribe((Patients: any) => {
          if (Patients) {
          }})}

    else if(!pp.treatment  ||  pp.treatment ===null)  {
      this.router.navigate([`/medical-conditions/${pp.queuePatientId}`]);
    }
    else {
      this.toaster.error("تم أستكمال العلاج")
    }

    }

        deleteMedicalRecord(QueuePatient: QueuePatient) {
      /**
       * Here we are updating our local array.
       * You would probably make an HTTP request here.
       */

    //   this.patientService.deleteQueuePatient(QueuePatient.id).subscribe((rep)=> {

    //   this.QueuePatients.splice(this.QueuePatients.findIndex((existingQueuePatient) => existingQueuePatient.id === QueuePatient.id), 1);
    //   this.selection.deselect(QueuePatient);
    //   this.subject$.next(this.QueuePatients);
    // });


  }

    deleteQueuePatients(QueuePatients: QueuePatient[]) {
      /**
       * Here we are updating our local array.
       * You would probably make an HTTP request here.
       */
      QueuePatients.forEach(c => this.deleteMedicalRecord(c));
    }

    onFilterChange(value: string) {
      if (!this.dataSource) {
        return;
      }
      value = value.trim();
      value = value.toLowerCase();
      this.dataSource.filter = value;
    }

    toggleColumnVisibility(column, event) {
      event.stopPropagation();
      event.stopImmediatePropagation();
      column.visible = !column.visible;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
      const numSelected = this.selection.selected.length;
      const numRows = this.dataSource.data.length;
      return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
      this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
    }

    trackByProperty<T>(index: number, column: TableColumn<T>) {
      return column.property;
    }

    onLabelChange(change: MatSelectChange, row: QueuePatient) {
      const index = this.QueuePatients.findIndex(c => c === row);
      this.QueuePatients[index].id = change.value;
      this.subject$.next(this.QueuePatients);
    }
  }

