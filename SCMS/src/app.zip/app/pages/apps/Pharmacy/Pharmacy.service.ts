import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/assets/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PharmacyService {
  createDrug(drug: Drug): Observable<Drug> {
    return this.http.post<Drug>(this.baseUrl, drug, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }
  private baseUrl = environment.apiUrl + '/Drugs';

  constructor(private http: HttpClient) { }

  // Upload an Excel file
  uploadExcel(file: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);

    return this.http.post(`${this.baseUrl}/upload`, formData, {
      headers: new HttpHeaders({
        'Accept': 'application/json'
      })
    });
  }

  // Get all drugs
  getDrugs(): Observable<Drug[]> {
    return this.http.get<Drug[]>(this.baseUrl);
  }

  // Get a drug by ID
  getDrugById(id: number): Observable<Drug> {
    return this.http.get<Drug>(`${this.baseUrl}/${id}`);
  }

  // Update a drug
  updateDrug(id: number, drug: Drug): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, drug, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }

  // Delete a drug
  deleteDrug(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}
export interface Drug {
  id: number;
  englishName: string;
  arabicName: string;
  activeIngredient: string;
  company: string;
  classification: string;
  units: number;
  form: string;
  barcode: string;
}
