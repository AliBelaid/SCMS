import { LayoutComponent } from './layouts/layout/layout.component';
import { VexRoutes } from '@vex/interfaces/vex-route.interface';
import { PatientMedicalRecordsComponent } from './patients/patient/patient-medical-records/patient-medical-records.component';
import { PatientMedicalConditionsComponent } from './patients/patient/patient-medical-conditions/patient-medical-conditions.component';
import { RoleGuard } from './guards/role.guard';
import { servicePricingRoutes } from './service-pricing/service-pricing.routes';
import { AuthGuard } from './guards/auth.guard';

export const appRoutes: VexRoutes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./pages/pages/auth/login/login.component').then(
        (m) => m.LoginComponent
      )
  },
  {
    path: 'register',
    loadComponent: () =>
      import('./pages/pages/auth/register/register.component').then(
        (m) => m.RegisterComponent
      )
  },
  {
    path: 'finish/:id',
    loadComponent: () => import('./pages/queue-patient-finish/queue-patient-finish.component')
      .then((m) => m.QueuePatientFinishComponent)
  },


  {
    path: 'forgot-password',
    loadComponent: () =>
      import(
        './pages/pages/auth/forgot-password/forgot-password.component'
      ).then((m) => m.ForgotPasswordComponent)
  },
  {
    path: 'coming-soon',
    loadComponent: () =>
      import('./pages/pages/coming-soon/coming-soon.component').then(
        (m) => m.ComingSoonComponent
      )
  },



  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'dashboards/analytics',
        redirectTo: '/',
        pathMatch: 'full'
      },
      {
        path: '',
        loadComponent: () =>
          import(
            './pages/dashboards/dashboard-analytics/dashboard-analytics.component'
          ).then((m) => m.DashboardAnalyticsComponent)
      },  {
        path: 'reports',
        loadChildren: () =>
          import('./pages/radiology/radiology.module').then(
            (m) => m.RadiologyModule
          )
      },
    



      {
        path: '',
        children: [
          {
            path: 'chat',
            loadChildren: () => import('./pages/apps/chat/chat.routes')
          },
          {
            path: 'analysis-patient',
            loadChildren: () => import('./pages/apps/analysis-patient/analysis-patient.routes')
              .then((m) => m.ANALYSIS_PATIENT_ROUTES)
          },
          {path:'printer-settings',
            loadComponent: () => import('./pages/settings/printer-settings/printer-settings.component')
              .then((m) => m.PrinterSettingsComponent),
            data: {
              toolbarShadowEnabled: true
            }
          },
          {
            path: 'printer',
            loadComponent: () => import('./pages/settings/printer-settings/printer-settings.component')
              .then(m => m.PrinterSettingsComponent)
          },

          {
            path: 'admin',
            loadChildren: () => import('./pages/apps/admin/admin.routes')
              .then((m) => m.ADMIN_ROUTES),
            canActivate: [RoleGuard],
            data: {
              roles: ['Admin']
            }
          },
          {
            path: 'analysis-laboratory',
            loadChildren: () => import('./pages/apps/analysis-laboratory/analysis-laboratory.routes')
              .then((m) => m.ANALYSIS_LABORATORY_ROUTES)
          },
          {
            path: 'pharmaceuticals',
            loadChildren: () => import('./pages/apps/pharmaceuticals/pharmaceutical-routing.module')
              .then((m) => m.Pharmaceutical_ROUTES)
          },
          {
            path: 'pharmacy',
            loadChildren: () => import('./pages/apps/Pharmacy/pharmacy.routes')
              .then((m) => m.PHARMACY_ROUTES)
          },
          {
            path: 'emergency-admission',
            loadChildren: () => import('./pages/apps/emergency-admission/emergency-admission.routes')
              .then((m) => m.EMERGENCY_ADMISSION_ROUTES)
          },
          {
            path: 'rooms',
            loadChildren: () => import('./pages/apps/room/room.routes').then(m => m.ROOM_ROUTES)
          },
           {
            path: 'reception',
            loadComponent: () => import('./pages/reception/reception.component').then(m => m.ReceptionComponent),
            canActivate: [RoleGuard],
            data: {
              roles: ['Admin', 'Reception']
            }
           },


{
 path: 'equipment',
  loadComponent: () => import('./pages/apps/hospital/equipment/equipment.component').then(m => m.EquipmentComponent)
},
{

path: 'staff',
loadComponent: () => import('./pages/apps/hospital/staff/staff.component').then(m => m.StaffComponent)

},
{path:'inventory',
loadComponent: () => import('./pages/apps/hospital/inventory/inventory.component').then(m => m.InventoryComponent)

},

          {
            path: 'employee-registration',
            loadComponent: () => import('./pages/insurance/employee-registration/employee-registration.component').then(m => m.EmployeeRegistrationComponent),
          },
          
          {
            path: 'imaging',
            children: [
              {
                path: 'types',
                loadComponent: () => import('./pages/imaging/imaging-types/imaging-types.component')
                  .then(m => m.ImagingTypesComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Imaging']
                }
              },
              {
                path: 'request',
                loadComponent: () => import('./pages/imaging/patient-imaging-request/patient-imaging-request.component')
                  .then(m => m.PatientImagingRequestComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Imaging', 'Doctor']
                }
              },
              {
                path: '',
                redirectTo: 'types',
                pathMatch: 'full'
              }
            ]
          },



          {
            path: 'patients',
            loadChildren: () => import('./patients/patients.routes')
              .then((m) => m.PATIENTS_ROUTES)
          },
          {
            path: 'emergency-patient',
            loadComponent: () => import('./pages/apps/emergency-patient/emergency-patient.component').then(m => m.EmergencyPatientComponent)
          },
          {
            path: 'treatment',
            loadChildren: () => import('./pages/treatment/treatment.routes').then(m => m.TREATMENT_ROUTES)
          },
          {
            path: 'hospital-requests',
            loadChildren: () => import('./pages/apps/hospital-requests/hospital-requests.routes').then(m => m.HOSPITAL_REQUESTS_ROUTES)
          },

          {
            path: 'surgery',
            loadChildren: () => import('./pages/apps/surgeries/surgery-routing.module').then(m => m.SurgeryRoutingModule)

          },
          {
            path: 'section-requests',
            loadChildren: () => import('./pages/apps/section-requests/section-requests.routes').then(m => m.SECTION_REQUESTS_ROUTES)
          },
          {
            path: 'specialties',
            children: [
              {
                path: '',
                loadComponent: () => import('./pages/apps/specialty/clinic-management.component')
                  .then(m => m.ClinicManagementComponent)
              },
              {
                path: 'calendar',
                loadComponent: () => import('./pages/apps/specialty/clinic-management/calendar-clinic/calendar-clinic.component')
                  .then(m => m.CalendarClinicComponent)
              }
            ]
          },
          {
            path: 'queues',
            loadComponent: () => import('./pages/medical-record/reception-manager.component')
              .then((m) => m.ReceptionManagerComponent),
            canActivate: [RoleGuard],
            data: {
              toolbarShadowEnabled: true,
              roles: ['Admin', 'Reception', 'Doctor']
            }
          },
          {
            path: 'payments',
            loadComponent: () => import('./pages/payment-management/payment-management.component').then(m => m.PaymentManagementComponent)
          },
          {
            path: 'medical-record/:id',
            component:PatientMedicalConditionsComponent,
            //  loadChildren: () => import('./patient/patient-medical-records/patient-medical-records.module').then(m => m.PatientMedicalrecordsModule),
              data: {
                toolbarShadowEnabled: true
              }
          },

          {
            path: 'medical-conditions/:id',
            component:PatientMedicalConditionsComponent,
          //  loadChildren: () => import('./patient/patient-medical-records/patient-medical-records.module').then(m => m.PatientMedicalrecordsModule),
            data: {
              toolbarShadowEnabled: true
            }
            //component: PatientMedicalConditionsComponent,
          },



          {
            path: 'doctor',
            loadChildren: () => import('./doctor/doctor.routes')
              .then((m) => m.DOCTOR_ROUTES),
        //    canActivate: [AuthGuard]
          },
          {
            path: 'user',
            loadChildren: () => import('./user/user.module').then(m => m.UserModule)
          },
          {
            path: 'mail',
            loadChildren: () => import('./pages/apps/mail/mail.routes'),
            data: {
              toolbarShadowEnabled: true,
              scrollDisabled: true
            }
          },
          {
            path: 'social',
            loadChildren: () => import('./pages/apps/social/social.routes')
          },
          {
            path: 'contacts',
            loadChildren: () => import('./pages/apps/contacts/contacts.routes')
          },
          {
            path: 'calendar',
            loadComponent: () =>
              import('./pages/apps/calendar/calendar.component').then(
                (m) => m.CalendarComponent
              ),
            data: {
              toolbarShadowEnabled: true
            }
          },
          {
            path: 'aio-table',
            loadComponent: () =>
              import('./pages/apps/aio-table/aio-table.component').then(
                (m) => m.AioTableComponent
              ),
            data: {
              toolbarShadowEnabled: false
            }
          },

          {
            path:'appointment',
            loadComponent: () =>
            import('./pages/apps/appointment/appointment.component')
            .then((m) => m.AppointmentComponent) ,

            data: {
              toolbarShadowEnabled: false
            }

          },






          {
            path: 'help-center',
            loadChildren: () =>
              import('./pages/apps/help-center/help-center.routes')
          },
          {
            path: 'scrumboard',
            loadChildren: () =>
              import('./pages/apps/scrumboard/scrumboard.routes')
          },
          {
            path: 'editor',
            loadComponent: () =>
              import('./pages/apps/editor/editor.component').then(
                (m) => m.EditorComponent
              ),
            data: {
              scrollDisabled: true
            }
          },
          {
            path: 'insurance',
            children: [
              {
                path: 'employee-registration',
                loadComponent: () => import('./pages/insurance/employee-registration/employee-registration.component')
                  .then(m => m.EmployeeRegistrationComponent),
                data: {
                  toolbarShadowEnabled: true
                }
              }
            ]
          },
          {
            path: 'service-pricing',
            children: servicePricingRoutes
          },
          {
            path: 'treasury',
            children: [
              {
                path: '',
                redirectTo: 'dashboard',
                pathMatch: 'full'
              },
              {
                path: 'dashboard',
                loadComponent: () => import('./pages/treasury/treasury-dashboard/treasury-dashboard.component')
                  .then(m => m.TreasuryDashboardComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Finance']
                }
              },
              {
                path: 'settlements',
                loadComponent: () => import('./pages/treasury/settlements/settlements.component')
                  .then(m => m.SettlementsComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Finance']
                }
              },
              {
                path: 'doctor-payouts',
                loadComponent: () => import('./pages/treasury/doctor-payouts/doctor-payouts.component')
                  .then(m => m.DoctorPayoutsComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Finance']
                }
              },
              {
                path: 'expenses',
                loadComponent: () => import('./pages/treasury/expenses/expenses.component')
                  .then(m => m.ExpensesComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Finance']
                }
              },
              {
                path: 'doctor-balance/:id',
                loadComponent: () => import('./pages/treasury/doctor-balance/doctor-balance.component')
                  .then(m => m.DoctorBalanceComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Finance', 'Doctor']
                }
              },
              {
                path: 'backup-queue',
                loadComponent: () => import('./pages/treasury/backup-queue/backup-queue.component')
                  .then(m => m.BackupQueueComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Finance']
                }
              }
            ]
          }
        ]
      },
      {
        path: 'pages',
        children: [
          {
            path: 'pricing',
            loadComponent: () =>
              import('./pages/pages/pricing/pricing.component').then(
                (m) => m.PricingComponent
              )
          },
          {
            path: 'faq',
            loadComponent: () =>
              import('./pages/pages/faq/faq.component').then(
                (m) => m.FaqComponent
              )
          },
          {
            path: 'guides',
            loadComponent: () =>
              import('./pages/pages/guides/guides.component').then(
                (m) => m.GuidesComponent
              )
          },
          {
            path: 'invoice',
            loadComponent: () =>
              import('./pages/pages/invoice/invoice.component').then(
                (m) => m.InvoiceComponent
              )
          },
          {
            path: 'error-404',
            loadComponent: () =>
              import('./pages/pages/errors/error-404/error-404.component').then(
                (m) => m.Error404Component
              )
          },
          {
            path: 'error-500',
            loadComponent: () =>
              import('./pages/pages/errors/error-500/error-500.component').then(
                (m) => m.Error500Component
              )
          }
        ]
      },
      {
        path: 'ui',
        children: [
          {
            path: 'components',
            loadChildren: () =>
              import('./pages/ui/components/components.routes')
          },
          {
            path: 'forms/form-elements',
            loadComponent: () =>
              import(
                './pages/ui/forms/form-elements/form-elements.component'
              ).then((m) => m.FormElementsComponent)
          },
          {
            path: 'forms/form-wizard',
            loadComponent: () =>
              import('./pages/ui/forms/form-wizard/form-wizard.component').then(
                (m) => m.FormWizardComponent
              )
          },
          {
            path: 'icons',
            loadChildren: () => import('./pages/ui/icons/icons.routes')
          },
          {
            path: 'page-layouts',
            loadChildren: () =>
              import('./pages/ui/page-layouts/page-layouts.routes')
          }
        ]
      },
      {
        path: 'documentation',
        loadChildren: () => import('./pages/documentation/documentation.routes')
      },
      {
        path: 'doctors',
        children: [
          {
            path: ':id',
            loadComponent: () =>
              import('./doctor/doctor-profile/doctor-profile.component')
                .then((m) => m.DoctorProfileComponent),
        //    canActivate: [AuthGuard],
            children: [
              {
                path: 'profile',
                loadComponent: () =>
                  import('./doctor/doctor-profile/user/doctor-detalis/doctor-detalis.component')
                    .then((m) => m.DoctorDetalisComponent)
              },
              {
                path: 'details',
                loadComponent: () =>
                  import('./doctor/doctor-profile/user/doctor-detalis/doctor-detalis.component')
                    .then((m) => m.DoctorDetalisComponent)
              },
              // {
              //   path: 'queue',
              //   loadComponent: () =>
              //     import('./doctor/doctor-profile/user/contacts/contacts-table/contacts-table.component')
              //       .then((m) => m.ContactsTableComponent)
              // },
              {
                path: 'schedule',
                loadComponent: () =>
                  import('./doctor/doctor-shift/doctor-shift.component')
                    .then((m) => m.DoctorShiftComponent)
              },
              {
                path: 'balance',
                loadComponent: () =>
                  import('./doctor/doctor-balance/doctor-balance.component')
                    .then((m) => m.DoctorBalanceComponent),
                canActivate: [RoleGuard],
                data: {
                  roles: ['Admin', 'Finance', 'Doctor']
                }
              },
              {
                path: '',
                redirectTo: 'details',
                pathMatch: 'full'
              }
            ]
          }
        ]
      },
      {
        path: 'patients',
        children: [
          {
            path: ':id',
            children: [
              {
                path: 'profile',
                loadComponent: () =>
                  import('./patients/patient-profile.component')
                    .then((m) => m.PatientProfileComponent)
              },
              {
                path: 'details',
                loadComponent: () =>
                  import('./patients/patient-profile.component')
                    .then((m) => m.PatientProfileComponent)
              },
              {
                path: 'history',
                loadComponent: () =>
                  import('./patients/patient-profile.component')
                    .then((m) => m.PatientProfileComponent)
              },
              {
                path: 'appointments',
                loadComponent: () =>
                  import('./pages/apps/appointment/appointment.component')
                    .then((m) => m.AppointmentComponent)
              },
              {
                path: 'documents',
                loadComponent: () =>
                  import('./patients/patient-profile.component')
                    .then((m) => m.PatientProfileComponent)
              }
            ]
          }
        ]
      },
      {
        path: '**',
        loadComponent: () =>
          import('./pages/pages/errors/error-404/error-404.component').then(
            (m) => m.Error404Component
          )
      }
    ]
  }
];
