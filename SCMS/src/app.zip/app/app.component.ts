import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { TranslateService } from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { NavigationService } from './core/navigation/navigation.service';
import { NavigationLoaderService } from './core/navigation/navigation-loader.service';
import { NavigationItem } from './core/navigation/navigation-item.interface';
import { UserService } from './user/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: true,
  imports: [
    RouterOutlet,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    TranslateModule
  ]
})
export class AppComponent implements OnInit {
  selectedLang = localStorage.getItem('userLang') || 'ar';
  navigationItems = [
    {
      type: 'subheading',
      label: this.translate.instant('APPLICATIONS'),
      children: [
        {
          type: 'link',
          label: this.translate.instant('DOCTORS'),
          route: '/doctor',
          icon: 'mat:medical_services',
          roles: ['Admin', 'Reception' ,'MedicalTechnician']
        },
        {
          type: 'link',
          label: this.translate.instant('PATIENTS'),
          route: '/patients',
          icon: 'mat:people',
          roles: ['Admin', 'Doctor', 'Reception' ,'MedicalTechnician']
        },
        {
          type: 'link',
          label: this.translate.instant('RECEPTION'),
          route: '/reception',
          icon: 'mat:desk',
          roles: ['Admin', 'Reception' ,'MedicalTechnician']
        },
        {
          type: 'link',
          label: this.translate.instant('PRICING'),
          route: '/service-pricing',
          icon: 'mat:payment',
          roles: ['Admin', 'Finance' ,'Reception']
        },
        {
          type: 'link',
          label: this.translate.instant('PAYMENTS'),
          route: '/payments',
          icon: 'mat:credit_card',
          roles: ['Admin', 'Finance', 'Reception']
        },
        {
          type: 'link',
          label: this.translate.instant('SETTINGS'),
          route: '/settings',
          icon: 'mat:settings',
          roles: ['Admin', 'Finance', 'Reception']
        },
        {
          type: 'dropdown',
          label: this.translate.instant('TREASURY'),
          icon: 'mat:account_balance',
          roles: ['Admin', 'Finance'],
          children: [
            {
              type: 'link',
              label: this.translate.instant('DASHBOARD'),
              route: '/treasury/dashboard',
              icon: 'mat:dashboard',
              roles: ['Admin', 'Finance']
            },
            {
              type: 'link',
              label: this.translate.instant('DOCTOR_BALANCE'),
              route: '/treasury/doctor-balance',
              icon: 'mat:payments',
              roles: ['Admin', 'Finance', 'Doctor']
            },
            {
              type: 'link',
              label: this.translate.instant('DOCTOR_PAYOUTS'),
              route: '/treasury/doctor-payouts',
              icon: 'mat:account_balance_wallet',
              roles: ['Admin', 'Finance']
            },
            {
              type: 'link',
              label: this.translate.instant('EXPENSES'),
              route: '/treasury/expenses',
              icon: 'mat:receipt_long',
              roles: ['Admin', 'Finance']
            },
            {
              type: 'link',
              label: this.translate.instant('SETTLEMENTS'),
              route: '/treasury/settlements',
              icon: 'mat:currency_exchange',
              roles: ['Admin', 'Finance']
            },
            {
              type: 'link',
              label: this.translate.instant('BACKUP_QUEUE'),
              route: '/treasury/backup-queue',
              icon: 'mat:backup',
              roles: ['Admin', 'Finance']
            }
          ]
        },
        {
          type: 'link',
          label: this.translate.instant('MEDICAL_RECORDS'),
          route: '/queues',
          icon: 'mat:folder',
          roles: ['Admin', 'Doctor', 'Reception' ,'MedicalTechnician']
        },
        {
          type: 'link',
          label: this.translate.instant('PHARMACY'),
          route: '/pharmacy',
          icon: 'mat:local_pharmacy',
          roles: ['Admin', 'Pharmacy']
        },
        {
          type: 'link',
          label: this.translate.instant('ADMIN'),
          route: '/admin',
          icon: 'mat:admin_panel_settings',
          roles: ['Admin']
        } 
      ]
    },
    {
      type: 'subheading',
      label: this.translate.instant('SPECIALTIES'),
      children: [
        {
          type: 'link',
          label: this.translate.instant('CLINIC_MANAGEMENT_TITLE'),
          route: '/specialties',
          icon: 'mat:medical_services',
          roles: ['Admin', 'Hospital']
        },
        {
          type: 'link',
          label: this.translate.instant('CLINIC_MANAGEMENT_CALENDAR'),
          route: '/specialties/calendar',
          icon: 'mat:calendar_today',
          roles: ['Admin', 'Hospital', 'Reception']
        },
        {
          type: 'link',
          label: this.translate.instant('SHIFT_MANAGEMENT'),
          route: '/specialties/shifts',
          icon: 'mat:schedule',
          roles: ['Admin', 'Hospital', 'Reception']
        },
        {
          type: 'link',
          label: this.translate.instant('CLINIC_MANAGEMENT_SUBTITLE'),
          route: '/specialties/records',
          icon: 'mat:folder',
          roles: ['Admin', 'Hospital']
        }
      ]
    },
    {
      type: 'subheading',
      label: this.translate.instant('HOSPITAL_MANAGEMENT'),
      roles: ['Admin', 'Hospital'],
      children: [
        {
          type: 'link',
          label: this.translate.instant('DEPARTMENTS'),
          route: '/departments',
          icon: 'mat:business',
          roles: ['Admin', 'Hospital']
        },
        {
          type: 'link',
          label: this.translate.instant('ROOMS'),
          route: '/rooms',
          icon: 'mat:meeting_room',
          roles: ['Admin', 'Hospital']
        },
        {
          type: 'link',
          label: this.translate.instant('STAFF'),
          route: '/staff',
          icon: 'mat:badge',
          roles: ['Admin', 'Hospital']
        },
        {
          type: 'link',
          label: this.translate.instant('EQUIPMENT'),
          route: '/equipment',
          icon: 'mat:medical_services',
          roles: ['Admin', 'Hospital']
        },
        {
          type: 'link',
          label: this.translate.instant('INVENTORY'),
          route: '/inventory',
          icon: 'mat:inventory',
          roles: ['Admin', 'Hospital']
        },
        {
          type: 'link',
          label: this.translate.instant('APPOINTMENTS'),
          route: '/appointments',
          icon: 'mat:event',
          roles: ['Admin', 'Hospital', 'Reception']
        },
        {
          type: 'link',
          label: this.translate.instant('BILLING'),
          route: '/billing',
          icon: 'mat:receipt',
          roles: ['Admin', 'Hospital', 'Finance']
        },
        {
          type: 'link',
          label: this.translate.instant('REPORTS'),
          route: '/reports',
          icon: 'mat:assessment',
          roles: ['Admin', 'Hospital']
        }
      ]
    },
    {
      type: 'subheading',
      label: this.translate.instant('SETTINGS'),
      children: [
        {
          type: 'link',
          label: this.translate.instant('USER_PROFILE'),
          route:   '/user',
          icon: 'mat:person',
          roles: ['Admin',  'Finance', 'Pharmacy', 'Hospital']
        },
        {
          type: 'link',
          label: this.translate.instant('SYSTEM_SETTINGS'),
          route: '/system-settings',
          icon: 'mat:settings',
          roles: ['Admin']
        },
        {
          type: 'link',
          label: this.translate.instant('PRINTER_SETTINGS'),
          route: '/printer-settings',
          icon: 'mat:print',
          roles: ['Admin']
        }
      ]
    }
  ];

  constructor(
    private translate: TranslateService,
    private navigationService: NavigationLoaderService,
    public userService: UserService
  ) {
    this.translate.setDefaultLang(this.selectedLang);
    this.translate.use(this.selectedLang);
    
    // Load additional translation files for Arabic
    if (this.selectedLang === 'ar') {
      this.loadAdditionalTranslations();
    }
    
    // Listen for language changes
    this.translate.onLangChange.subscribe((event) => {
      if (event.lang === 'ar') {
        this.loadAdditionalTranslations();
      }
    });
  }

  ngOnInit(): void {
    this.translate.onLangChange.subscribe(() => {
      this.loadMenuItems();
    });
    
    // Initial load
    this.loadMenuItems();
    
    // Reload when user changes
    this.userService.currentUser$.subscribe(user => {
      if (user) {
        this.filterMenuItemsByUserRoles(user.roles);
      }
    });
  }

  loadMenuItems() {
    // Get current user roles
    this.userService.currentUser$.subscribe(user => {
      if (user && user.roles) {
        this.filterMenuItemsByUserRoles(user.roles);
      } else {
        // No user or no roles, just show public items
        this.navigationService.updateItems([]); 
      }
    });
  }
  
  /**
   * Filter menu items based on user roles
   */
  filterMenuItemsByUserRoles(userRoles: string[]) {
    if (!userRoles || userRoles.length === 0) {
      this.navigationService.updateItems([]);
      return;
    }
    
    // Deep clone the navigation items to avoid modifying the original
    const items = JSON.parse(JSON.stringify(this.navigationItems));
    
    // Filter function for items
    const filterItemsByRole = (items: any[]): any[] => {
      return items.filter(item => {
        // Check if item has roles defined and if user has any of those roles
        if (item.roles && item.roles.length > 0) {
          // Keep item only if user has at least one of the required roles
          const hasRequiredRole = item.roles.some((role: string) => 
            userRoles.includes(role)
          );
          
          if (!hasRequiredRole) {
            return false;
          }
        }
        
        // If this item has children, filter them as well
        if (item.children && item.children.length > 0) {
          item.children = filterItemsByRole(item.children);
          
          // If after filtering children there are none left, don't show the parent item
          if (item.type === 'dropdown' && item.children.length === 0) {
            return false;
          }
          
          // For subheadings, if no children are left, don't show it
          if (item.type === 'subheading' && item.children.length === 0) {
            return false;
          }
        }
        
        return true;
      });
    };
    
    // Apply filter
    const filteredItems = filterItemsByRole(items);
    
    // Update navigation
    this.navigationService.updateItems(filteredItems as NavigationItem[]);
  }
  
  // Load additional translation files
  private loadAdditionalTranslations() {
    // Load reception management translations
    fetch('./assets/translate/reception-ar.json')
      .then(response => response.json())
      .then(translations => {
        // Merge translations with the main translation set
        this.translate.setTranslation('ar', translations, true);
      })
      .catch(error => {
        console.error('Error loading reception translations:', error);
      });
  }
}
