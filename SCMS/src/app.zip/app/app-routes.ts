import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  // Default redirect for technicians
  { 
    path: 'technician', 
    redirectTo: 'technician-dashboard',
    pathMatch: 'full'
  },
  
  // Technician routes
  { 
    path: 'technician-dashboard', 
    loadComponent: () => import('./user/technician-dashboard/technician-dashboard.component').then(m => m.TechnicianDashboardComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'technician-queue', 
    loadComponent: () => import('./user/technician-queue/technician-queue.component').then(m => m.TechnicianQueueComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'technician-analytics', 
    loadComponent: () => import('./user/technician-analytics/technician-analytics.component').then(m => m.TechnicianAnalyticsComponent),
    canActivate: [AuthGuard]
  }
]; 